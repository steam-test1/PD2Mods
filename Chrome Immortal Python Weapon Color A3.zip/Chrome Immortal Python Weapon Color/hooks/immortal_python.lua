local init_original = DLCTweakData.init
function DLCTweakData:init(...)
	init_original(self, ...)

    -- self.immortal_python_13 = {
    --     dlc = "has_achievement_milestone",
	-- 	milestone_id = "ami_13",
	-- 	content = {}
	-- }
	-- self.immortal_python_13.content.loot_global_value = "tam"
	-- self.immortal_python_13.content.loot_drops = {
		
	-- }
	table.insert( self.ami_13.content.loot_drops,
		{
			type_items = "weapon_skins",
			item_entry = "chrome_immortal_python",
			amount = 1
		}
	)
end