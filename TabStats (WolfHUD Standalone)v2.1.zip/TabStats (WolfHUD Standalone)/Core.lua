if not _G.WolfTabStats then
	_G.WolfTabStats = {}
	WolfTabStats.mod_path = ModPath
	WolfTabStats.save_path = SavePath
	WolfTabStats.assets_path = "./assets/mod_overrides/"
	WolfTabStats.settings_path = WolfTabStats.save_path .. "WolfTabStats2.json"
	WolfTabStats.tweak_file = "WolfHUDTweakData.lua"
	WolfTabStats.identifier = string.match(WolfTabStats.mod_path, "[\\/]([%w_%-%.]+)[\\/]$") or "WolfTabStats"

	WolfTabStats.notifications = {}
	WolfTabStats.settings = {}
	WolfTabStats.tweak_data = {}

	function WolfTabStats:Reset()
		local default_lang = "english"
		for _, filename in pairs(file.GetFiles(self.mod_path .. "/loc/")) do
			local str = filename:match('^(.*).json$')
			if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
				default_lang = str
				break
			end
		end

		WolfTabStats.settings = {
			LANGUAGE 								= default_lang,
			TabStats = {
				ENABLED									= true,
				CLOCK_MODE								= 3,		-- 1 = disabled, 2 = 12h, 3 = 24h
				COLOR		 							= "rainbow",
				FONT_SIZE		 						= 18,
				SHOW_MASK								= true,
				SHOW_LOOT_NUMBERS						= true,
			},
			CrewLoadout = {
				REPLACE_IN_BRIEFING 					= true,
				SHOW_IN_LOBBY							= true,
				SHOW_IN_CS_LOBBY 						= true,
				SHOW_ON_STATS_PANEL						= true,
				REPLACE_PROFILE_MENU                    = true,
				ENABLE_PEER_PING                        = true,
			}
		}
	end

	function WolfTabStats:print_log(...)
		local LOG_MODES = self:getTweakEntry("LOG_MODE", "table", {})
		local params = {...}
		local msg_type, text = table.remove(params, #params), table.remove(params, 1)
		if msg_type and LOG_MODES[tostring(msg_type)] then
			if type(text) == "table" or type(text) == "userdata" then
				local function log_table(userdata)
					local text = ""
					for id, data in pairs(userdata) do
						if type(data) == "table" then
							log( id .. " = {")
							log_table(data)
							log("}")
						elseif type(data) ~= "function" then
							log( id .. " = " .. tostring(data) .. "")
						else
							log( "function " .. id .. "(...)")
						end
					end
				end
				if not text[1] or type(text[1]) ~= "string" then
					log(string.format("[WolfTabStats] %s:", string.upper(type(msg_type))))
					log_table(text)
					return
				else
					text = string.format(unpack(text))
				end
			elseif type(text) == "function" then
				msg_type = "error"
				text = "Cannot log function... "
			elseif type(text) == "string" then
				text = string.format(text, unpack(params or {}))
			end
			text = string.format("[WolfTabStats] %s: %s", string.upper(msg_type), text)
			log(text)
			if LOG_MODES.to_console and con and con.print and con.error then
				local t = Application:time()
				text = string.format("%02d:%06.3f\t>\t%s", math.floor(t/60), t%60, text)
				if tostring(msg_type) == "info" then
					con:print(text)
				else
					con:error(text)
				end
			end
		end
	end

	function WolfTabStats:Load()
		local corrupted = false
		local file = io.open(self.settings_path, "r")
		if file then
			local function parse_settings(table_dst, table_src, setting_path)
				for k, v in pairs(table_src) do
					if type(table_dst[k]) == type(v) then
						if type(v) == "table" then
							table.insert(setting_path, k)
							parse_settings(table_dst[k], v, setting_path)
							table.remove(setting_path, #setting_path)
						else
							table_dst[k] = v
						end
					else
						self:print_log("Error while loading, Setting types don't match (%s->%s)", self:SafeTableConcat(setting_path, "->") or "", k or "N/A", "error")
						corrupted = corrupted or true
					end
				end
			end

			local settings = json.decode(file:read("*all"))
			parse_settings(self.settings, settings, {})
			file:close()
		else
			self:print_log("Error while loading, settings file could not be opened (" .. self.settings_path .. ")", "error")
		end
		if corrupted then
			self:Save()
			self:print_log("Settings file appears to be corrupted, resaving...", "error")
		end
	end

	function WolfTabStats:Save()
		if table.size(self.settings or {}) > 0 then
			local file = io.open(self.settings_path, "w+")
			if file then
				file:write(json.encode(self.settings))
				file:close()
			else
				self:print_log("Error while saving, settings file could not be opened (" .. self.settings_path .. ")", "error")
			end
		else
			self:print_log("Error while saving, settings table appears to be empty...", "error")
		end
	end

	function WolfTabStats:createDirectory(path)
		local current = ""
		path = Application:nice_path(path, true):gsub("\\", "/")

		for folder in string.gmatch(path, "([^/]*)/") do
			current = Application:nice_path(current .. folder, true)

			if not self:DirectoryExists(current) then
				if SystemFS and SystemFS.make_dir then
					SystemFS:make_dir(current)
				elseif file and file.CreateDirectory then
					file.CreateDirectory(current)
				end
			end
		end

		return self:DirectoryExists(path)
	end

	function WolfTabStats:DirectoryExists(path)
		if SystemFS and SystemFS.exists then
			return SystemFS:exists(path)
		elseif file and file.DirectoryExists then
			log("")	-- For some weird reason the function below always returns true if we don't log anything previously...
			return file.DirectoryExists(path)
		end
	end

	function WolfTabStats:getVersion()
	end

	function WolfTabStats:SafeTableConcat(tbl, str)
		local res
		for i = 1, #tbl do
			local val = tbl[i] and tostring(tbl[i]) or "[nil]"
			res = res and res .. str .. val or val
		end
		return res
	end

	function WolfTabStats:getSetting(id_table, default)
		if type(id_table) == "table" then
			local entry = self.settings
			for i = 1, #id_table do
				entry = entry[id_table[i]]
				if entry == nil then
					self:print_log("Requested setting doesn't exists!  (id='" .. self:SafeTableConcat(id_table, "->") .. "', type='" .. (default and type(default) or "n/a") .. "') ", "error")
					return default
				end
			end
			return entry
		end
		return default
	end

	function WolfTabStats:setSetting(id_table, value)
		local entry = self.settings
		for i = 1, (#id_table-1) do
			entry = entry[id_table[i]]
			if entry == nil then
				return false
			end
		end

		if type(entry[id_table[#id_table]]) == type(value) then
			entry[id_table[#id_table]] = value
			return true
		end
	end

	function WolfTabStats:getColorSetting(id_table, default, ...)
		local color_name = self:getSetting(id_table, default)
		return self:getColor(color_name, ...) or default and self:getColor(default, ...)
	end

	function WolfTabStats:getColorID(name)
		if self.tweak_data and type(name) == "string" then
			for i, data in ipairs(self:getTweakEntry("color_table", "table")) do
				if name == data.name then
					return i
				end
			end
		end
	end

	function WolfTabStats:getColor(name, ...)
		if self.tweak_data and type(name) == "string" then
			for i, data in ipairs(self:getTweakEntry("color_table", "table")) do
				if name == data.name then
					return data.color and Color(data.color) or data.color_func and data.color_func(...) or nil
				end
			end
		end
	end

	function WolfTabStats:getTweakEntry(id, val_type, default)
		local value = self.tweak_data[id]
		if value ~= nil and (not val_type or type(value) == val_type) then
			return value
		else
			if default == nil then
				if val_type == "number" then -- Try to prevent crash by giving default value
					default = 1
				elseif val_type == "boolean" then
					default = false
				elseif val_type == "string" then
					default = ""
				elseif val_type == "table" then
					default = {}
				end
			end
			self.tweak_data[id] = default
			self:print_log("Requested tweak_entry doesn't exists!  (id='" .. id .. "', type='" .. tostring(val_type) .. "') ", "error")
			return default
		end
	end

	if not WolfTabStats.tweak_path then		-- Populate tweak data
		local tweak_path = string.format("%s%s", WolfTabStats.save_path, WolfTabStats.tweak_file)
		if not io.file_is_readable(tweak_path) then
			tweak_path = string.format("%s%s", WolfTabStats.mod_path, WolfTabStats.tweak_file)
		end
		if io.file_is_readable(tweak_path) then
			dofile(tweak_path)
			WolfTabStats.tweak_data = WolfHUDTweakDataTabStats:new()
		else
			WolfTabStats:print_log(string.format("Tweak Data file couldn't be found! (%s)", tweak_path), "error")
		end
	end

	-- Table with all menu IDs
	WolfTabStats.menu_ids = WolfTabStats.menu_ids or {}

	--callback functions to apply changed settings on the fly
	if not WolfTabStats.apply_settings_clbk then
		WolfTabStats.apply_settings_clbk = {
			["TabStats"] = function(setting, value)
				if managers.hud and managers.hud.change_tabstats_setting then
					managers.hud:change_tabstats_setting(tostring(setting[#setting]), value)
				end
			end
		}
	end

	if not WolfTabStats:DirectoryExists(WolfTabStats.assets_path) then
		WolfTabStats:print_log("Folder '%s' doesn't exist, creating....\t%s", WolfTabStats.assets_path, tostring(WolfTabStats:createDirectory(WolfTabStats.assets_path)), "warining")
	end

	WolfTabStats:Reset()	-- Populate settings table
	WolfTabStats:Load()	-- Load user settings

	-- Create Ingame Menus
	do
		dofile(WolfTabStats.mod_path .. "OptionMenus.lua")	-- Menu structure table in seperate file, in order to not bloat the Core file too much.
		local menu_options = WolfTabStats.options_menu_data

		-- Setup and register option menus
		Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_WolfHUD", function( menu_manager, nodes )
			local function create_menu(menu_table, parent_id)
				for i, data in ipairs(menu_table) do
					if data.type == "menu" then
						MenuHelper:NewMenu( data.menu_id )
						create_menu(data.options, data.menu_id)
					end
				end
			end

			create_menu({menu_options}, BLT and BLT.Mods.Constants:LuaModOptionsMenuID() or "blt_options")
		end)

		--Populate options menus
		Hooks:Add("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_WolfHUD", function(menu_manager, nodes)
			-- Called on setting change
			local function change_setting(setting, value)
				if WolfTabStats:getSetting(setting, nil) ~= value and WolfTabStats:setSetting(setting, value) then
					WolfTabStats:print_log(string.format("Change setting: %s = %s", WolfTabStats:SafeTableConcat(setting, "->"), tostring(value)), "info")	-- Change type back!
					WolfTabStats.settings_changed = true

					local script = table.remove(setting, 1)
					if WolfTabStats.apply_settings_clbk[script] then
						WolfTabStats.apply_settings_clbk[script](setting, value)
					end
				end
			end

			local function add_visible_reqs(menu_id, id, data)
				local visual_clbk_id = id .. "_visible_clbk"
				local enabled_clbk_id = id .. "_enabled_clbk"

				--Add visual callback
				MenuCallbackHandler[visual_clbk_id] = function(self, item)
					for _, req in ipairs(data.visible_reqs or {}) do
						if type(req) == "table" then
							local a = WolfTabStats:getSetting(req.setting, nil)
							if req.equal then
								if a ~= req.equal then
									return false
								end
							elseif type(a) == "boolean" then
								local b = req.invert and true or false
								if a == b then
									return false
								end
							elseif type(a) == "number" then
								local min_value = req.min or a
								local max_value = req.max or a
								if a < min_value or a > max_value then
									return false
								end
							end
						elseif type(req) == "boolean" then
							return req
						end
					end
					return true
				end

				--Add enable callback
				MenuCallbackHandler[enabled_clbk_id] = function(self, item)
					for _, req in ipairs(data.enabled_reqs or {}) do
						if type(req) == "table" then
							local a = WolfTabStats:getSetting(req.setting, nil)
							if req.equal then
								if a ~= req.equal then
									return false
								end
							elseif type(a) == "boolean" then
								local b = req.invert and true or false
								if a == b then
									return false
								end
							elseif type(a) == "number" then
								local min_value = req.min or a
								local max_value = req.max or a
								if a < min_value or a > max_value then
									return false
								end
							end
						elseif type(req) == "boolean" then
							return req
						end
					end
					return true
				end

				--Associate visual callback with item
				local menu = MenuHelper:GetMenu(menu_id)
				for i, item in pairs(menu._items_list) do
					if item:parameters().name == id then
						item._visible_callback_name_list = { visual_clbk_id }
						item._enabled_callback_name_list = { enabled_clbk_id }
						item._create_data = data
						break
					end
				end
			end

			-- Reapply enabled state on all items in the same menu
			local update_visible_clbks = "wolfhud_update_visibility"
			MenuCallbackHandler[update_visible_clbks] = function(self, item)
				local gui_node = item:parameters().gui_node
				if gui_node then
					if item._type ~= "slider" then
						gui_node:refresh_gui(gui_node.node)
						gui_node:highlight_item(item, true)
					end

					for _, row_item in pairs(gui_node.row_items) do
						local option_item = row_item.item
						if option_item._type ~= "divider" and option_item:parameters().name ~= item:parameters().name then
							local enabled = true

							for _, clbk in ipairs(option_item._enabled_callback_name_list or {}) do
								enabled = enabled and self[clbk](self, option_item)
							end

							option_item:set_enabled(enabled)

							gui_node:reload_item(option_item)
						end
					end
				end
			end

			-- item create functions by type
			local create_item_handlers = {
				menu = function(parent_id, offset, data)
					if not table.contains(WolfTabStats.menu_ids, data.menu_id) then
						table.insert(WolfTabStats.menu_ids, data.menu_id)
					end
				end,
				slider = function(menu_id, offset, data, value)
					local id = string.format("%s_%s_slider", menu_id, data.name_id)
					local clbk_id = id .. "_clbk"

					MenuHelper:AddSlider({
						id = id,
						title = data.name_id,
						desc = data.desc_id,
						callback = string.format("%s %s", clbk_id, update_visible_clbks),
						value = value or 0,
						min = data.min_value,
						max = data.max_value,
						step = data.step_size,
						show_value = true,
						menu_id = menu_id,
						priority = offset,
						disabled_color = Color(0.6, 0.6, 0.6),
					})

					--Value changed callback
					MenuCallbackHandler[clbk_id] = function(self, item)
						change_setting(clone(data.value), item:value())
					end

					if data.visible_reqs or data.enabled_reqs then
						add_visible_reqs(menu_id, id, data)
					end
				end,
				toggle = function(menu_id, offset, data, value)
					local id = string.format("%s_%s_toggle", menu_id, data.name_id)
					local clbk_id = id .. "_clbk"

					if data.invert_value then
						value = not value
					end

					MenuHelper:AddToggle({
						id = id,
						title = data.name_id,
						desc = data.desc_id,
						callback = string.format("%s %s", clbk_id, update_visible_clbks),
						value = value or false,
						menu_id = menu_id,
						priority = offset,
						disabled_color = Color(0.6, 0.6, 0.6),
					})

					--Add visual callback
					MenuCallbackHandler[clbk_id] = function(self, item)
						local value = (item:value() == "on") and true or false

						if data.invert_value then
							value = not value
						end

						change_setting(clone(data.value), value)
					end

					if data.visible_reqs or data.enabled_reqs then
						add_visible_reqs(menu_id, id, data)
					end
				end,
				multi_choice = function(menu_id, offset, data, value)
					local id = string.format("%s_%s_multi", menu_id, data.name_id)
					local clbk_id = id .. "_clbk"

					local multi_data = {
						id = id,
						title = data.name_id,
						desc = data.desc_id,
						callback = string.format("%s %s", clbk_id, update_visible_clbks),
						items = data.options,
						value = value,
						menu_id = menu_id,
						priority = offset,
						disabled_color = Color(0.6, 0.6, 0.6),
					}

					do	-- Copy of MenuHelper:AddMultipleChoice (Without ipairs for options)
						local data = {
							type = "MenuItemMultiChoice"
						}
						for k, v in pairs( multi_data.items or {} ) do
							table.insert( data, { _meta = "option", text_id = v, value = k } )
						end

						local params = {
							name = multi_data.id,
							text_id = multi_data.title,
							help_id = multi_data.desc,
							callback = multi_data.callback,
							filter = true,
							localize = multi_data.localized,
						}

						local menu = MenuHelper:GetMenu( multi_data.menu_id )
						local item = menu:create_item(data, params)
						item._priority = multi_data.priority
						item:set_value( multi_data.value or 1 )

						if multi_data.disabled then
							item:set_enabled( not multi_data.disabled )
						end

						menu._items_list = menu._items_list or {}
						table.insert( menu._items_list, item )
					end

					MenuCallbackHandler[clbk_id] = function(self, item)
						change_setting(clone(data.value), item:value())
					end

					if data.add_color_options then
						local menu = MenuHelper:GetMenu(menu_id)
						for i, item in pairs(menu._items_list) do
							if item:parameters().name == id then
								item:clear_options()
								for k, v in ipairs(WolfTabStats:getTweakEntry("color_table", "table") or {}) do
									if data.add_rainbow or v.name ~= "rainbow" then
										local color_name = managers.localization:text("wolfhud_colors_" .. v.name)
										color_name = not color_name:lower():find("error") and color_name or string.upper(v.name)
										local params = {
											_meta = "option",
											text_id = color_name,
											value = v.name,
											localize = false,
											color = Color(v.color),
										}
										if v.name == "rainbow" then
											local rainbow_colors = { Color('FE0E31'), Color('FB9413'), Color('F7F90F'), Color('3BC529'), Color('00FFFF'), Color('475DE7'), Color('B444E4'), Color('F46FE6') }
											params.color = rainbow_colors[1]
											for i = 0, color_name:len() do
												params["color" .. i] = rainbow_colors[(i % #rainbow_colors) + 1]
												params["color_start" .. i] = i
												params["color_stop" .. i] = i + 1
											end
										end

										item:add_option(CoreMenuItemOption.ItemOption:new(params))
									end
								end
								item:_show_options(nil)
								item:set_value(value)
								for __, clbk in pairs( item:parameters().callback ) do
									clbk(item)
								end
								break
							end
						end
					end

					if data.visible_reqs or data.enabled_reqs then
						add_visible_reqs(menu_id, id, data)
					end
				end,
				input = function(menu_id, offset, data)
					local id = string.format("%s_%s_input", menu_id, data.name_id)
					local clbk_id = id .. "_clbk"

					MenuHelper:AddInput({
						id = id,
						title = data.name_id,
						desc = data.desc_id,
						value = tostring(data.value),
						callback = clbk_id,
						menu_id = menu_id,
						priority = offset,
						disabled_color = Color(0.6, 0.6, 0.6),
					})

					MenuCallbackHandler[clbk_id] = function(self, item)
						change_setting(clone(data.value), item:value())
					end

					if data.visible_reqs or data.enabled_reqs then
						add_visible_reqs(menu_id, id, data)
					end
				end,
				button = function(menu_id, offset, data)
					local id = string.format("%s_%s_button", menu_id, data.name_id)
					local clbk_id = data.clbk or (id .. "_clbk")

					MenuHelper:AddButton({
						id = id,
						title = data.name_id,
						desc = data.desc_id,
						callback = clbk_id,
						menu_id = menu_id,
						priority = offset,
						disabled_color = Color(0.6, 0.6, 0.6),
					})

					MenuCallbackHandler[clbk_id] = MenuCallbackHandler[clbk_id] or function(self, item)

					end

					if data.visible_reqs or data.enabled_reqs then
						add_visible_reqs(menu_id, id, data)
					end
				end,
				keybind = function(menu_id, offset, data)
					local id = string.format("%s_%s_keybind", menu_id, data.name_id)
					local clbk_id = data.clbk or (id .. "_clbk")

					MenuHelper:AddKeybinding({
						id = id,
						title = data.name_id,
						desc = data.desc_id,
						connection_name = "",
						binding = "",
						button = "",
						callback = clbk_id,
						menu_id = menu_id,
						priority = offset,
						--disabled_color = Color(0.6, 0.6, 0.6),
					})

					MenuCallbackHandler[clbk_id] = MenuCallbackHandler[clbk_id] or function(self, item)

					end

					if data.visible_reqs or data.enabled_reqs then
						add_visible_reqs(menu_id, id, data)
					end
				end,
				divider = function(menu_id, offset, data)
					local id = string.format("%s_divider_%d", menu_id, offset)

					local item_data = {
						type = "MenuItemDivider"
					}
					local params = {
						name = id,
						no_text = not data.text_id,
						text_id = data.text_id,
						localize = "true",
						size = data.size or 8,
						color = tweak_data.screen_colors.text
					}

					local menu = MenuHelper:GetMenu( menu_id )
					local item = menu:create_item( item_data, params )
					item._priority = offset or 0
					menu._items_list = menu._items_list or {}
					table.insert( menu._items_list, item )
				end,
			}

			-- Populate Menus with their menu items
			local function populate_menu(menu_table, parent_id)
				local item_amount = #menu_table
				for i, data in ipairs(menu_table) do
					local value = data.value and WolfTabStats:getSetting(data.value, nil)
					create_item_handlers[data.type](data.parent_id or parent_id, item_amount - i, data, value)

					if data.type == "menu" then
						populate_menu(data.options, data.menu_id)
					end
				end
			end

			populate_menu({menu_options}, BLT and BLT.Mods.Constants:LuaModOptionsMenuID() or "blt_options")
		end)

		-- Create callbacks and finalize menus
		Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_WolfHUD", function(menu_manager, nodes)
			local back_clbk = "wolfhud_back_clbk"
			local focus_clbk = "wolfhud_focus_clbk"
			local reset_clbk = "wolfhud_reset_clbk"

			-- Add menu back callback
			MenuCallbackHandler[back_clbk] = function(node)
				if WolfTabStats.settings_changed then
					WolfTabStats.settings_changed = nil
					WolfTabStats:Save()
					WolfTabStats:print_log("Settings saved!", "info")
				end
			end

			-- Add focus callback
			MenuCallbackHandler[focus_clbk] = function(node, focus)
				if focus then
					for _, option_item in pairs(node._items) do
						if option_item._type ~= "divider" then
							local enabled = true

							for _, clbk in ipairs(option_item._enabled_callback_name_list or {}) do
								enabled = enabled and MenuCallbackHandler[clbk](node.callback_handler, option_item)
							end

							option_item:set_enabled(enabled)
						end
					end
				end
			end

			-- Add reset menu items callback
			MenuCallbackHandler[reset_clbk] = function(self, item)
				local menu_title = managers.localization:text("wolfhud_reset_options_title")
				local menu_message = managers.localization:text("wolfhud_reset_options_confirm")
				local menu_buttons = {
					[1] = {
						text = managers.localization:text("dialog_yes"),
						callback = function(self, item)
							WolfTabStats:Reset()

							for i, menu_id in ipairs(WolfTabStats.menu_ids) do
								local menu = MenuHelper:GetMenu(menu_id)
								if menu then
									for __, menu_item in ipairs(menu._items_list) do
										local setting = menu_item._create_data and clone(menu_item._create_data.value)
										if menu_item.set_value and setting then
											local value = WolfTabStats:getSetting(setting, nil)
											if value ~= nil then
												local script = table.remove(setting, 1)
												if WolfTabStats.apply_settings_clbk[script] then
													WolfTabStats.apply_settings_clbk[script](setting, value)
												end

												if menu_item._type == "toggle" then
													if menu_item._create_data.invert_value then
														value = not value
													end
													value = (value and "on" or "off")
												end

												menu_item:set_value(value)
											end
										end
									end
								end
							end
							managers.viewport:resolution_changed()

							WolfTabStats.settings_changed = true
							WolfTabStats:print_log("Settings resetted!", "info")
						end,
					},
					[2] = {
						text = managers.localization:text("dialog_no"),
						is_cancel_button = true,
					},
				}
				QuickMenu:new( menu_title, menu_message, menu_buttons, true )
			end

			-- Build Menus and add a button to parent menu
			local function finalize_menu(menu_table, parent_id)
				for i, data in ipairs(menu_table) do
					if data.type == "menu" then
						nodes[data.menu_id] = MenuHelper:BuildMenu(data.menu_id, { back_callback = back_clbk, focus_changed_callback = focus_clbk })
						MenuHelper:AddMenuItem(
							nodes[data.parent_id or parent_id],
							data.menu_id,
							data.name_id,
							data.desc_id,
							data.position or i
						)

						finalize_menu(data.options, data.menu_id)
					end
				end
			end

			finalize_menu({menu_options}, BLT and BLT.Mods.Constants:LuaModOptionsMenuID() or "blt_options")
		end)
	end

	--Add localization strings
	Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_WolfHUD", function(loc)
        local loc_path = WolfTabStats.mod_path .. "loc/"
		if file.DirectoryExists( loc_path ) then
			loc:load_localization_file(string.format("%s/%s.json", loc_path, WolfTabStats:getSetting({"LANGUAGE"}, "english")))
			loc:load_localization_file(string.format("%s/english.json", loc_path), false)
		else
			WolfTabStats:print_log("Localization folder seems to be missing!", "error")
		end
	end)
end
