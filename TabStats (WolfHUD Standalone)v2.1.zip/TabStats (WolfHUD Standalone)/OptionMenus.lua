if WolfTabStats then
	-- Actual Menu Data table
	WolfTabStats.options_menu_data = {
		type = "menu",
		menu_id = "wolfhudtabstats_main_options_menu",
		--parent_id = "blt_options",
		name_id = "wolfhudtabstats_options_name",
		desc_id = "wolfhudtabstats_options_help",
		position = 3,
		options = {
			{
				type = "multi_choice",
				name_id = "wolfhudtabstats_language_title",
				desc_id = "wolfhudtabstats_language_desc",
				options = {
					["english"] = "wolfhudtabstats_languages_english",
					["german"] = "wolfhudtabstats_languages_german",
					["dutch"] = "wolfhudtabstats_languages_dutch",
					["french"] = "wolfhudtabstats_languages_french",
					["italian"] = "wolfhudtabstats_languages_italian",
					["spanish"] = "wolfhudtabstats_languages_spanish",
					["portuguese"] = "wolfhudtabstats_languages_portuguese",
					["russian"] = "wolfhudtabstats_languages_russian",
					["chinese"] = "wolfhudtabstats_languages_chinese",
					["korean"] = "wolfhudtabstats_languages_korean"
				},
				visible_reqs = {},
				enabled_reqs = {},
				value = {"LANGUAGE"},
			},
			{
				type ="divider",
				size = 8,
			},
			{ --TabStats
				type = "menu",
				menu_id = "wolfhudtabstats_tabstats_options_menu",
				name_id = "wolfhudtabstats_tabstats_options_name",
				desc_id = "wolfhudtabstats_tabstats_options_help",
				options = {
					{
						type = "multi_choice",
						name_id = "wolfhudtabstats_tabstats_clock_mode_title",
						desc_id = "wolfhudtabstats_tabstats_clock_mode_desc",
						options = {
							"wolfhudtabstats_multiselect_disabled",
							"wolfhudtabstats_tabstats_clock_mode_a",
							"wolfhudtabstats_tabstats_clock_mode_b",
							"wolfhudtabstats_tabstats_clock_mode_c"
						},
						visible_reqs = {}, enabled_reqs = {},
						value = {"TabStats", "CLOCK_MODE"},
					},
					{
						type = "divider",
						size = 16,
					},
					{
						type = "toggle",
						name_id = "wolfhudtabstats_use_tabstats_title",
						desc_id = "wolfhudtabstats_use_tabstats_desc",
						value = {"TabStats", "ENABLED"},
						visible_reqs = {}, enabled_reqs = {},
					},
					{
						type = "slider",
						name_id = "wolfhudtabstats_tabstats_font_size_title",
						desc_id = "wolfhudtabstats_tabstats_font_size_desc",
						value = {"TabStats", "FONT_SIZE"},
						visible_reqs = {},
						enabled_reqs = {
							{ setting = { "TabStats", "ENABLED" }, invert = false },
						},
						min_value = 10,
						max_value = 24,
						step_size = 1,
					},
					{
						type = "multi_choice",
						name_id = "wolfhudtabstats_tabstats_color_title",
						desc_id = "wolfhudtabstats_tabstats_color_desc",
						value = {"TabStats", "COLOR"},
						visible_reqs = {},
						enabled_reqs = {
							{ setting = { "TabStats", "ENABLED" }, invert = false },
						},
						options = {},
						add_color_options = true,
						add_rainbow = true,
					},
					{
						type = "toggle",
						name_id = "wolfhudtabstats_tabstats_actual_mask_title",
						desc_id = "wolfhudtabstats_tabstats_actual_mask_desc",
						value = {"TabStats", "SHOW_MASK"},
						visible_reqs = {},
						enabled_reqs = {
							{ setting = { "TabStats", "ENABLED" }, inverted = false }
						},
					},
				},
			},
			{ --CrewLoadout
				type = "menu",
				menu_id = "wolfhudtabstats_crewloadout_options_menu",
				name_id = "wolfhudtabstats_crewloadout_options_name",
				desc_id = "wolfhudtabstats_crewloadout_options_help",
				options = {
					{
						type = "toggle",
						name_id = "wolfhudtabstats_crewloadout_lobby_title",
						desc_id = "wolfhudtabstats_crewloadout_lobby_desc",
						value = {"CrewLoadout", "SHOW_IN_LOBBY"},
						visible_reqs = {}, enabled_reqs = {},
					},
					{
						type = "toggle",
						name_id = "wolfhudtabstats_crewloadout_cs_lobby_title",
						desc_id = "wolfhudtabstats_crewloadout_cs_lobby_desc",
						value = {"CrewLoadout", "SHOW_IN_CS_LOBBY"},
						visible_reqs = {}, enabled_reqs = {},
					},
					{
						type = "divider",
						size = 16,
					},
					{
						type = "toggle",
						name_id = "wolfhudtabstats_crewloadout_briefing_title",
						desc_id = "wolfhudtabstats_crewloadout_briefing_desc",
						value = {"CrewLoadout", "REPLACE_IN_BRIEFING"},
						visible_reqs = {}, enabled_reqs = {},
					},
					{
						type = "divider",
						size = 16,
					},
					{
						type = "toggle",
						name_id = "wolfhudtabstats_crewloadout_tabscreen_title",
						desc_id = "wolfhudtabstats_crewloadout_tabscreen_desc",
						value = {"CrewLoadout", "SHOW_ON_STATS_PANEL"},
						visible_reqs = {}, enabled_reqs = {},
					},
					{
						type = "toggle",
						name_id = "wolfhud_enable_peer_ping_title",
						desc_id = "wolfhud_enable_peer_ping_desc",
						value = {"CrewLoadout", "ENABLE_PEER_PING"},
						visible_reqs = {}, enabled_reqs = {},
					},
				},
			},
			
		},
	}
end
