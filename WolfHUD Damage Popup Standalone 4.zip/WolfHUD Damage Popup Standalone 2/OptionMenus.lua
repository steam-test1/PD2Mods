if WolfHUDDmgPop then
	-- Actual Menu Data table
	WolfHUDDmgPop.options_menu_data = {
		type = "menu",
		menu_id = "WolfHUDDmgPop_main_options_menu",
		--parent_id = "blt_options",
		name_id = "WolfHUDDmgPop_options_name",
		desc_id = "WolfHUDDmgPop_options_help",
		position = 3,
		options = {
			{
				type = "multi_choice",
				name_id = "wolfhud_language_title",
				desc_id = "wolfhud_language_desc",
				options = {
					["english"] = "wolfhud_languages_english",
					["german"] = "wolfhud_languages_german",
					["dutch"] = "wolfhud_languages_dutch",
					["french"] = "wolfhud_languages_french",
					["italian"] = "wolfhud_languages_italian",
					["spanish"] = "wolfhud_languages_spanish",
					["portuguese"] = "wolfhud_languages_portuguese",
					["russian"] = "wolfhud_languages_russian",
					["chinese"] = "wolfhud_languages_chinese",
					["korean"] = "wolfhud_languages_korean"
				},
				visible_reqs = {},
				enabled_reqs = {},
				value = {"LANGUAGE"},
			},
			{
				type = "divider",
				size = 12,
			},
			{
				type = "multi_choice",
				name_id = "wolfhud_show_dmg_popup_title",
				desc_id = "wolfhud_show_dmg_popup_desc",
				value = {"DamagePopup", "DISPLAY_MODE"},
				visible_reqs = {}, enabled_reqs = {},
				options = {
					"wolfhud_multiselect_disabled",
					"wolfhud_dmg_popup_player",
					"wolfhud_dmg_popup_all"
				},
			},
			{
				type = "slider",
				name_id = "wolfhud_dmg_popup_scale_title",
				desc_id = "wolfhud_dmg_popup_scale_desc",
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2 },
				},
				value = {"DamagePopup", "SCALE"},
				min_value = 0.1,
				max_value = 3,
				step_size = 0.1,
			},
			{
				type = "slider",
				name_id = "wolfhud_dmg_popup_skull_scale_title",
				desc_id = "wolfhud_dmg_popup_skull_scale_desc",
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2 },
				},
				value = {"DamagePopup", "SKULL_SCALE"},
				min_value = 0.1,
				max_value = 3,
				step_size = 0.1,
			},
			{
				type = "multi_choice",
				name_id = "wolfhud_dmg_popup_skull_align_title",
				desc_id = "wolfhud_dmg_popup_skull_align_desc",
				value = {"DamagePopup", "SKULL_ALIGN"},
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2 },
				},
				options = {
					"wolfhud_multiselect_left",
					"wolfhud_multiselect_right"
				},
			},
			{
				type = "slider",
				name_id = "wolfhud_dmg_popup_time_title",
				desc_id = "wolfhud_dmg_popup_time_desc",
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2 },
				},
				value = {"DamagePopup", "DURATION"},
				min_value = 0.1,
				max_value = 20,
				step_size = 0.1,
			},
			{
				type = "slider",
				name_id = "wolfhud_dmg_popup_height_title",
				desc_id = "wolfhud_dmg_popup_height_desc",
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2 },
				},
				value = {"DamagePopup", "HEIGHT"},
				min_value = 0,
				max_value = 500,
				step_size = 10,
			},
			{
				type = "slider",
				name_id = "wolfhud_dmg_popup_alpha_title",
				desc_id = "wolfhud_dmg_popup_alpha_desc",
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2 },
				},
				value = {"DamagePopup", "ALPHA"},
				min_value = 0,
				max_value = 1,
				step_size = 0.05,
			},
			{
				type = "multi_choice",
				name_id = "wolfhud_dmg_popup_color_title",
				desc_id = "wolfhud_dmg_popup_color_desc",
				value = {"DamagePopup", "COLOR"},
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2, max = 2 },
				},
				options = {},
				add_color_options = true,
				add_rainbow = false,
			},
			{
				type = "multi_choice",
				name_id = "wolfhud_dmg_popup_critical_color_title",
				desc_id = "wolfhud_dmg_popup_critical_color_desc",
				value = {"DamagePopup", "CRITICAL_COLOR"},
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2, max = 2 },
				},
				options = {},
				add_color_options = true,
				add_rainbow = false,
			},
			{
				type = "multi_choice",
				name_id = "wolfhud_dmg_popup_headshot_color_title",
				desc_id = "wolfhud_dmg_popup_headshot_color_desc",
				value = {"DamagePopup", "HEADSHOT_COLOR"},
				visible_reqs = {},
				enabled_reqs = {
					{ setting = { "DamagePopup", "DISPLAY_MODE" }, min = 2, max = 2 },
				},
				options = {},
				add_color_options = true,
				add_rainbow = false,
			},
		},
	}
end
