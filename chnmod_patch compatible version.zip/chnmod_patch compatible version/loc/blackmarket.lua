Hooks:Add("LocalizationManagerPostInit", "CHNMOD_PATCH_black", function(loc)
	LocalizationManager:add_localized_strings({
-- ——————————————————————枪械(共406条)——————————————————————
-- —————— 突击步枪
["bm_w_amcar"] = "Colt 727 \"AMCAR\" 卡宾枪",
["bm_w_amcar_desc"] = "5.56mm全自动步枪, 拥有中等精准和威力",
["bm_w_s552"] = "SIG SG552C \"突击手 553\" 短突击步枪",
-- ———— 无描述
["bm_w_scar"] = "FN Mk.17 \"巨鹰\" 战斗步枪",
-- ———— 无描述
["addation_f1fb1add8753f0a5"] = "FN F2000-T \"联盟 5.56\" 突击步枪", 
["addation_bce7c9fe7c8359e0"] = "\"联盟 5.56\"步枪是一把紧凑而高效的无托突击步枪。",
["bm_w_ak74"] = "Izhmash AKS74 \"AK\" 突击步枪",
["bm_w_ak74_desc"] = "5.45mm全自动步枪, 拥有中等射速和精准。",
["bm_w_m4"] = "Colt M4A1 \"CAR-4\" 突击步枪",
["bm_w_m4_desc"] = "5.56mm全自动步枪, 拥有优秀的操控性和精准。",
["bm_w_aug"] = "Steyr AUG A2 \"UAR\" 突击步枪",
["bm_w_aug_desc"] = ".45ACP自动手枪, 中等的停止力但携弹量低。", -- ———— 手枪？
["bm_w_sub2000"] = "K-T SUB2000 \"龋齿 9mm\" 卡宾枪",
["bm_w_sub2000_desc"] = "便携性和隐蔽性极高的武器。可以对折以储存和运输。如此小的体积，伤害却极为可观———这也是它名字的由来。",
["bm_w_akm"] = "Izhmash AKMS \"AK.762\" 突击步枪",
["bm_w_akm_desc"] = "7.62mm全自动步枪，高伤害但低射速。", -- ———— 可能有缺字
["bm_w_g36"] = "H&K G36KV \"JP36\" 突击步枪",
["bm_w_g36_desc"] = "5.56mm全自动步枪，拥有中等伤害和低子弹扩散。",
["addation_f1157fb5d12a0c76"] = "Izhmash AK12 \"AK17\" 突击步枪", 
["addation_d0e5719952c8085f"] = "Izhmash AK12 \"AK17\" 突击步枪。", -- ———— 重复文本，可能是描述？
["bm_w_akm_gold"] = "Izhmash AKMS 黄金 \"AK.762\" 突击步枪",
-- ———— 无描述，可能和AK.762共用同一描述
["addation_5a4d56a8d880f953"] = "H&K HK416C \"私录碟\" 短突击步枪", 
-- ———— 无描述
["bm_w_l85a2"] = "Enfield L85A2 \"女王之怒\" 突击步枪",
-- ———— 无描述
["addation_8fcf6a75175e9f25"] = "M1 Garand \"加兰特\" 步枪", 
["addation_516170b71d2ea0f6"] = "加兰德步枪太棒了。", 
["bm_w_m14"] = "Springfield M1A \"M308\" 战斗步枪",
["bm_w_m14_desc"] = "使用.308温彻斯特步枪弹的半自动步枪，拥有高威力和高后座。",
["bm_w_famas"] = "FAMAS F1 \"号角\" 突击步枪",
-- ———— 无描述
["bm_w_vhs"] = "HS Produkt VHS-D2 \"狮吼\" 突击步枪",
-- ———— 无描述
["bm_w_asval"] = "TsNII AS Val \"瓦尔基里\" 突击步枪",
["bm_w_asval_desc"] = "\"瓦尔基里\"(女武神)听起来就像是上帝的玩具。但事实上它并不发出什么声音———这得归功于它的亚音速子弹和自带的消音器。",
["bm_w_ak5"] = "Bofors AK5 \"AK5\" 突击步枪",
["bm_w_ak5_desc"] = "5.56mm全自动步枪，拥有充足的携弹量，中等的后坐力。",
["bm_w_galil"] = "Galil ARM 7.62 \"壁虎 7.62\" 突击步枪",
-- ———— 无描述
["addation_5dfe025d9d2a2d1e"] = "Tavor X95 \"风暴-21\" 突击步枪", 
["addation_c65d8cce401f7cfc"] = "突击步枪中的火爆浪子。", 
["bm_w_m16"] = "Colt M16A4 \"AMR-16\" 突击步枪",
["bm_w_m16_desc"] = "5.56mm全自动步枪，拥有高射速和高威力。",
["addation_ca77cf7158370122"] = "H&K HK417D \"小伙伴 7.62\" 步枪", 
["addation_d85dea953b9ebec9"] = "别忘了向全自动模式的小伙伴问好。", 
["addation_d6da15fc0c52fdf7"] = "别忘了向全自动模式的小伙伴问好。",  -- ———— 为啥小伙伴的描述有俩
["bm_w_fal"] = "DSA SA58 \"飞隼\" 战斗步枪",
-- ———— 无描述
["bm_w_g3"] = "H&K G3A3 \"格威尔 3型\" 战斗步枪",
-- ———— 无描述
["addation_558d9f856648757a"] = "OTs-14-4A \"科迟诺夫 Byk-1\" 突击步枪", 
-- ———— 无描述
["bm_w_shak12"] = "ShAK-12 \"KS12 都市型\" 突击步枪",
-- ———— 无描述

-- —————— 霰弹枪（主手）
["bm_w_spas12"] = "Franchi SPAS-12 \"掠食者 12G\" 霰弹枪",
-- ———— 无描述
["addation_bde9bc2285fd1405"] = "Winchester M1887 \"破坏者 12G\" 霰弹枪", 
-- ———— 无描述
["bm_w_r870"] = "Remington M870 \"赖因费尔德 880\" 霰弹枪",
["bm_w_r870_desc"] = "12号口径泵动式霰弹枪，拥有高威力和中等精度。",
["bm_w_benelli"] = "Benelli M4 \"M1014\" 霰弹枪",
-- ———— 无描述
["bm_w_ksg"] = "Kel-Tec KSG \"渡鸦\" 霰弹枪",
-- ———— 无描述
["bm_w_saiga"] = "Saiga-12K \"一字马 12G\" 霰弹枪", -- ———— 英文IZHMA是neta的IZHMASH(伊茨玛希)公司，因此这条实际上应该改成\"伊茨玛\"，不过算了
["bm_w_saiga_desc"] = "12号口径全自动霰弹枪，拥有中等射速，高停止力。",
["addation_a5230e0dfa82cc78"] = "Winchester M1897 \"赖因费尔德 88\" 霰弹枪", 
-- ———— 无描述
["bm_w_huntsman"] = "Stoeger/IGA \"莫斯科尼 12G\" 霰弹枪",
["bm_w_huntsman_desc"] = "12号口径双管霰弹枪，威力很高但携弹量很低。",
["bm_w_b682"] = "Beretta 682 \"乔斯林 O/U 12G\" 霰弹枪",
-- ———— 无描述
["bm_w_aa12"] = "MPS AA-12 \"牛排 12G\" 霰弹枪",
-- ———— 无描述
["addation_a2949d03231b06fa"] = "Mossberg 590 \"莫斯科尼 12G 战术款\" 霰弹枪", 
-- ———— 无描述

-- —————— 轻机枪
["bm_w_rpk"] = "Izhmash RPK \"RPK\" 轻机枪",
-- ———— 无描述
["bm_w_par"] = "FN M240B \"KSP 58\" 轻机枪",
["bm_w_par_desc"] = "来自50年代的好东西。",
["bm_w_m249"] = "FN M249 \"KSP\" 轻机枪",
-- ———— 无描述
["bm_w_mg42"] = "MG42 \"撕布机42\" 轻机枪",
-- ———— 无描述
["bm_w_hk21"] = "H&K HK21E \"火舌 21型\" 轻机枪", -- ———— Brenner为德语中的喷枪
-- ———— 无描述
["addation_f0905938f311a9be"] = "M60E3 \"M60\" 轻机枪", 
-- ———— 无描述

-- —————— 狙击步枪
["bm_w_msr"] = "Remington MSR \"响尾蛇\" 步枪",
["bm_w_msr_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["bm_w_model70"] = "Winchester M70 \"鸭嘴兽 70\" 步枪",
["bm_w_model70_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["bm_w_wa2000"] = "Walther WA2000 \"嗜命者 .308\" 狙击步枪",
["bm_w_wa2000_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["addation_fad640d6375aac07"] = "DT SRS-A1 \"沙漠之狐\" 狙击步枪", 
["bm_w_desertfox_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["addation_97fa1da5248a444c"] = "TTI TR-1 Ultra-light \"合约人 .308\" 步枪", 
["addation_bd0f9647e57c1475"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。", 
["bm_w_r93"] = "Blaser R93 LRS2 \"R93\" 狙击步枪",
["bm_w_r93_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["bm_w_winchester1874"] = "Winchester M1873 \"1873连珠枪\" 杠杆步枪",
["bm_w_winchester1874_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["addation_aa6e3f34fac1d802"] = "Dragunov SVD \"霹雳\" 狙击步枪", 
["addation_6711052ccda5017d"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。", 
["addation_8981385089d4a283"] = "Marlin M1895 SBL \"伯奈特 百步穿杨\" 杠杆步枪", 
["bm_w_sbl_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。", 
["bm_w_mosin"] = "Mosin Nagant M1907 \"纳甘\" 步枪",
["bm_w_mosin_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["bm_w_m95"] = "Barrett M95 \"死神 .50\" 狙击步枪",
["bm_w_m95_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["addation_b48fc9912ea986ee"] = "Remington M700P \"R700\" 狙击步枪", 
["bm_w_r700_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",
["addation_ad4a41b671ddd7dd"] = "Norinco QBU-88 \"工业军工 X1\" 狙击步枪", 
["bm_w_qbu88_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。",

-- —————— 特殊（主手）
["bm_w_saw"] = "OVE9000电锯", -- ————主副手共用
["bm_w_saw_desc"] = "该武器无法拾取弹药。",
["bm_w_plainsrider"] = "大地奇兵猎弓",
["bm_w_plainsrider_desc"] = "这是一把弓。",
["bm_w_frankish"] = "轻弩",
["bm_w_frankish_desc"] = "弩是战场上的规则制定者。它结构简单，制造廉价，威力足以穿透骑士的铠甲。",
["bm_w_long"] = "英格兰长弓",
["bm_w_long_desc"] = "英格兰长弓是原始的杀伤性武器，它能提供来自远程的巨大伤害，在敌方挥剑之前结束战斗。",
["addation_76328f3d46d6e911"] = "XM556 \"XL 5.56\" 微型机枪", 
-- ———— 描述未知
["addation_26e792d7962223b4"] = "G5 Quest Radical \"DECA科技\" 复合弓", 
-- ———— 描述未知
["bm_w_m134"] = "M134 \"火神\" 机枪",
["bm_w_m134_desc"] = "该武器无法拾取弹药。",
["bm_w_arblast"] = "重弩",
["bm_w_arblast_desc"] = "重弩的射速和重量提供了额外的射程和伤害。如同理查德在阿索夫之战的自传体编年史里所描写：“...重弩一进入战场，便操翻了全场。”",
["bm_w_m32"] = "Milkor M32 \"小猪\" 榴弹发射器",
-- ———— 无描述
["bm_w_flamethrower_mk2"] = "火焰喷射器 Mk.1型",
["bm_w_flamethrower_mk2_desc"] = "该武器无法拾取弹药。",
["bm_w_gre_m79"] = "M79 \"GL40\" 榴弹发射器",
-- ———— 无描述
["addation_456879593f55072b"] = "高压气动弩", 
["addation_43d6b5c8e274a71b"] = "半自动气动弩，7102年的最新科技保证让你弹无虚发。", 

-- —————— 手枪（副手）
["bm_w_usp"] = "H&K USP45 Tactical \"拦截者 .45\" 手枪",
-- ———— 无描述
["bm_w_glock_17"] = "Glock 17 \"奇玛诺 88\" 手枪",
["bm_w_glock_17_desc"] = "9mm自动手枪，中等精度、携弹量和威力.",
["bm_w_ppk"] = "Walther PPK/S \"格鲁博 轻便型\" 手枪",
-- ———— 无描述
["bm_w_p226"] = "SIG P226 \"署名 .40\" 手枪", 
-- ———— 无描述
["bm_w_colt_1911"] = "SpringField 1911 \"十字杀\" 手枪",
-- ———— 无描述
["bm_w_b92fs"] = "Beretta 92FS \"伯奈特 9型\" 手枪",
["bm_w_b92fs_desc"] = "9mm自动手枪，有着优秀的精度和中等威力。",
["bm_w_raging_bull"] = "Raging Bull \"野马 .44\" 左轮手枪",
["bm_w_raging_bull_desc"] = ".44马格南左轮，高威力，低携弹量。",
["addation_7e0bd73e98af8d21"] = "Lebedev PL-14 \"白纹\" 手枪", 
-- ———— 无描述
["bm_w_sparrow"] = "Jericho RPL \"沙漠雏鹰\" 手枪",
-- ———— 无描述
["addation_b13c4143c804d40b"] = "H&K P7M13 \"M13 9mm\" 手枪", 
["addation_885b5b9edf2439ca"] = "它太完美了，这才是一把枪该有的制作水准。", 
["bm_w_g22c"] = "Glock 22C \"奇玛诺 定制版\" 手枪",
-- ———— 无描述
["bm_w_c96"] = "Mauser C96 \"扫帚柄\" 手枪",
-- ———— 无描述
["addation_ae1dbb0a5c0351c4"] = "Luger P08 \"巴拉贝鲁姆\" 手枪", -- ———— Parabellum = 巴拉贝鲁姆手枪弹
["addation_5113967b62629e1c"] = "鲁格手枪最棒了。", 
["addation_2ecbbf2d3df6714a"] = "FN Five-seveN \"5/7 AP\" 穿甲手枪", 
["addation_7f9ecc4318575028"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。", 
["addation_286ffd47d441d9b9"] = "S&W Model 29 \"裁罚 .44\" 左轮手枪", 
-- ———— 描述未知
["addation_cbfe4fce2af60e41"] = "H&K P30L \"合约人\" 手枪", 
-- ———— 描述未知
["bm_wp_pis_g26"] = "Glock 26 \"奇玛诺 紧凑型\" 手枪",
-- ———— 无描述
["addation_9a27e2b16715cf12"] = "Colt Defender \"十字杀 警卫版\" 手枪", 
["addation_4a16c9a832b3caf0"] = "便携式打孔器。", 
["bm_w_hs2000"] = "Springfield XDM \"LEO\" 手枪", -- ———— 考虑到LEO可能是Law Enforcement Officer的缩写(来自wiki)(和前警察德拉冈有关)，保留原文为妙
-- ———— 无描述
["bm_w_glock_18c"] = "Glock 18C \"突袭 18C\" 冲锋手枪", 
["bm_w_glock_18c_desc"] = "9mm全自动手枪，射速很高但精度很差。",
["addation_b84e46d1aa5a46fb"] = "S&W M3 \"法国制 87型\" 左轮手枪", 
-- ———— 无描述
["addation_7c9c4eaa7968521b"] = "Beretta 93R \"伯奈特 自动型\" 冲锋手枪", 
-- ———— 无描述
["addation_18c8f2387e1faccd"] = "CZ 75 FULL AUTO \"捷克式 92\" 全自动手枪", 
-- ———— 无描述
["addation_c92328ec1a8e504a"] = "APS \"伊戈尔 全自动\" 手枪", 
-- ———— 无描述
["bm_w_peacemaker"] = "Ruger NV \"和平缔造者 .45\" 转轮手枪",
["bm_w_peacemaker_desc"] = "西部6发装手枪。枪斗者的武器。",
["bm_w_mateba"] = "Mateba 2006M \"马特文 .357\" 左轮手枪", -- ———— Matever来自对Mateba(马特巴)的一个typo
["bm_w_mateba_desc"] = "稀有的意大利制左轮。",
["bm_w_deagle"] = "IMI Desert Eagle Mark XIX \"沙鹰\" 手枪",
["bm_w_deagle_desc"] = ".50AE自动手枪，高威力，中等精度。",
["addation_716f9722696734a8"] = "Hudson H9 \"霍尔特 9mm\" 手枪", 
-- ———— 无描述
["addation_a1cb8493a5b9fb61"] = "Colt M1911 \"十字杀 掌中炮\" 手枪", 
-- ———— 无描述
["bm_w_rsh12"] = "RSh-12 \"RUS-12 怒虎\" 穿甲左轮手枪", 
["bm_w_rsh12_desc"] = "子弹可穿透敌人、敌人护甲、盾兵盾牌及墙体。", 
["bm_w_type54"] = "Type 54 \"工业军工 54型\" 手枪", 
-- ———— 无描述


-- —————— 双持手枪（主手）
-- 注：顺序以副手手枪为准
-- （吐槽：春假更新的双持(包括之后)描述全都有两条，难不成是因为有两把枪所以每一把都得描述一遍）
["bm_w_x_usp"] = "双持 \"拦截者.45\" 手枪",
-- ———— 无描述
["bm_w_x_g17"] = "双持 \"奇玛诺 88\" 手枪",
-- ———— 无描述
["addation_6a432a5b10cec704"] = "双持 \"格鲁博 轻便型\" 手枪", 
["addation_4c65d42bbb6e2ba6"] = "双持\"格鲁博 轻便型\"手枪更加高效。", 
["addation_db267afe18d2820c"] = "双持\"格鲁博 轻便型\"手枪更加高效。", 
["addation_23726e77cdf2c229"] = "双持 \"署名 .40\" 手枪", 
["addation_9c793ca0d5d63b11"] = "双持\"署名 .40\"手枪更加高效。", 
["addation_dcce5eda88837d5a"] = "双持\"署名 .40\"手枪更加高效。", 
["bm_w_x_1911"] = "双持 \"十字杀\" 手枪",
-- ———— 无描述
["bm_w_x_b92fs"] = "双持 \"伯奈特 9型\" 手枪",
-- ———— 无描述
["addation_2ab63bb80d78328e"] = "双持 \"野马 .44\" 左轮手枪", 
["addation_545e01faec02aef6"] = "双持\"野马 .44\"左轮手枪更加高效。", 
["addation_812a1155317670bd"] = "双持\"野马 .44\"左轮手枪更加高效。", 
["addation_49def807bf53517b"] = "双持 \"白纹\" 手枪", 
["addation_ff6ba8373639e2fb"] = "双持\"白纹\"手枪更加高效。", 
["addation_c577249f19b98c3b"] = "双持\"白纹\"手枪更加高效。", 
["addation_927098158e4b2c90"] = "双持 \"沙漠雏鹰\" 手枪", 
["addation_6102b0f8d293d368"] = "双持\"沙漠雏鹰\"手枪更加高效。", 
["addation_3739a3d8125b184a"] = "双持\"沙漠雏鹰\"手枪更加高效。", 
["addation_4559230c3431de8b"] = "双持 \"M13 9mm\" 手枪", 
["addation_44e1d81270bdd2fa"] = "什么东西比一把枪更好？答案很明显，当然是两把小可爱了。", 
["addation_b6300f35cb72094e"] = "什么东西比一把枪更好？答案很明显，当然是两把小可爱了。",
["bm_w_x_g22c"] = "双持 \"奇玛诺定制版\" 手枪",
-- ———— 无描述
["addation_58f7e25eeeb77436"] = "双持 \"扫帚柄\" 手枪", 
["addation_ea0337b8ec772e1a"] = "双持\"扫帚柄\"手枪更加高效。", 
["addation_ff64d6d896924e3c"] = "双持\"扫帚柄\"手枪更加高效。", 
["addation_1d87f738ff04c064"] = "双持 \"巴拉贝鲁姆\" 手枪", 
["addation_2ef571872d791e25"] = "双持鲁格手枪更加高效。", 
["addation_6e39d9df58e06b79"] = "双持鲁格手枪更加高效。", 
["addation_2378579d61ea1f84"] = "双持 \"裁罚 .44\" 左轮手枪", 
-- ———— 描述未知
["addation_0ba60b760ba736cf"] = "双持 \"合约人\" 手枪", 
-- ———— 描述未知
["bm_w_jowi"] = "双持 \"奇玛诺紧凑型\" 手枪",
-- ———— 无描述
["addation_201f8ef9b909c298"] = "双持 \"十字杀 警卫款\" 手枪", 
["addation_5adf6f4379d15d3d"] = "打出一排整齐的孔。",
["addation_787c03cabde29f21"] = "双持 \"LEO\" 手枪", 
["addation_5440b936c1cf50e5"] = "双持\"LEO\"手枪更加高效。", 
["addation_b98ce431558d5397"] = "双持\"LEO\"手枪更加高效。", 
["addation_63a6ca5ab40ad283"] = "双持 \"突袭 18C\" 冲锋手枪", 
["addation_ee01a8ca46b00f54"] = "双持\"突袭 18C\"手枪更加高效。", 
["addation_7db8a32e8ff1edc2"] = "双持\"突袭 18C\"手枪更加高效。", 
["addation_d26a4c5d5137d69b"] = "双持 \"法国制 87型\" 左轮手枪", 
-- ———— 无描述
["addation_42970a87838632ea"] = "双持 \"伯奈特 自动型\" 冲锋手枪", 
-- ———— 无描述
["addation_0ea9acdff330c33b"] = "双持 \"捷克式 92\" 全自动手枪", 
-- ———— 无描述
["addation_b2ebc9b469526e53"] = "双持 \"伊戈尔 全自动\" 手枪", 
-- ———— 无描述
["addation_286f5b27202fe1be"] = "双持 \"马特文 .357\" 左轮手枪", 
["addation_393fce18567f02bf"] = "双持\"马特文 .357\"左轮手枪更加高效。", 
["addation_1034d8a90c28c21d"] = "双持\"马特文 .357\"左轮手枪更加高效。", 
["bm_w_x_deagle"] = "双持 \"沙鹰\" 手枪",
-- ———— 无描述
["addation_8b78d2e2d6aa3c85"] = "双持 \"霍尔特 9mm\" 手枪", 
-- ———— 无描述
["addation_9f0d4aa982fc9f75"] = "双持 \"十字杀 掌中炮\" 手枪", 
-- ———— 无描述
["bm_w_x_type54"] = "双持 \"工业军工 54型\" 手枪", 
-- ———— 无描述

-- —————— 冲锋枪（副手）
["bm_w_m45"] = "Carl Gustav m/45B \"瑞典K型\" 冲锋枪",
-- ———— 无描述
["bm_w_mp7"] = "H&K MP7A1 \"特战\" 单兵自卫武器",
-- ———— 无描述
["bm_w_mac10"] = "Ingram MAC-11 \"马克 10\" 冲锋手枪",
["bm_w_mac10_desc"] = ".45ACP全自动冲锋枪，高射速高伤害。",
["addation_2c59b6ce41541d34"] = "CZ-805 BREN \"CR 805B\" 突击步枪", 
-- ———— 描述未知
["bm_w_cobray"] = "Cobray M11/9 \"夹克男的小玩意\" 冲锋枪",
-- ———— 无描述
["bm_w_mp5"] = "H&K MP5A2 \"紧凑型-5\" 冲锋枪",
["bm_w_mp5_desc"] = "9mm全自动冲锋枪，中等射速高精度。",
["bm_w_m1928"] = "Thompson M1928A1 \"芝加哥打字机\" 冲锋枪",
-- ———— 无描述
["bm_w_scorpion"] = "Sa. Vz.61 Skorpion \"眼镜蛇\" 冲锋枪",
-- ———— 无描述
["bm_w_mp9"] = "B&T MP9 \"CMP\" 冲锋手枪",
["bm_w_mp9_desc"] = "9mm全自动冲锋枪，高射速，但弹道散布较大。",
["bm_w_olympic"] = "Olympic K23 \"伞兵\" 短突击步枪",
["bm_w_olympic_desc"] = "5.56mm全自动冲锋枪，拥有中等精度和威力。",
["bm_w_baka"] = "IMI Micro Uzi \"微型乌兹\" 冲锋手枪",
-- ———— 无描述
["addation_5b6469de11b78e8a"] = "SIG MPX \"署名\" 冲锋枪", 
["addation_e610a8fde9fa214d"] = "有时候，\"署名\"冲锋枪能成为你摆脱困境的好伙伴。", 
["addation_1cf89f02e34fdf3e"] = "H&K UMP45 \"豺狼\" 冲锋枪", 
-- ———— 描述未知
["addation_115a8e49c39578f7"] = "MP40 \"MP40\" 冲锋枪", 
["addation_8dd19d76ce6d05db"] = "MP40冲锋枪已经过时了。", 
["bm_w_sr2"] = "SR-2 Veresk \"希瑟\" 冲锋枪",
-- ———— 无描述
["bm_w_akmsu"] = "Izhmash AKMSU \"卡拉科夫\" 短突击步枪",
["bm_w_akmsu_desc"] = "7.62mm全自动，高威力但操控性较差。",
["bm_w_tec9"] = "Intratec TEC-9 \"冲击波 9mm\" 冲锋手枪",
-- ———— 无描述
["bm_w_p90"] = "FN P90-TR \"辛夷花 90\" 单兵自卫武器", -- ———— 考虑到有忍者枪管这一玩意的存在，Kobus可能是指日本的辛夷花
["bm_w_p90_desc"] = "5.7mm全自动冲锋枪，中等威力，高携弹量。",
["bm_w_polymer"] = "KRISS Vector \"纵横交错\" 冲锋枪",
["bm_w_polymer_desc"] = "高分子聚合物制作的冲锋枪。轻量且高射速，假如你擅长应付后坐力，这把枪将带你直面对手逼得他们满地找掩体。",
["addation_1db6032213f43696"] = "Izhmash PP-19 Bizon-2 \"野牛\" 冲锋枪", 
-- ———— 描述未知
["bm_w_sterling"] = "Sterling L2A1 \"帕切特 L2A1\" 冲锋枪", -- ———— 人就叫这名，不能不改 ;-;
-- ———— 无描述
["bm_w_uzi"] = "IMI Uzi \"乌兹\" 冲锋枪",
-- ———— 无描述
["addation_61b2bf7bacd929eb"] = "PP-19-01 \"AK 21代 战术式\" 冲锋枪", 
-- ———— 无描述
["addation_d3027c53d5be3beb"] = "Minebea PM-9 \"美弥华 10 特殊型\" 冲锋枪", 
-- ———— 无描述

-- ——————双持冲锋枪（主手）
-- 注：顺序以副手冲锋枪为准
["addation_e9138848bbdf6e29"] = "双持 \"瑞典K型\" 冲锋枪", 
["addation_1142cf8bd069d8a8"] = "双持\"瑞典K型\"冲锋枪拥有更多弹药。", 
["addation_dcbd10319a086edb"] = "双持\"瑞典K型\"冲锋枪拥有更多弹药。", 
["addation_2bbf795cb16eb5f5"] = "双持\"特战\" 单兵自卫武器", 
["addation_3194f55bfd2a38ad"] = "双持\"特战\"单兵自卫武器拥有更多弹药。", 
["addation_97e7645d35af751f"] = "双持\"特战\"单兵自卫武器拥有更多弹药。", 
["addation_7863f814370395b0"] = "双持 \"马克 10\" 冲锋手枪", 
["addation_934afd8bff0b807e"] = "双持\"马克 10\"冲锋手枪拥有更多弹药。", 
["addation_db640645afe487da"] = "双持\"马克 10\"冲锋手枪拥有更多弹药。", 
["addation_20fb35febf542d61"] = "双持 \"CR 805B\" 突击步枪", 
["addation_1d05d4b43708509a"] = "双持\"CR 805B\"突击步枪拥有更多弹药。", 
["addation_115629971d191b98"] = "双持\"CR 805B\"突击步枪拥有更多弹药。", 
["addation_3fd338bd7e46532d"] = "双持 \"夹克男的小玩意\" 冲锋枪", 
["addation_682a80003f79653b"] = "双持\"夹克男的小玩意\"冲锋枪拥有更多弹药。", 
["addation_6967f3a108702ad9"] = "双持\"夹克男的小玩意\"冲锋枪拥有更多弹药。", 
["addation_b479bea81738481c"] = "双持 \"紧凑型-5\" 冲锋枪", 
-- ———— 无描述
["addation_6213fb9126644733"] = "双持 \"芝加哥打字机\" 冲锋枪", 
["addation_dc0beec5a818a047"] = "双持\"芝加哥打字机\"冲锋枪拥有更多弹药。", 
["addation_f9269250daf1c48e"] = "双持\"芝加哥打字机\"冲锋枪拥有更多弹药。", 
["addation_1b38d5e295507dee"] = "双持 \"眼镜蛇\" 冲锋枪", 
["addation_d565479a56747d13"] = "双持\"眼镜蛇\"冲锋枪拥有更多弹药。", 
["addation_a892be201978c7d5"] = "双持\"眼镜蛇\"冲锋枪拥有更多弹药。", 
["addation_eae2e208f8dd0a91"] = "双持 \"CMP\" 冲锋手枪", 
["addation_288b3e53440cfdfe"] = "双持\"CMP\"冲锋手枪拥有更多弹药。", 
["addation_b6c0ab1604546099"] = "双持\"CMP\"冲锋手枪拥有更多弹药。", 
["addation_3c82f64c70290a74"] = "双持 \"伞兵\" 短突击步枪", 
["addation_327de015b0d55ec4"] = "双持\"伞兵\"短突击步枪拥有更多弹药。", 
["addation_39ba4fe0c514b294"] = "双持\"伞兵\"短突击步枪拥有更多弹药。", 
["addation_640de2fae620e6a3"] = "双持 \"微型乌兹\" 冲锋手枪", 
["addation_c97ded12cd55272d"] = "双持\"微型乌兹\"冲锋手枪拥有更多弹药。", 
["addation_92854faaa1425849"] = "双持\"微型乌兹\"冲锋手枪拥有更多弹药。", 
["addation_a94cae5ed045fd3c"] = "双持 \"署名\" 冲锋枪", 
["addation_a2d946c00d88ecae"] = "如果一把\"署名\"冲锋枪是个好伙伴，那么两把就能开个派对了！", 
["addation_7477eff9153bf8d3"] = "双持 \"豺狼\" 冲锋枪", 
["addation_2d757ed934342823"] = "双持\"豺狼\"冲锋枪拥有更多弹药。", 
["addation_2888dffe888680e4"] = "双持\"豺狼\"冲锋枪拥有更多弹药。", 
["addation_47fc960ed693791f"] = "双持 \"MP40\" 冲锋枪", 
["addation_67925402cfb85301"] = "双持\"MP40\"冲锋枪拥有更多弹药。", 
["addation_2e15c9f2dcf85b63"] = "双持\"MP40\"冲锋枪拥有更多弹药。", 
["bm_w_x_sr2"] = "双持 \"希瑟\" 冲锋枪",
-- ———— 无描述
["addation_4c103e01640a6163"] = "双持 \"卡拉科夫\" 短突击步枪", 
-- ———— 无描述
["addation_276488d81d5f9998"] = "双持 \"冲击波 9mm\" 冲锋手枪", 
["addation_c6f937024d3bba07"] = "双持\"冲击波 9mm\"冲锋手枪冲锋枪拥有更多弹药。", 
["addation_4572a2e9f4eb6881"] = "双持\"冲击波 9mm\"冲锋手枪冲锋枪拥有更多弹药。", 
["addation_e7f2076a5af1a2c6"] = "双持 \"辛夷花 90\" 单兵自卫武器", 
["addation_b3a924abc3a00d47"] = "双持\"辛夷花 90\"单兵自卫武器拥有更多弹药。", 
["addation_c41094461c1bff45"] = "双持\"辛夷花 90\"单兵自卫武器拥有更多弹药。", 
["addation_27f9ac204e578f00"] = "双持 \"纵横交错\" 冲锋枪", 
["addation_57d65cf1508f5457"] = "双持\"纵横交错\"冲锋枪拥有更多弹药。", 
["addation_b3d2adb979fe419f"] = "双持\"纵横交错\"冲锋枪拥有更多弹药。", 
["addation_fe04d129f5e0a589"] = "双持 \"野牛\" 冲锋枪", 
["addation_ab40fd1edc4af8f6"] = "双持\"野牛\"冲锋枪拥有更多弹药。", 
["addation_611edec5a1deb5c6"] = "双持\"野牛\"冲锋枪拥有更多弹药。", 
["addation_246c9425dc6f0f12"] = "双持 \"帕切特 L2A1\" 冲锋枪", 
["addation_f8141dfa0174b9be"] = "双持\"帕切特 L2A1\"冲锋枪拥有更多弹药。", 
["addation_405221a0e095658a"] = "双持\"帕切特 L2A1\"冲锋枪拥有更多弹药。", 
["addation_085a9b7cfc9c0c24"] = "双持 \"乌兹\" 冲锋枪", 
["addation_bffd01c97ad2ba1a"] = "双持\"乌兹\"冲锋枪拥有更多弹药。", 
["addation_ac229bded285c946"] = "双持\"乌兹\"冲锋枪拥有更多弹药。", 
["addation_dd120a4e62c0ce70"] = "双持 \"AK 21代 战术式\" 冲锋枪", 
-- ———— 无描述
["addation_0d0a0c0a8e420ff1"] = "双持 \"美弥华 10 特殊型\" 冲锋枪", 
-- ———— 无描述

-- —————— 特殊（副手）
["bm_w_hunter"] = "Avalanche Pistol T50-lb. 手枪弩",
["bm_w_hunter_desc"] = "手枪与弓合二为一。结实如手枪安静如弓。为特定击杀准备了各类箭矢。",
["addation_a202d7da05ddae29"] = "H&K M320 \"紧凑型 40mm\" 榴弹发射器", 
["addation_0e9f600387a14cf3"] = "\"紧凑型 40mm\"榴弹发射器中看又中用。", 
["bm_w_rpg7"] = "RPG-7 \"HRL-7\" 火箭筒",
["bm_w_rpg7_desc"] = "该武器无法拾取弹药。",
["bm_w_china"] = "China Lake \"中国湖泵动式 40mm\" 榴弹发射器", -- ———— 单纯把\"泡芙\"这个看到就知道不对的翻译该掉
-- ———— 无描述
["addation_62059013f5f16858"] = "M202A1 \"魔鬼司令101\" 火箭筒", 
["addation_3cc65fa4d255f178"] = "该武器无法拾取弹药。", 
["addation_0ab6e3a8127fd031"] = "Not-A-Flamethrower \"MA-17\" 火焰喷射器", 
["addation_faf93f15890eebdf"] = "未来可不会变成\"他们\"所说的样子，不是吗？好吧，至少它还是有机会变得很酷或很现代化的。在美国的某个地方，有一家公司在暗中制造这些次世代的武器。能飞的汽车是不可能有了，但至少它们能够成为这其中的一个配件。", 
["addation_203ea003beb7a53f"] = "H&K XM25 \"仲裁者\" 榴弹发射器", 
-- ———— 无描述

-- —————— 霰弹枪（副手）
["bm_w_serbu"] = "Remington M870 \"火车头 12G\" 霰弹枪",
["bm_w_serbu_desc"] = "12号口径泵动式霰弹枪，拥有高威力和高便携性。",
["bm_w_m37"] = "Ithaca 37 \"GSPS 12G\" 霰弹枪",
["bm_w_m37_desc"] = "\"GSPS 12G\"泵动式霰弹枪被广泛用于军事，警用与民用。这把霰弹别出心裁地使用了子弹装填与退弹共用同一仓口的设计。该设计不论是使用者是左手持枪还是右手持枪都能方便地换弹，这使得左撇子尤其青睐这把枪。",
["addation_5f3702835b0dd412"] = "C-P Six 12 \"歌莉娅 12G\" 霰弹枪", 
-- ———— 描述未知
["addation_96cdf1741d0b472a"] = "CBRPS Saiga \"格林 12G\" 霰弹枪", 
["addation_6904059a1ce19660"] = "牛逼闪闪的\"格林\"霰弹枪", 
["bm_w_striker"] = "S-A Striker-12 \"街道扫荡者\" 霰弹枪",
-- ———— 无描述
["bm_w_judge"] = "Taurus 4510PLYFS \"判官\" 霰弹枪",
["bm_w_judge_desc"] = ".410左轮霰弹，威力相当高，但携弹量很低。",
["addation_ee83ce57f5c422a4"] = "Remington M1889 \"克莱尔 12G\" 霰弹枪", 
["addation_3338f9129573d787"] = "新霰弹不错嘛！", 
["addation_fdd63b3d6a07db83"] = "新霰弹不错嘛！", 

-- —————— 双持霰弹枪（主手）
["addation_e6880ecf77531f95"] = "双持 \"歌莉娅 12G\" 霰弹枪", 
["addation_e583a2c9c3723b26"] = "双持\"歌莉娅 12G\"霰弹枪更加高效。", 
["addation_9359241bf61a9a1c"] = "双持\"歌莉娅 12G\"霰弹枪更加高效。", 
["addation_0ff097fef0b5e88c"] = "\"格林兄弟 12G\" 双持霰弹枪", -- ———— 被逼无奈...
["addation_e2d356409a943460"] = "双持版本的\"格林\"霰弹枪", 
["addation_4bc0d9ee3892ead8"] = "双持 \"判官\" 霰弹枪", 
["addation_3cf889c2f34eaa9d"] = "双持\"判官\"霰弹枪更加高效。", 
["addation_f956fdb7a062b7d1"] = "双持\"判官\"霰弹枪更加高效。", 

-- ——————————————————————武器模组(共726条)——————————————————————
-- —————— 步枪   注：以AMCAR的排列顺序为基准
-- ———— 枪管
["bm_menu_barrel"] = "枪管",
["bm_wp_ass_s552_b_long"] = "长枪管", -- ———— 突击手 553
["bm_wp_scar_b_short"] = "短枪管", -- ———— 巨鹰
["bm_wp_scar_b_long"] = "长枪管", -- ———— 巨鹰
["addation_5abb752c5ed5d174"] = "短枪管", -- ———— 联盟 5.56
["bm_wp_upg_ak_b_draco"] = "\"AK型斯拉夫之龙\" 枪管", -- ———— AK
["bm_wp_upg_ak_b_ak105"] = "\"现代化\" 枪管", -- ———— AK
["bm_wp_upg_ass_ak_b_zastava"] = "DMR套件", -- ———— AK
["bm_wp_m4_uupg_b_long"] = "长枪管", -- ———— CAR-4
["bm_wp_m4_uupg_b_short"] = "短枪管", -- ———— CAR-4
["bm_wp_m4_uupg_b_sd"] = "\"潜袭\" 枪管", -- ———— CAR-4
["bm_wp_upg_ass_m4_b_beowulf"] = "DMR套件", -- ———— CAR-4
["bm_wp_aug_b_long"] = "长枪管", -- ———— UAR
["bm_wp_aug_b_short"] = "短枪管", -- ———— UAR
["addation_581f00454744887f"] = "\"AML\" 枪管", -- ———— 私录碟
["bm_wp_l85a2_b_short"] = "\"小个子\" 枪管", -- ———— 女王之怒
["bm_wp_l85a2_b_long"] = "\"大个子\" 枪管", -- ———— 女王之怒
["addation_13ffd877e8cd2be6"] = "\"坦克车手\" 枪管", -- ———— 加兰特
["bm_wp_famas_b_long"] = "长枪管", -- ———— 号角
["bm_wp_famas_b_short"] = "短枪管", -- ———— 号角
["bm_wp_famas_b_sniper"] = "狙击枪管", -- ———— 号角
["bm_wp_famas_b_suppressed"] = "消音枪管", -- ———— 号角
["bm_wp_vhs_b_short"] = "CQB枪管", -- ———— 狮吼
["bm_wp_vhs_b_sniper"] = "精准枪管", -- ———— 狮吼
["bm_wp_vhs_b_silenced"] = "消音枪管", -- ———— 狮吼
["bm_wp_asval_b_proto"] = "原型枪管", -- ———— 瓦尔基里
["bm_wp_ak5_b_short"] = "CQB枪管", -- ———— AK5
["bm_wp_fal_body_standard"] = "CQB护木", -- ———— 飞隼
["bm_wp_fal_fg_03"] = "\"复古式\"护木", -- ———— 飞隼
["bm_wp_fal_fg_04"] = "\"射手\" 护木", -- ———— 飞隼
["bm_wp_fal_fg_wood"] = "\"木质\" 护木", -- ———— 飞隼
["bm_wp_g3_b_short"] = "突击套件", -- ———— 格威尔三型
["bm_wp_g3_b_sniper"] = "DMR套件", -- ———— 格威尔三型
["addation_70c8f4aa022168aa"] = "K-B100抑制枪管", -- ———— 科迟诺夫 Byk-1

-- ———— 枪口配件(通用)
["bm_menu_barrel_ext"] = "枪口配件",
["bm_wp_upg_ns_ass_smg_medium"] = "\"中等大小\" 抑制器",
["bm_wp_upg_ns_ass_smg_small"] = "\"低调\" 抑制器",
["bm_wp_upg_ns_ass_smg_stubby"] = "\"短粗\" 补偿器",
["bm_wp_upg_ns_ass_smg_tank"] = "\"坦克\" 补偿器",
["bm_wp_upg_ns_ass_smg_firepig"] = "\"吐焰\" 消焰器",
["bm_wp_upg_ns_ass_smg_large"] = "\"越大越好\" 抑制器",
["bm_wp_upg_ass_ns_jprifles"] = "\"竞争者\" 补偿器",
["bm_wp_upg_ass_ns_linear"] = "\"欢乐囱管\" 补偿器",
["bm_wp_upg_ass_ns_surefire"] = "\"战术\" 补偿器",
["bm_wp_ns_battle"] = "\"镂空\" 补偿器",
["addation_6761233b3b0e0b08"] = "\"马蒙\" 补偿器", 

-- ———— 枪口配件
["bm_wp_upg_ns_ass_pbs1"] = "\"PBS\" 抑制器", -- ———— AK
["addation_b1b255067ae50800"] = "\"一己之力\" 补偿器",  -- ———— 私录碟
["bm_wp_shak12_ns_muzzle"] = "KS12-A爆裂枪口", -- ———— KS12
["bm_wp_shak12_ns_suppressor"] = "KS12-S超长消音器", -- ———— KS12

-- ———— 枪机组 就两条。
["bm_menu_custom"] = "枪机组",
["bm_wp_upg_i_singlefire"] = "半自动锁定枪机组",
["bm_wp_upg_i_autofire"] = "全自动锁定枪机组",

-- ———— 额外部件
["addation_2465e4a54fed7773"] = "额外部件", 
["bm_menu_extra"] = "额外部件", -- ———— 弃用文本
["bm_wp_upg_o_ak_scopemount"] = "镜桥", -- ———— AK系
["bm_wp_aug_fg_a3"] = "A3战术护木", -- ———— UAR
["bm_wp_upg_o_m14_scopemount"] = "镜桥", -- ———— M308

-- ———— 护木
["bm_menu_foregrip"] = "护木",
["bm_wp_ass_s552_fg_standard_green"] = "增强护木", -- ———— 突击手 553
["bm_wp_ass_s552_fg_railed"] = "导轨护木", -- ———— 突击手 553
["bm_wp_scar_fg_railext"] = "扩展导轨", -- ———— 巨鹰
["bm_wp_ak_fg_combo2"] = "\"纯木制导轨\" 前握把", -- ———— AK
["bm_wp_ak_fg_combo3"] = "\"战术俄制\" 护木", -- ———— AK
["bm_wp_upg_ak_fg_tapco"] = "\"久经沙场\" 护木", -- ———— AK
["bm_wp_upg_fg_midwest"] = "\"轻量化\" 导轨", -- ———— AK
["bm_wp_upg_ak_fg_krebs"] = "\"横行\" 导轨", -- ———— AK
["bm_wp_upg_ak_fg_trax"] = "\"核心模块\" 导轨", -- ———— AK
["bm_wp_m4_uupg_fg_lr300"] = "\"配件商特制版\" 前握把", -- ———— CAR-4
["bm_wp_upg_fg_jp"] = "\"竞赛\" 护木", -- ———— CAR-4
["bm_wp_upg_fg_smr"] = "\"羚羊\" 导轨", -- ———— CAR-4
["bm_wp_upg_ass_m4_fg_lvoa"] = "\"OVAL\" 护木", -- ———— CAR-4
["bm_wp_upg_ass_m4_fg_moe"] = "\"E.M.O.\" 护木", -- ———— CAR-4
["bm_wp_sub2000_fg_gen2"] = "\"阿巴拉契亚\" 护木", -- ———— 龋齿 9mm
["bm_wp_sub2000_fg_railed"] = "\"德拉贝尔\" 护木", -- ———— 龋齿 9mm
["bm_wp_sub2000_fg_suppressed"] = "\"牙仙\" 抑制器", -- ———— 龋齿 9mm
["bm_wp_g36_fg_c"] = "\"紧凑型\" 导轨", -- ———— JP36
["bm_wp_g36_fg_ksk"] = "\"警用特制\" 导轨", -- ———— JP36
["addation_604dd1b7a584fafd"] = "JP36长护木",  -- ———— JP36
["bm_wp_l85a2_fg_short"] = "\"多用途\" 前握把", -- ———— 女王之怒
["addation_af0fed4d314c5e8a"] = "定制护木", -- ———— 加兰特
["bm_wp_ak5_fg_ak5c"] = "\"卡宾C型\" 护木", -- ———— AK5
["bm_wp_ak5_fg_fnc"] = "\"比利时盗火\" 护木", -- ———— AK5
["bm_wp_galil_fg_fab"] = "\"精巧绝伦\" 护木", -- ———— 壁虎 7.62
["bm_wp_galil_fg_mar"] = "CQB护木", -- ———— 壁虎 7.62
["bm_wp_galil_fg_sar"] = "\"轻型\" 护木", -- ———— 壁虎 7.62
["bm_wp_galil_fg_sniper"] = "\"狙击式\" 护木", -- ———— 壁虎 7.62
["bm_wp_m16_fg_railed"] = "\"战术式\" 护木", -- ———— AMR-16
["bm_wp_m16_fg_vietnam"] = "\"怀旧之潮\" 护木", -- ———— AMR-16
["bm_wp_upg_ass_m16_fg_stag"] = "人体工程学长导轨", -- ———— AMR-16
["bm_wp_g3_fg_psg"] = "\"精准\" 护木", -- ———— 格威尔三型
["bm_wp_g3_fg_railed"] = "\"战术式\" 护木", -- ———— 格威尔三型
["bm_wp_g3_fg_retro"] = "\"木制\" 护木", -- ———— 格威尔三型
["bm_wp_g3_fg_retro_plastic"] = "\"塑料制\" 护木", -- ———— 格威尔三型

-- ———— 附属配件(通用)
["bm_menu_gadget"] = "附属配件",
["addation_6e2f75239ac8e423"] = "\"瑞科普克\" 45度瞄准镜", 
["addation_444278e6a5781c7e"] = "\"瑞科普克\" 放大附件镜", 
["bm_wp_upg_fl_ass_smg_sho_surefire"] = "\"突击式\" 手电",
["bm_wp_upg_fl_ass_smg_sho_peqbox"] = "\"战术式\" 镭射模块",
["bm_wp_upg_fl_ass_laser"] = "\"紧凑型\" 镭射模块",
["bm_wp_upg_fl_ass_peq15"] = "\"军用\" 镭射模块",
["bm_wp_upg_fl_ass_utg"] = "\"LED组合\" 照明模块",
["addation_fe9ca981c4ded826"] = "45度红点瞄准镜", 
["addation_f330ba5ea0a6eda0"] = "45度机械瞄具", 
["addation_e9926125b3eef587"] = "\"鲜明\" 放大附件镜", 

-- ———— 握把(通用)
["bm_menu_grip"] = "握把",
["bm_wp_m4_g_ergo"] = "\"人体工程\" 握把",
["bm_wp_m4_g_sniper"] = "平衡配重 \"专家式\" 合成物握把",
["bm_wp_upg_m4_g_hgrip"] = "\"橡胶制\" 握把", -- ———— M4系
["bm_wp_upg_m4_g_mgrip"] = "\"直式\" 握把",
["addation_d3edbc96e6f08c21"] = "钛合金镂空握把", 
["addation_c1733e9a8a4cb8d1"] = "\"合约人\" 握把", 

-- ———— 握把
["bm_wp_ass_s552_g_standard_green"] = "增强握把", -- ———— 突击手 553
["bm_wp_upg_ak_g_hgrip"] = "\"AK系橡胶制\" 握把", -- ———— AK系
["bm_wp_upg_ak_g_pgrip"] = "\"AK系塑料制\" 握把", -- ———— AK
["addation_93a42eed066c753c"] = "\"AK系纯木制\" 握把", -- ———— AK
["bm_wp_upg_ak_g_rk3"] = "\"铝合金\" 握把", -- ———— AK
["bm_wp_upg_ak_g_wgrip"] = "\"AK系纯木制\" 握把", -- ———— AK
["bm_wp_l85a2_g_worn"] = "\"激情迸发\" 握把", -- ———— 女王之怒
["bm_wp_famas_g_retro"] = "\"G2\" 握把", -- ———— 号角
["bm_wp_fal_g_01"] = "\"战术式\" 握把", -- ———— 飞隼
["bm_wp_g3_g_retro"] = "\"复古式\" 握把", -- ———— 格威尔三型
["bm_wp_g3_g_sniper"] = "\"精准\" 握把", -- ———— 格威尔三型

-- ———— 下机匣
["addation_68f828f8af2606b3"] = "下机匣", 
["bm_menu_lower_reciever"] = "下机匣", -- ———— 弃用文本
["addation_6f9fcdc9625f25b5"] = "沙色战术枪身",  -- 联盟 5.56
["bm_wp_upg_ass_m4_lower_reciever_core"] = "\"猛袭\" 下机匣", -- ———— CAR-4
["bm_wp_aug_body_f90"] = "猛禽聚合物枪身", -- ———— UAR

-- ———— 弹匣(通用)
["bm_menu_magazine"] = "弹匣",
["bm_wp_m4_m_straight"] = "\"陈年\" 弹匣",
["bm_wp_m4_uupg_m_std"] = "\"军用规范式\" 弹匣",
["bm_wp_m4_m_pmag"] = "\"战术式\" 弹匣",
["bm_wp_upg_m4_m_quad"] = "\"CAR系四排双进\" 弹匣",
["bm_wp_l85a2_m_emag"] = "\"专家级\" 弹匣",
["bm_wp_upg_m4_m_l5"] = "\"L5\" 弹匣",
["addation_613b5403d9854ca1"] = "弹匣快拔套", 
["addation_00056a4a7bb1b44f"] = "弹匣快拔套", 
["addation_49f91c2457ff8bae"] = "弹匣快拔套", 
["addation_f68f22fb0d419303"] = "弹匣快拔套", 
["addation_9b7a8e964aaf2744"] = "弹匣快拔套", 
["addation_6a3e000ce338132f"] = "弹匣快拔套", 
["addation_53b13ade79ddd031"] = "弹匣快拔套", 

-- ———— 弹匣
["bm_wp_upg_ak_m_quad"] = "\"AK系四排双进\" 弹匣", -- ———— AK
["bm_wp_upg_ak_m_uspalm"] = "\"低阻型\" 弹匣", -- ———— AK
["bm_wp_fal_m_01"] = "扩容弹匣", -- ———— 号角
["addation_306d907fcd647747"] = "K-B1快拔弹匣", -- ———— 科迟诺夫 Byk-1

-- ———— 瞄准镜(通用)
["bm_menu_sight"] = "瞄准镜",
["bm_wp_upg_o_eotech"] = "\"全息式\" 瞄准镜",
["bm_wp_upg_o_t1micro"] = "\"专家之选\" 瞄准镜",
["bm_wp_upg_o_docter"] = "\"医师\" 瞄准镜",
["bm_wp_upg_o_acog"] = "\"阿柯\" 光学瞄准镜",
["bm_wp_upg_o_aimpoint"] = "\"军用红点\" 瞄准镜",
["bm_wp_upg_o_specter"] = "\"军备级\" 瞄准镜",
["bm_wp_upg_o_cmore"] = "\"见多识广\" 瞄准镜",
["bm_wp_upg_o_cs"] = "\"战术式\" 瞄准镜",
["bm_wp_upg_o_eotech_xps"] = "\"紧凑型全息式\" 瞄准镜",
["bm_wp_upg_o_reflex"] = "\"见机行事\" 瞄准镜",
["bm_wp_upg_o_rx01"] = "\"崔贡\" 瞄准镜",
["bm_wp_upg_o_rx30"] = "\"太阳能\" 瞄准镜",
["addation_2a84d45a76ac0b32"] = "\"侦查\" 瞄准镜", 
["addation_10af4ed7ef80dd5f"] = "\"紧凑型机械式\" 瞄准镜", 
["addation_9567d197e1a79672"] = "\"混乱\" 瞄准镜", 
["addation_ffc2a2dc6ccee6b1"] = "\"改良型战术式\" 瞄准镜", 
["addation_bd4cf96b1132fb99"] = "\"紧凑型战术式\" 盒式瞄准镜", 
["bm_wp_upg_o_poe"] = "Z5 \"夜鸮之视\" 通用瞄准镜",

-- ———— 瞄准镜
["addation_f6cc9cff08b4a13a"] = "原型瞄准镜", -- ———— JP36
["bm_wp_shak12_o_carry_dummy"] = "KS12-S枪械提把", -- ———— KS12sh

-- ———— 枪托(通用)
["addation_d0a2a4abef2c4858"] = "枪托", 
["bm_menu_stock"] = "枪托", -- ———— 弃用文本
["bm_wp_m4_s_standard"] = "\"标配式\" 枪托",
["bm_wp_upg_m4_s_crane"] = "\"宽型\" 枪托",
["bm_wp_upg_m4_s_mk46"] = "\"战损\" 枪托",
["bm_wp_upg_m4_s_ubr"] = "\"两段型\" 枪托",
["addation_727a85c1f9aa63fc"] = "\"合约人\" 枪托", 
["bm_wp_m4_s_pts"] = "\"战术式\" 枪托",

-- ———— 枪托
["bm_wp_ass_s552_s_standard_green"] = "增强枪托", -- ———— 突击手 553
["bm_wp_scar_s_sniper"] = "狙击枪托", -- ———— 巨鹰
["bm_wp_m4_uupg_s_fold"] = "\"折叠式\" 枪托", -- ———— AK
["bm_wp_ak_s_psl"] = "\"纯木制\" 狙击枪托", -- ———— AK
["bm_wp_upg_ak_s_solidstock"] = "\"经典式\" 枪托", -- ———— AK
["bm_wp_ak_s_folding"] = "折叠枪托", -- ———— RPK
["bm_wp_ak_s_skfoldable"] = "\"骨架形\" 枪托", -- ———— AK.762
["bm_wp_g36_s_kv"] = "固定枪托", -- ———— JP36
["bm_wp_g36_s_sl8"] = "狙击枪托", -- ———— JP36
["addation_7dbf7af4acb87382"] = "备弹袋枪托",  -- ———— 加兰特
["bm_wp_m14_body_ebr"] = "\"亚伯拉罕\" 枪身", -- ———— M308
["bm_wp_m14_body_jae"] = "\"耶格\" 枪身", -- ———— M308
["addation_b170f8f0b0b4e344"] = "\"地虎特攻队\" 枪身", -- ———— M308
["bm_wp_asval_s_solid"] = "固定枪托", -- ———— 瓦尔基里
["bm_wp_ak5_s_ak5b"] = "\"伯蒂尔\" 枪托", -- ———— AK5
["bm_wp_ak5_s_ak5c"] = "\"凯撒\" 枪托", -- ———— AK5
["bm_wp_galil_s_fab"] = "\"精巧绝伦\" 枪托", -- ———— 壁虎 7.62
["bm_wp_galil_s_light"] = "\"轻型\" 枪托", -- ———— 壁虎 7.62
["bm_wp_galil_s_plastic"] = "\"塑料制\" 枪托", -- ———— 壁虎 7.62
["bm_wp_galil_s_skeletal"] = "\"骨架形\" 枪托", -- ———— 壁虎 7.62
["bm_wp_galil_s_sniper"] = "\"狙击式\" 枪托", -- ———— 壁虎 7.62
["bm_wp_galil_s_wood"] = "\"木质\" 枪托", -- ———— 壁虎 7.62
["bm_wp_fal_s_01"] = "CQB枪托", -- ———— 飞隼
["bm_wp_fal_s_03"] = "\"射手\" 枪托", -- ———— 飞隼
["bm_wp_fal_s_wood"] = "\"木质\" 枪托", -- ———— 飞隼
["bm_wp_g3_s_sniper"] = "\"精准\" 枪托", -- ———— 格威尔三型
["bm_wp_g3_s_wood"] = "\"木质\" 枪托", -- ———— 格威尔三型
["bm_wp_shak12_body_vks"] = "DMR套件", -- ———— KS12sh

-- ———— 上机匣
["addation_fe16cc1d74a5f1d0"] = "上机匣", 
["bm_menu_upper_reciever"] = "上机匣", -- ———— 弃用文本
["bm_wp_ass_s552_body_standard_black"] = "热加工枪身", -- ———— 突击手 553
["bm_wp_m4_upper_reciever_edge"] = "\"异国\" 机匣",
["bm_wp_upg_ass_m4_upper_reciever_ballos"] = "\"LW\" 上机匣",
["bm_wp_upg_ass_m4_upper_reciever_core"] = "\"猛袭\" 上机匣", -- ———— CAR-4

-- ———— 下挂榴弹
-- ———— groza是默认爆破弹就很奇怪
["addation_3209db536f1e7956"] = "下挂榴弹", 
["bm_wp_upg_a_grenade_launcher_frag"] = "爆破榴弹",
["addation_bafe04ba9cf70020"] = "X1-a战术式电磁榴弹", 
["addation_7bfaa5e99235677b"] = "X1-a战术式电磁榴弹", 
["addation_d757a3f2caa512b9"] = "释放高压电流，伤害并电击范围内的敌人。", 

-- —————— 霰弹(主副手)
-- ———— 弹药
["bm_menu_ammo"] = "弹药",
["bm_wp_upg_a_custom"] = "000型猎鹿弹",
["bm_wp_upg_a_explosive"] = "HE高爆弹",
["bm_wp_upg_a_piercing"] = "箭形弹",
["bm_wp_upg_a_slug"] = "AP独头弹",
["bm_wp_upg_a_dragons_breath"] = "龙息弹",

-- ———— 枪管
["bm_wp_spas12_b_long"] = "扩容弹仓", -- ———— 掠夺者 12G
["addation_1033712327b6d06c"] = "长枪管",  -- ———— 破坏者 12G
["addation_3ad80420d9a81455"] = "短枪管",  -- ———— 破坏者 12G
["bm_wp_ben_b_long"] = "长枪管", -- ———— M1014
["bm_wp_ben_b_short"] = "短枪管", -- ———— M1014
["bm_wp_ksg_b_long"] = "长枪管", -- ———— 渡鸦
["bm_wp_ksg_b_short"] = "短枪管", -- ———— 渡鸦
["addation_ebc4107e650a859e"] = "短枪管",  -- ———— 一字马 12G
["bm_wp_huntsman_b_short"] = "\"路霸\" 枪管", -- ———— 莫斯科尼 12G
["bm_wp_b682_b_short"] = "锯短枪管", -- ———— 乔斯林 O/U 12G
["bm_wp_aa12_barrel_long"] = "长枪管", -- ———— 牛排 12G
["bm_wp_aa12_barrel_silenced"] = "消音枪管", -- ———— 牛排 12G
["bm_wp_m37_b_short"] = "\"暴乱\" 枪管", -- ———— GSPS 12G
["addation_739565325e8ce3fc"] = "短枪管", -- ———— 格利亚 12G
["addation_6dbf30b77f5a6ed1"] = "消音枪管", -- ———— 格利亚 12G
["bm_wp_striker_b_long"] = "长枪管", -- ———— 街道扫荡者
["bm_wp_striker_b_suppressed"] = "消音枪管", -- ———— 街道扫荡者
["addation_edda88d6f1a18607"] = "锯短枪管", -- ———— 克莱尔 12G
["addation_cc8c8719f320c456"] = "\"猎手\" 枪管", -- ———— 赖因费尔德 88
["addation_77630b7aec2bbcc8"] = "\"通透\" 枪管",  -- ———— 赖因费尔德 88
["addation_69192e36a3124d4c"] = "CE消音枪管", -- ———— 莫斯科尼 战术
["addation_c1d9aa6c4be55ff2"] = "CE延长枪管", -- ———— 莫斯科尼 战术

-- ———— 枪口配件(通用)
["bm_wp_upg_ns_shot_shark"] = "鲨鱼齿枪口",
["bm_wp_upg_ns_shot_thick"] = "\"无声杀手\" 抑制器",
["bm_wp_upg_shot_ns_king"] = "\"王者之冠\" 补偿器",
["bm_wp_upg_ns_sho_salvo_large"] = "\"嘘！\"",
["addation_b1030b0a408b6d27"] = "\"唐老鸭\" 水平扩散枪口", 

-- ———— 护木
["bm_wp_r870_fg_wood"] = "\"僵尸猎人\" 护木", -- ———— 瑞恩斐德 880
["bm_wp_saiga_fg_lowerrail"] = "\"战术俄制\" 导轨", -- ———— 一字马 12G
["addation_c865b305ce90f659"] = "\"镂洞式\" 护木", -- ———— 一字马 12G
["addation_e918418503086053"] = "\"小老弟\" 护木", -- ———— 格林 12G

-- ———— 弹匣
["bm_wp_r870_m_extended"] = "扩容弹仓", -- ———— 瑞恩斐德 880
["addation_58b69ef80952becd"] = "\"大表哥\" 弹匣", -- ———— 一字马 12G
["bm_wp_aa12_mag_drum"] = "弹鼓", -- ———— 牛排 12G
["bm_wp_shorty_m_extended_short"] = "扩容弹仓", -- ———— 火车头 12G

-- ———— 下机匣
["addation_cc13b5d8d4222a91"] = "\"身经百战\" 枪身", -- ———— 破坏者 12G
["addation_ea3fb1428d54350d"] = "定制钢制枪身", 
["addation_393d85c1b359f146"] = "CE枪管稳定器", -- ———— 莫斯科尼 战术

-- ———— 瞄准镜
["bm_wp_upg_o_mbus_rear"] = "\"翻折式\" 机械瞄具", -- ———— 渡鸦

-- ———— 枪托
["bm_wp_spas12_s_folded"] = "折叠枪托", -- ———— 掠夺者 12G
["bm_wp_spas12_s_solid"] = "固定枪托", -- ———— 掠夺者 12G
["bm_wp_spas12_s_no"] = "无枪托", -- ———— 掠夺者 12G
["addation_2cb7e1d0a4ad4b46"] = "长枪托", -- ———— 破坏者 12G
["bm_wp_r870_s_nostock"] = "\"不能再小\" 枪托", -- ———— 瑞恩斐德 880
["bm_wp_r870_s_nostock_big"] = "\"不能再小\" 战术枪托", -- ———— 瑞恩斐德 880
["bm_wp_r870_s_solid_big"] = "\"政府需求\" 战术枪托", -- ———— 瑞恩斐德 880
["bm_wp_r870_s_folding"] = "折叠枪托", -- ———— 瑞恩斐德 880
["bm_wp_ben_s_collapsed"] = "收起式枪托", -- ———— M1014
["bm_wp_ben_fg_standard"] = "战术枪托", -- ———— M1014
["bm_wp_huntsman_s_short"] = "\"匪帮特制\" 枪托", -- ———— 莫斯科尼 12G
["bm_wp_b682_s_ammopouch"] = "豪华子弹袋", -- ———— 乔斯林 O/U 12G
["bm_wp_b682_s_short"] = "\"手腕破坏者\" 枪托", -- ———— 乔斯林 O/U 12G
["bm_wp_r870_s_solid"] = "标准枪托", -- ———— 火车头 12G
["bm_wp_serbu_s_solid_short"] = "\"警用短版\" 枪托", -- ———— 火车头 12G
["bm_wp_serbu_s_nostock_short"] = "\"不能再小\" 战术枪托", -- ———— 火车头 12G
["bm_wp_m37_s_short"] = "侦查枪托", -- ———— GSPS 12G
["addation_4bf0a7f332ead7a4"] = "亡命徒枪托", -- ———— 克莱尔 12G
["addation_591d4ec383cf616a"] = "\"匠人\" 枪托", -- ———— 赖因费尔德 88

-- ———— 上机匣
["bm_wp_r870_body_rack"] = "弹药架", -- ———— 瑞恩斐德 880


-- —————— 机枪
-- ———— 枪管
["bm_wp_par_b_short"] = "短枪管", -- ———— KSP 58
["bm_wp_m249_b_long"] = "长枪管", -- ———— KSP
["bm_wp_mg42_b_mg34"] = "\"轻型\" 枪管", -- ———— 撕布机 42
["bm_wp_mg42_b_vg38"] = "\"散热型\" 消音枪管", -- ———— 撕布机 42
["bm_wp_hk21_b_long"] = "长枪管", -- ———— 布伦纳21型
["addation_579e6c9b69e109e2"] = "短枪管", -- ———— M60

-- ———— 脚架
["addation_6ab6d1da5cd8d7f5"] = "脚架", 
["bm_menu_bipod"] = "脚架",
["bm_wp_upg_lmg_lionbipod"] = "\"雄狮\" 脚架",

-- ———— 护木
["bm_wp_rpk_fg_standard"] = "\"战术式\" 护木", -- ———— RPK
["bm_wp_m249_fg_mk46"] = "导轨护木", -- ———— KSP
["bm_wp_hk21_fg_short"] = "短护木", -- ———— 布伦纳21型
["addation_c1d57e78d7f1d68c"] = "\"现代化\" 护木", -- —— M60
["addation_60947fbda74eda3a"] = "\"战术式\" 护木", -- —— M60
["addation_b67f364dac20f891"] = "\"热带型\" 护木", -- —— M60

-- ———— 枪托
["bm_wp_rpk_s_standard"] = "\"塑料制\" 枪托", -- ———— RPK
["bm_wp_par_s_plastic"] = "\"塑料制\" 枪托", -- ———— KSP 58
["bm_wp_m249_s_solid"] = "固定枪托", -- ———— KSP

-- ———— 握把
["bm_wp_hk21_g_ergo"] = "\"人体工程学\" 握把", -- ———— 布伦纳21型

-- —————— 狙击步枪
-- ———— 枪管
["bm_wp_snp_msr_b_long"] = "长枪管", -- ———— 响尾蛇
["bm_wp_wa2000_b_long"] = "\"加长\" 枪管", -- ———— 嗜命者.308
["bm_wp_wa2000_b_suppressed"] = "\"闷声\" 枪管", -- ———— 嗜命者.308
["addation_041b591e207db20f"] = "长枪管", -- ———— 沙漠之狐
["addation_5a8b95399e5bbb88"] = "消音枪管", -- ———— 沙漠之狐
["addation_1832c609c8915e59"] = "\"合约人\" 抑制器", -- ———— 合约人.308 
["bm_wp_r93_b_short"] = "短枪管", -- ———— R93
["bm_wp_r93_b_suppressed"] = "\"以小补大\" 抑制器", -- ———— R93
["bm_wp_winchester_b_long"] = "\"远程\" 枪管", -- ———— 1874连珠枪
["bm_wp_winchester_b_suppressed"] = "\"亡命鸳鸯\" 消音枪管", -- ———— 1874连珠枪
["addation_3efa5a10a643e517"] = "\"格列维奇\" 补偿器", -- ———— 霹雳
["addation_38e4be19055a21fd"] = "\"无声\" 消音器", -- ———— 霹雳
["bm_wp_mosin_b_short"] = "短枪管", -- ———— 纳甘
["bm_wp_mosin_b_long"] = "长枪管", -- ———— 纳甘
["bm_wp_mosin_b_sniper"] = "消音枪管", -- ———— 纳甘
["bm_wp_m95_b_barrel_long"] = "反坦克枪管", -- ———— 死神.50
["bm_wp_m95_b_barrel_short"] = "CQB枪管", -- ———— 死神.50
["bm_wp_m95_b_barrel_suppressed"] = "消音枪管", -- ———— 死神.50
["addation_5e174d065a08f775"] = "短枪管", -- ———— R700
["addation_14977e1920131103"] = "中等枪管", -- ———— R700
["addation_3b11f4de152f431c"] = "\"一点入云\" 枪管", -- ———— 伯奈特远距打击者
["addation_b88ce102e41d626a"] = "\"随风呼啸\" 枪管", -- ———— 伯奈特远距打击者
["addation_9d551481156c6451"] = "KA-ZD1A长枪管", -- ———— 工业军工 X1
["addation_d04342dd929321a7"] = "KA-ZD1B短枪管", -- ———— 工业军工 X1

-- ———— 军刺
["bm_menu_bayonet"] = "军刺",
["bm_wp_mosin_ns_bayonet"] = "纳甘军刺", -- ———— 纳甘

-- ———— 枪口配件
["bm_wp_snp_msr_ns_suppressor"] = "\"狙击用\" 抑制器", -- ———— 响尾蛇
["addation_4ad48caaaad91672"] = "\"鸟喙\" 抑制器", -- ———— 鸭嘴兽 70

-- ———— 附属配件
["bm_wpn_fps_upg_o_45iron"] = "斜角机械瞄具",

-- ———— 瞄准镜
["bm_wp_upg_o_leupold"] = "\"忒伊亚\" 高倍瞄准镜",
["addation_8c8d603d9098d9a7"] = "\"盒兄\" 瞄准镜", 
["bm_wp_model70_iron_sight"] = "机械瞄具", -- ———— 鸭嘴兽 70
["bm_wp_winchester_sniper_scope"] = "A5瞄准镜", -- ———— 1874连珠枪
["addation_54c809e13fdf25dc"] = "机械瞄具", -- ———— 霹雳
["bm_wp_mosin_iron_sight"] = "机械瞄具", -- ———— 纳甘
["addation_14cbd68e6edfa60e"] = "KA-ZD032机械瞄具", -- ———— 工业军工 X1

-- ———— 枪托
["bm_wp_msr_body_msr"] = "战术铝制枪身", -- ———— 响尾蛇
["bm_wp_wa2000_g_light"] = "\"轻化\" 枪身", -- ———— 嗜命者.308
["bm_wp_wa2000_g_stealth"] = "\"隐蔽\" 枪身", -- ———— 嗜命者.308
["bm_wp_wa2000_g_walnut"] = "\"胡桃木\" 枪身", -- ———— 嗜命者.308
["bm_wp_r93_body_wood"] = "\"纯木制\" 枪身", -- ———— R93
["addation_de7fbd6148d5240c"] = "\"轻型\" 枪托", -- ———— 霹雳
["bm_wp_mosin_body_conceal"] = "可拆式枪托", -- ———— 纳甘
["addation_ffeb90a35d9ee34f"] = "\"军用\" 枪身", -- ———— R700
["addation_f942cb0063ebf0cb"] = "\"战术式\" 枪身", -- ———— R700
["addation_a755590086ba979e"] = "\"社团\" 枪托 + 弹药架", -- ———— 伯奈特远距打击者

-- ———— 弹匣
["addation_d6e71e2a6bcc7a65"] = "KA-ZDM2扩容弹匣", -- ———— 工业军工 X1

-- —————— 特殊
-- ———— 弹药
["bm_wp_upg_a_bow_poison"] = "剧毒箭矢", -- ———— 大地奇兵
["bm_wpn_fps_upg_a_bow_explosion"] = "爆破箭矢", -- ———— 大地奇兵
["bm_wp_upg_a_arblast_poison"] = "剧毒弩矢", -- ———— 重弩
["bm_wp_upg_a_arblast_explosion"] = "爆破弩矢", -- ———— 重弩
["bm_wp_bow_long_poison"] = "剧毒箭矢", -- ———— 英格兰长弓
["bm_wp_bow_long_explosion"] = "爆破箭矢", -- ———— 英格兰长弓
["bm_wp_upg_a_frankish_poison"] = "剧毒弩矢", -- ———— 轻弩
["bm_wp_upg_a_frankish_explosion"] = "爆破弩矢", -- ———— 轻弩
["addation_50342c8b32300540"] = "剧毒箭矢", -- ———— DECA
["addation_1b9d7089bada5059"] = "爆破箭矢", -- ———— DECA
["bm_wp_upg_a_grenade_launcher_incendiary"] = "燃烧榴弹",
["bm_wp_fla_mk2_mag_rare"] = "三分熟", -- ———— Mk.1
["bm_wp_fla_mk2_mag_welldone"] = "九分熟", -- ———— Mk.1
["addation_f999df9d23f041db"] = "剧毒弩矢", -- ———— 高压气动弩
["addation_1c0108d71bb75851"] = "爆破弩矢", -- ———— 高压气动弩
["bm_wp_upg_a_crossbow_poison"] = "剧毒弩矢", -- ———— 手枪弩
["bm_wp_upg_a_crossbow_explosion"] = "爆破弩矢", -- ———— 手枪弩

-- ———— 枪管
["bm_wp_m134_barrel_extreme"] = "\"空袭\" 枪管", -- ———— 火神
["bm_wp_m134_barrel_short"] = "\"半截\" 枪管", -- ———— 火神
["bm_wp_m32_barrel_short"] = "短枪管", -- ———— 小猪
["bm_wp_m79_barrel_short"] = "\"掠夺\" 枪管", -- ———— GL40
["bm_wp_bow_hunter_b_carbon"] = "炭纤弩臂", -- ———— 手枪弩
["bm_wp_bow_hunter_b_skeletal"] = "骨质弩臂", -- ———— 手枪弩
["addation_dffb1b9e9b221825"] = "隼型枪口", -- ———— MA-17
["addation_63b0eae1d1b6bd52"] = "\"炮兵\" 枪管", -- ———— 审判者
["addation_1a7f1a94cc48d222"] = "长枪管", -- ———— 审判者

-- ———— 下机匣
["bm_wp_saw_body_speed"] = "高速马达", -- ———— OVE9000电锯
["bm_wp_saw_body_silent"] = "消音马达", -- ———— OVE9000电锯

-- ———— 握把
["addation_a9c60e150e492805"] = "\"人体工程学\" 握把", -- ———— DECA
["addation_f3eff028d237d7f5"] = "木制握把", -- ———— DECA
["bm_wp_bow_hunter_g_camo"] = "迷彩握把", -- ———— 手枪弩
["bm_wp_bow_hunter_g_walnut"] = "胡桃木握把", -- ———— 手枪弩

-- ———— 额外部件
["bm_wp_m134_body_upper_light"] = "\"我只带一半子弹\"", -- ———— 火神

-- ———— 弹匣
["bm_wp_saw_m_blade_sharp"] = "锋利锯片", -- ———— OVE9000电锯
["bm_wp_saw_m_blade_durable"] = "耐久锯片", -- ———— OVE9000电锯
["addation_c57befe3a5b94948"] = "低温燃料", -- ———— MA-17
["addation_ab67ec0227db4a14"] = "高温燃料", -- ———— MA-17

-- ———— 枪托
["bm_wp_m32_no_stock"] = "无枪托", -- ———— 小猪
["bm_wp_gre_m79_s_leather"] = "截短枪托", -- ———— GL40
["addation_85c03f33b5055510"] = "\"轻型\" 枪托", -- ———— 高压气动弩
["bm_wp_china_stock_short"] = "暴乱枪托", -- ———— 中国泡芙

-- ———— 上机匣
["addation_c452586c2688e2dc"] = "\"XS式\" 枪管", -- ———— XL 5.56
["addation_a51c72409e31dd52"] = "\"散热式\" 枪管", -- ———— XL 5.56
["addation_04ea8b4686c6d601"] = "\"XS散热式\" 枪管", -- ———— XL 5.56
["addation_a54c5eccfbd98077"] = "战术骨架", -- ———— DECA

-- —————— 冲锋枪
-- ———— 枪管
["bm_wp_smg_m45_b_small"] = "\"黄油枪\" 枪管", -- ———— 瑞典K型
["bm_wp_smg_m45_b_green"] = "\"瑞典式\" 枪管", -- ———— 瑞典K型
["bm_wp_cobray_ns_barrelext"] = "散热延长枪管", -- ———— 夹克男的小玩意
["bm_wp_cobray_ns_silencer"] = "韦贝尔的抑制器", -- ———— 夹克男的小玩意
["addation_5fd8d404d7dfdb91"] = "中等枪管", -- ———— CR 805B
["addation_d6b1a72d906d6d08"] = "短枪管", -- ———— CR 805B
["bm_wp_mp5_fg_m5k"] = "\"短小精悍\" 枪管", -- ———— 紧凑五型
["bm_wp_mp5_fg_mp5a5"] = "\"警用战术式\" 护木", -- ———— 紧凑五型
["bm_wp_mp5_fg_mp5sd"] = "\"忍者\" 枪管", -- ———— 紧凑五型
["addation_8cdcf7f0d5c0449b"] = "\"减重\" 护木", -- ———— 紧凑五型
["bm_wp_m1928_b_short"] = "短粗枪管", -- ———— 芝加哥打字机
["bm_wp_m1928_b_long"] = "长枪管", -- ———— 芝加哥打字机
["bm_wp_scorpion_b_suppressed"] = "标准抑制器", -- ———— 眼镜蛇
["bm_wp_mp9_b_suppressed"] = "\"战术式\" 抑制器", -- ———— CMP
["bm_wp_m4_uupg_b_medium"] = "中等枪管", -- ———— 伞兵
["bm_wp_baka_b_comp"] = "定制枪管", -- ———— 微型乌兹
["addation_815cb7f7b09fd2b9"] = "民用枪管", -- ———— 豺狼
["bm_wp_tec9_b_standard"] = "短枪管", -- ———— 冲击波 9mm
["bm_wp_tec9_ns_ext"] = "\"音震\" 枪管", -- ———— 冲击波 9mm
["bm_wp_p90_b_long"] = "长枪管", -- ———— 克巴斯90
["bm_wp_p90_b_civilian"] = "\"民间通用\" 枪管", -- ———— 克巴斯90
["bm_wp_p90_b_ninja"] = "\"商城忍者\" 枪管", -- ———— 克巴斯90
["bm_wp_sterling_b_long"] = "长枪管", -- ———— 帕切特 L2A1
["bm_wp_sterling_b_short"] = "短枪管", -- ———— 帕切特 L2A1
["bm_wp_sterling_b_suppressed"] = "消音枪管", -- ———— 帕切特 L2A1
["bm_wp_sterling_b_e11"] = "\"散热型\" 消音枪管", -- ———— 帕切特 L2A1
["addation_0fe392bc77d90a65"] = "BY90大号抑制器", -- ———— AK21
["addation_7c51d682d9fe6e29"] = "MG8精准枪管", -- ———— AK21
["addation_5e4b4925adfad214"] = "MS10短枪管", -- ———— 美弥华 10 特殊型

-- ———— 枪口配件
["bm_wp_mp7_b_suppressed"] = "消音枪管", -- ———— 特战
["bm_wp_m1928_fg_discrete"] = "快拆式护木", -- ———— 芝加哥打字机
["bm_wp_baka_b_longsupp"] = "\"太卷寿司\"抑制器", -- ———— 微型乌兹
["bm_wp_baka_b_smallsupp"] = "\"寿司卷\" 抑制器", -- ———— 微型乌兹
["bm_wp_baka_b_midsupp"] = "\"春卷寿司\" 抑制器", -- ———— 微型乌兹
["addation_1e8e1ba483f263aa"] = "\"静默\" 抑制器", -- ———— 豺狼
["bm_wp_sr2_ns_silencer"] = "\"寂静\" 抑制器", -- ———— 希瑟
["bm_wp_polymer_barrel_precision"] = "精准枪管", -- ———— 纵横交错
["bm_wp_polymer_ns_silencer"] = "HPS抑制器", -- ———— 纵横交错
["bm_wp_uzi_b_suppressed"] = "\"寂静杀手\" 抑制器", -- ———— 乌兹

-- ———— 护木
["bm_wp_m4_uupg_fg_rail"] = "导轨护木", -- ———— 伞兵
["bm_wp_upg_smg_olympic_fg_lr300"] = "\"配件商短制\" 护木", -- ———— 伞兵
["addation_5825d07d1ebb8a79"] = "短护木", -- ———— 署名
["bm_wp_akmsu_fg_rail"] = "\"莫斯科特别版\" 导轨", -- ———— 卡拉科夫
["bm_wp_upg_ak_fg_zenit"] = "铝制护木", -- ———— 卡拉科夫
["bm_wp_uzi_fg_rail"] = "\"战术式\" 护木", -- ———— 乌兹

-- ———— 附属配件
["bm_wp_mac10_body_ris"] = "导轨机匣", -- ———— 马克十型

-- ———— 下机匣
["addation_8a16934a2e3b8ca6"] = "定制枪身", -- ———— 马克十型
["addation_6ead2a4e18bc404e"] = "定制突击枪身", -- ———— 克巴斯90

-- ———— 握把
["bm_wp_smg_m45_g_bling"] = "\"星钻\" 握把", -- ———— 瑞典K型
["bm_wp_smg_m45_g_ergo"] = "\"人体工程学\" 握把", -- ———— 瑞典K型
["bm_wp_m1928_g_discrete"] = "快拆式握把", -- ———— 芝加哥打字机
["bm_wp_scorpion_g_ergo"] = "\"人体工程学\" 握把", -- ———— 眼镜蛇
["bm_wp_scorpion_g_wood"] = "木制握把", -- ———— 眼镜蛇
["addation_23704a2f01ab0143"] = "MS10木制舒适握把", -- ———— 美弥华 10 特殊型

-- ———— 弹匣
["bm_wp_smg_m45_m_extended"] = "扩容弹匣", -- ———— 瑞典K型
["bm_wp_mp7_m_extended"] = "扩容弹匣", -- ———— 特战
["bm_wp_mac10_m_extended"] = "扩容弹匣", -- ———— 马克十型
["bm_wp_mp5_m_straight"] = "\"直式\" 弹匣", -- ———— 紧凑五型
["bm_wp_scorpion_m_extended"] = "扩容弹匣", -- ———— 眼镜蛇
["bm_wp_mp9_m_extended"] = "扩容弹匣", -- ———— CMP
["addation_8dba9a5bacaef576"] = "扩容弹匣", -- ———— 署名
["addation_bd910dca0c3364a5"] = "扩容弹匣", -- ———— 豺狼
["addation_498e40fe3d1ae321"] = "短弹匣", -- ———— 豺狼
["bm_wp_tec9_m_extended"] = "扩容弹匣", -- ———— 冲击波 9mm
["bm_wp_sterling_m_long"] = "扩容弹匣", -- ———— 帕切特 L2A1
["bm_wp_sterling_m_short"] = "短弹匣", -- ———— 帕切特 L2A1
["addation_9cb145d5e5bf4583"] = "MS10快拔弹匣", -- ———— 美弥华 10 特殊型

-- ———— 枪托
["bm_wp_smg_m45_s_folded"] = "折叠枪托", -- ———— 瑞典K型
["bm_wp_mp7_s_long"] = "展开枪托", -- ———— 特战
["bm_wp_mac10_s_skel"] = "\"骨架形\" 枪托", -- ———— 马克十型
["bm_wp_mp5_s_adjust"] = "\"可调式\" 枪托", -- ———— 紧凑五型
["bm_wp_mp5_s_ring"] = "\"近乎没有\" 枪托", -- ———— 紧凑五型
["addation_d5c6974c7351ba30"] = "\"朴素\" 枪托", -- ———— 紧凑五型
["bm_wp_m1928_s_nostock"] = "快拆式悬带扣", -- ———— 芝加哥打字机
["bm_wp_m1928_s_discrete"] = "快拆式枪托", -- ———— 芝加哥打字机
["bm_wp_scorpion_s_nostock"] = "无枪托", -- ———— 眼镜蛇
["bm_wp_scorpion_s_unfolded"] = "展开枪托", -- ———— 眼镜蛇
["bm_wp_mp9_s_skel"] = "\"骨架形\" 枪托", -- ———— CMP
["bm_wp_olympic_s_short"] = "\"一短再短\" 枪托", -- ———— 伞兵
["bm_wp_baka_s_standard"] = "无枪托", -- ———— 微型乌兹
["bm_wp_baka_s_unfolded"] = "展开枪托", -- ———— 微型乌兹
["addation_a1108ed2a7586968"] = "无枪托", -- ———— 署名
["addation_2b839d039c7dc083"] = "民用枪托", -- ———— 豺狼
["addation_d2972e165789fe46"] = "折叠枪托", -- ———— 豺狼
["addation_c8aeffbd40bda5c2"] = "折叠枪托", -- ———— MP40
["bm_wp_sr2_s_unfolded"] = "展开枪托", -- ———— 希瑟
["bm_wp_tec9_s_unfolded"] = "\"拗一拗就出来了\"", -- ———— 冲击波 9mm
["bm_wp_sterling_s_folded"] = "折叠枪托", -- ———— 帕切特 L2A1
["bm_wp_sterling_s_nostock"] = "无枪托", -- ———— 帕切特 L2A1
["bm_wp_sterling_s_solid"] = "固定枪托", -- ———— 帕切特 L2A1
["bm_wp_uzi_s_standard"] = "折叠枪托", -- ———— 乌兹
["bm_wp_uzi_s_solid"] = "固定枪托", -- ———— 乌兹
["bm_wp_uzi_s_leather"] = "人体工程学枪托", -- ———— 乌兹
["addation_4cf58da4baecb483"] = "野牛枪托", -- ———— AK21
["addation_16d39659cf8511f3"] = "MS10战术式枪托", -- ———— 美弥华 10 特殊型

-- ———— 上机匣
["bm_wp_smg_m45_body_green"] = "瑞典枪身", -- ———— 瑞典K型
["bm_wp_cobray_body_upper_jacket"] = "80年代的呼唤", -- ———— 夹克男的小玩意

-- ———— 垂直握把
["bm_menu_vertical_grip"] = "垂直握把",
["addation_d094e2d35fc0383b"] = "手电握把", -- ———— 豺狼

-- —————— 手枪   注：以奇玛诺88的排列顺序为基准
-- ———— 枪管
["addation_4582fe1fa33b9332"] = "原型枪管", -- ———— 白纹
["bm_wp_sparrow_b_comp"] = "\"镂空\" 导气枪管", -- ———— 沙漠雏鹰
["bm_wp_sparrow_b_threaded"] = "\"螺纹\" 抑制枪管", -- ———— 沙漠雏鹰
["addation_a9df4f69c8597814"] = "\"螺纹\" 枪管", -- ———— 十字杀？忘了写了懒得回去找
["addation_3e1d5125a02ffcd8"] = "加固枪管", -- ———— 帕拉贝鲁
["addation_a8b5f3d4c365bedb"] = "短枪管", -- ———— 帕拉贝鲁
["addation_aa91471af5e754e4"] = "碳氮化钛涂层枪管", -- ———— 5/7 AP
["addation_71a0f3a40363d811"] = "\"恶煞\" 枪管", -- ———— 裁罚.44
["addation_7e15af92cce3efd0"] = "\"威勒\" 枪管", -- ———— 伯奈特自动型
["addation_cb61eda39b79c0e5"] = "\"刺客\" 枪管", -- ———— 捷克式92
["addation_a7ca0c32626fb693"] = "\"射手\" 枪管", -- ———— 伊戈尔全自动
["bm_wp_2006m_b_long"] = "重型枪管", -- ———— 美特尔.357
["bm_wp_2006m_b_medium"] = "中型枪管", -- ———— 美特尔.357
["bm_wp_2006m_b_short"] = "小型枪管", -- ———— 美特尔.357
["addation_d009b29e1cb5e51e"] = "\"歌剧院\" 长枪管", -- ———— 法国制87型
["addation_1a8005e4288137e8"] = "\"拿破仑\" 枪管", -- ———— 法国制87型
["addation_6088a865437b117b"] = "\"沉稳猎手\" 枪管", -- ———— 掌中炮
["bm_wp_rsh12_b_comp"] = "RUS-J长谷枪管用稳定器", -- ———— RUS-12
["bm_wp_rsh12_b_short"] = "RUS-K战术短枪管", -- ———— RUS-12
["bm_wp_type54_b_long"] = "KA54枪管延长部件", -- ———— 工业军工 54型

-- ———— 枪口配件(通用)
["bm_wp_upg_ns_ipsccomp"] = "IPSC补偿器",
["bm_wp_upg_ns_medium_gem"] = "\"罗特\" 抑制器",
["bm_wp_upg_ns_large_kac"] = "\"冠军\" 抑制器",
["bm_wp_upg_ns_meatgrinder"] = "\"颜面打击\" 补偿器",
["bm_wp_upg_ns_pis_medium"] = "\"基础威胁\" 抑制器",
["bm_wp_upg_ns_pis_small"] = "\"大小是浮云\" 抑制器",
["bm_wp_upg_ns_pis_large"] = "\"巨石\" 抑制器",
["bm_wp_upg_ns_pis_medium_slim"] = "\"无菌\" 抑制器",
["bm_wp_upg_pis_ns_flash"] = "手枪消焰器",
["bm_wp_upg_ns_ass_filter"] = "\"低成本\" 抑制器",
["bm_wp_upg_ns_pis_jungle"] = "\"丛林忍者\" 抑制器",
["addation_a73d9832bfd8c5df"] = "\"飓风\"补偿器", 

-- ———— 枪口配件
["bm_wp_usp_co_comp_1"] = "\"排气式\" .45用补偿器", -- ———— 拦截者.45
["bm_wp_usp_co_comp_2"] = "\"高速式\" .45用补偿器", -- ———— 拦截者.45
["bm_wp_p226_co_comp_1"] = "\"排气式\" .40用补偿器", -- ———— 署名.40
["bm_wp_p226_co_comp_2"] = "\"高速式\" .40用补偿器", -- ———— 署名.40
["bm_wp_1911_co_2"] = "\"进攻者\" 补偿器", -- ———— 十字杀
["bm_wp_1911_co_1"] = "\"惩罚者\" 补偿器", -- ———— 十字杀
["bm_wp_beretta_co_co2"] = "\"竞赛用\" 补偿器", -- ———— 伯奈特 9型
["bm_wp_beretta_co_co1"] = "\"专业版\" 补偿器", -- ———— 伯奈特 9型
["bm_wp_g18c_co_1"] = "\"排气式\" 补偿器", -- ———— 定制版 / 突袭18C
["bm_wp_g18c_co_comp_2"] = "\"高速式\" 补偿器", -- ———— 定制版 / 突袭18C
["bm_wp_c96_nozzle"] = "D.L44型喷嘴", -- ———— 扫帚柄
["addation_3d7e384d16f9fb66"] = "\"合约人\" 补偿器", -- ———— 合约人
["bm_wp_deagle_co_short"] = "\"小美人\" 补偿器", -- ———— 沙鹰
["bm_wp_deagle_co_long"] = "\"大狂杀\" 补偿器", -- ———— 沙鹰

-- ———— 额外部件
["bm_wp_pis_rage_extra"] = "野马镜桥", -- ———— 野马.44
["bm_wp_pis_deagle_extra"] = "沙鹰镜桥", -- ———— 沙鹰


-- ———— 附属配件(通用)
["bm_wp_upg_fl_crimson"] = "\"微型\" 镭射模块",
["bm_wp_upg_fl_x400v"] = "\"光电结合\" 照明模块",
["bm_wp_upg_fl_pis_tlr1"] = "\"战术式\" 手枪手电",
["bm_wp_upg_fl_pis_laser"] = "\"便携式\" 镭射模块",
["bm_wp_upg_fl_pis_m3x"] = "聚合物手电",

-- ———— 握把
["bm_wp_pis_g_laser"] = "\"镭射结合式\" 握把", -- ———— 88
["bm_wp_pis_g_beavertail"] = "\"鸭嘴兽\" 握把", -- ———— 88
["bm_wp_pis_ppk_g_laser"] = "\"镭射结合式\" 握把", -- ———— 古博克兹
["bm_wp_p226_g_ergo"] = "\"人体工程学\" 握把", -- ———— 署名.40
["bm_wp_1911_g_ergo"] = "\"人体工程学\" 握把", -- ———— 十字杀
["bm_wp_1911_g_bling"] = "\"星钻\" 握把", -- ———— 十字杀
["bm_wp_1911_g_engraved"] = "\"雕花款\" 十字杀握把", -- ———— 十字杀
["bm_wp_beretta_g_ergo"] = "\"人体工程学\" 握把", -- ———— 伯奈特 9型
["bm_wp_beretta_g_engraved"] = "\"雕花\" 伯奈特握把", -- ———— 伯奈特 9型
["bm_wp_rage_g_ergo"] = "\"纯木制\" \"人体工程学\" 握把", -- ———— 野马.44
["bm_wp_sparrow_g_cowboy"] = "\"史派克\" 握把", -- ———— 沙漠雏鹰
["bm_wp_g18c_g_ergo"] = "\"人体工程学\" 握把", -- ———— 定制版 / 突袭18C
["addation_97d3fd101e279c11"] = "\"雕花\" 握把", -- ———— 帕拉贝鲁
["addation_7c725e8906467213"] = "\"狂欢\" 握把",  -- ———— 裁罚.44
["addation_9199d1de615bebd2"] = "\"十字架\" 握把",  -- ———— 裁罚.44
["addation_23bb7335c9b68895"] = "\"闪钻\" 握把", -- ———— 十字杀警卫
["addation_78db7a9eabc41705"] = "\"人体工程学\" 握把", -- ———— 十字杀警卫
["addation_113c20d7f90a9032"] = "\"威勒\" 握把", -- ———— 伯奈特自动型
["addation_3d55f643c387a33e"] = "\"联盟\" 握把", -- ———— 伯奈特自动型
["addation_5f8fd7816ca05345"] = "\"联盟\" 握把", -- ———— 捷克式92
["addation_616fbd77d3d67ef0"] = "\"刺客\" 握把", -- ———— 捷克式92
["addation_9169451ee9acbab7"] = "\"射手\" 握把", -- ———— 伊戈尔全自动
["addation_97525bbecbfdacdd"] = "\"联盟\" 握把", -- ———— 伊戈尔全自动
["bm_wp_peacemaker_handle_bling"] = "豪华握把", -- ———— 换弹缔造者.45
["bm_wp_2006m_g_bling"] = "\"黑皮\" 握把", -- ———— 美特尔.357
["bm_wp_deagle_g_ergo"] = "\"人体工程学\" 握把", -- ———— 沙鹰
["bm_wp_deagle_g_bling"] = "\"星钻\" 握把", -- ———— 沙鹰
["addation_6f662616e46e9dc8"] = "\"星钻\" 握把", -- ———— 霍尔特 9mm
["addation_baeb8ff268ee7dc5"] = "\"人体工程学\" 握把", -- ———— 霍尔特 9mm
["addation_01d1a0b72ec1a64c"] = "\"骡骨\" 握把", -- ———— 法国制87型
["bm_wp_rsh12_g_wood"] = "RUS木制定制握把", -- ———— RUS-12

-- ———— 下机匣
["addation_c9f23d2815a65279"] = "钛合金定制枪身", -- ———— 伯奈特 9型
["bm_wp_sparrow_body_941"] = "\"史派克\" 枪身套件", -- ———— 沙漠雏鹰
["bm_wp_g26_body_salient"] = "\"精悍\" 枪身套件", -- ———— 紧凑型

-- ———— 弹匣
["bm_wp_g18c_m_mag_33rnd"] = "扩容弹匣", -- ———— 88
["bm_wp_pis_usp_m_extended"] = "扩容弹匣", -- ———— 拦截者.45
["addation_b608934ad52a7f88"] = "\"弹匣我要最大的！\"", -- ———— 拦截者.45
["bm_wp_p226_m_extended"] = "扩容弹匣", -- ———— 署名.40
["bm_wp_1911_m_extended"] = "12发装弹匣", -- ———— 十字杀
["addation_ff167386c5878bb6"] = "\"有美国精神的弹匣！\"",  -- ———— 十字杀
["bm_wp_beretta_m_extended"] = "扩容弹匣", -- ———— 伯奈特 9型
["addation_81e42b8a12e6ca3c"] = "扩容弹匣", -- ———— 白纹
["bm_wp_c96_m_extended"] = "高容量弹匣",-- ———— 扫帚柄
["addation_541c2dd68c1c0dc3"] = "扩容弹匣", -- ———— 5/7 PA
["bm_wp_g26_m_custom"] = "\"精悍\" 弹匣", -- ———— 紧凑型
["addation_a7feaa9216912b5c"] = "扩容弹匣", -- ———— 十字杀警卫
["bm_wp_hs2000_m_extended"] = "扩容弹匣", -- ———— 里欧
["addation_fcb81c9c0d6ee44d"] = "扩容弹匣", -- \
["addation_80c6b035932a7514"] = "扩容弹匣", --  ———— 三把垃圾全自动的扩容，哪个是哪个懒得查
["addation_5525cf6514b070d0"] = "扩容弹匣", -- /
["bm_wp_deagle_m_extended"] = "扩容弹匣", -- ———— 沙鹰
["addation_f0b27cfd7918a901"] = "扩容弹匣", -- ———— 霍尔特 9mm
["addation_af0e273e690e6aa8"] = "十字杀专用 扩容弹匣", -- ———— 掌中炮
["bm_wp_type54_m_ext"] = "KA54扩容弹匣", -- ———— 工业军工 54型

-- ———— 瞄准镜(通用)
["bm_wp_upg_o_rmr"] = "\"手枪用红点\" 瞄准镜",
["addation_0387e4e813744970"] = "\"方针全息式\" 瞄准镜", 
["addation_ec2d3f25b2ff784d"] = "\"骨架反射式\"微型瞄准镜", 
["bm_wp_upg_o_marksmansight_rear"] = "\"射手\" 机械瞄具",

-- ———— 瞄准镜
["bm_wp_c96_sight"] = "44型瞄准镜", -- ———— 扫帚柄
["addation_550c9fa6239737bc"] = "\"氚光管\" 机械瞄具", -- ———— 这个也忘了写（

-- ———— 套筒
["bm_menu_slide"] = "套筒",
["bm_wp_pis_usp_b_match"] = "\"竞技用\" 套筒", -- ———— 拦截者.45
["bm_wp_pis_usp_b_expert"] = "\"专业版\" 套筒", -- ———— 拦截者.45
["bm_wp_pis_ppk_b_long"] = "长套筒", -- ———— 古博克兹
["bm_wp_p226_b_equinox"] = "\"双色\" 套筒", -- ———— 署名.40
["bm_wp_p226_b_long"] = "长套筒", -- ———— 署名.40
["bm_wp_1911_b_vented"] = "排气套筒", -- ———— 十字杀
["bm_wp_1911_b_long"] = "加长型排气套筒", -- ———— 十字杀
["bm_wp_rage_b_comp1"] = "\"进攻者\" 枪管", -- ———— 野马.44
["bm_wp_rage_b_short"] = "\"口袋惊喜\" 枪管", -- ———— 野马.44
["bm_wp_rage_b_comp2"] = "\"排气\" 枪管", -- ———— 野马.44
["bm_wp_rage_b_long"] = "\"超长平衡\" 枪管", -- ———— 野马.44
["bm_wp_g22c_b_long"] = "长套筒", -- ———— 定制版
["bm_wp_c96_b_long"] = "精准枪管", -- ———— 扫帚柄
["bm_wp_g26_b_custom"] = "\"精悍\" 套筒", -- ———— 紧凑型
["addation_603d8e24cdc33fc6"] = "\"镂空\" 套筒", -- ———— 十字杀警卫
["bm_wp_hs2000_sl_custom"] = "定制套筒", -- ———— 里欧
["bm_wp_hs2000_sl_long"] = "长套筒", -- ———— 里欧
["bm_wp_peacemaker_barrel_long"] = "精准枪管", -- ———— 换弹缔造者.45
["bm_wp_peacemaker_barrel_short"] = "枪斗枪管", -- ———— 换弹缔造者.45
["bm_wp_deagle_b_long"] = "长枪管", -- ———— 沙鹰
["addation_f2c03e75319f3318"] = "定制排气孔枪管", -- ———— 沙鹰
["addation_b948d033fae5ba32"] = "十字杀专用 \"白金公牛\" 套筒", -- ———— 掌中炮

-- ———— 枪托
["bm_wp_c96_s_solid"] = "枪套枪托", -- ———— 扫帚柄
["bm_wp_g18c_s_stock"] = "专用枪托", -- ———— 突袭18C
["addation_b7dbfea4ad52fbaf"] = "\"联邦\" 枪托", -- ———— 伯奈特自动型
["addation_3e02e060f8a04cc6"] = "\"射手\" 枪托", -- ———— 捷克式92
["addation_6cf9749776c10439"] = "\"联邦\" 枪托", -- ———— 伊戈尔全自动
["bm_wp_peacemaker_rifle_stock"] = "老本大爷的枪托", -- ———— 换弹缔造者.45

-- ———— 上机匣
["bm_wp_beretta_sl_brigadier"] = "\"精英\" 套筒", -- ———— 伯奈特 9型
["bm_wp_rage_body_smooth"] = "修长枪身", -- ———— 野马.44

-- ———— 找不到具体是啥的文本，但我很确定游戏内会显示
["addation_deacf959a3466506"] = "扩容弹匣", 
["bm_wp_r870_s_solid_single"] = "\"政府需求\" 战术枪托",

-- ———— 下挂配件(目前只有 工业军工 54型 有)
["addation_1d65e35f3d1c7031"] = "下挂配件", 
["addation_00bb94edd2df3d1d"] = "下挂配件", -- ———— 双持？
["bm_wp_type54_underbarrel"] = "KA54 \"阻牛器\" 配件", -- ———— 工业军工 54型
["bm_wp_type54_underbarrel_piercing"] = "KA54 \"阻牛器\" 配件(箭型弹)", -- ———— 工业军工 54型
["bm_wp_type54_underbarrel_slug"] = "KA54 \"阻牛器\" 配件(AP独头弹)", -- ———— 工业军工 54型
["addation_7016ac828d8e27ad"] = "龙息弹", 
["addation_09826be1dd11d4eb"] = "HE高爆弹", 

-- —————————— *附加 配件描述
-- ———— 镭射/侧瞄/放大镜/脚架
["bm_wp_upg_fl_ass_laser_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_ass_peq15_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_ass_smg_sho_peqbox_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_ass_smg_sho_surefire_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_ass_utg_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_crimson_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_pis_laser_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_pis_m3x_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_pis_tlr1_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_upg_fl_x400v_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wpn_fps_upg_o_45iron_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_pis_g_laser_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["bm_wp_pis_ppk_g_laser_desc"] = "按下$BTN_GADGET;对配件进行开启/关闭",
["addation_acbfc4f54e3d6f37"] = "按住 $BTN_GADGET;对配件进行开启/关闭", 
["addation_c0090c61c59b140b"] = "按下$BTN_GADGET;对配件进行开启/关闭", 
["addation_acefa334f7243030"] = "按下$BTN_GADGET;对配件进行开启/关闭", 
["addation_5a5847b920d2e59b"] = "按下$BTN_GADGET;对配件进行开启/关闭", 
["addation_436a63a2ba7a2df5"] = "按下$BTN_GADGET;对配件进行开启/关闭", 
["addation_8952e8fe57726cc0"] = "按下$BTN_GADGET;对配件进行开启/关闭", 
["addation_017ecdcd40678f39"] = "按下$BTN_GADGET;对配件进行开启/关闭", 
["bm_wp_upg_lmg_lionbipod_desc"] = "按下$BTN_BIPOD;进行脚架的部署/收回",
["bm_wp_upg_lmg_lionbipod_desc_pc"] = "按下$BTN_BIPOD;进行脚架的部署/收回",

-- ———— 纳甘的军刺
["bm_wp_mosin_ns_bayonet_desc"] = "增加使用近战枪托时的伤害与击倒。",

-- ———— 剧毒/爆炸箭矢
["bm_wp_upg_a_arblast_explosion_desc"] = "在弩矢顶部连接了易爆物的弩矢。在撞击到物体时会引爆。",
["bm_wp_upg_a_arblast_poison_desc"] = "弩矢顶部内涂抹了有毒物的弩矢，在击中后会对敌人造成持续的伤害效果，能使敌人失去反击能力。",
["bm_wp_upg_a_bow_poison_desc"] = "弩矢顶部内涂抹了有毒物的弩矢，在击中后会对敌人造成持续的伤害效果，能使敌人失去反击能力。", -- ———— 不知为何这条被单独出来了
["bm_wp_upg_a_crossbow_explosion_desc"] = "在弩矢顶部连接了易爆物的弩矢。在撞击到物体时会引爆。",
["bm_wp_upg_a_crossbow_poison_desc"] = "弩矢顶部内涂抹了有毒物的弩矢，在击中后会对敌人造成持续的伤害效果，能使敌人失去反击能力。",
["bm_wp_upg_a_frankish_explosion_desc"] = "在弩矢顶部连接了易爆物的弩矢。在撞击到物体时会引爆。",
["bm_wp_upg_a_frankish_poison_desc"] = "弩矢顶部内涂抹了有毒物的弩矢，在击中后会对敌人造成持续的伤害效果，能使敌人失去反击能力。",
["addation_9dc615fbf480948a"] = "在弩矢顶部连接了易爆物的弩矢。在撞击到物体时会引爆。", 
["addation_e07ba648a0eebd06"] = "弩矢顶部内涂抹了有毒物的弩矢，在击中后会对敌人造成持续的伤害效果，能使敌人失去反击能力。", 

-- ———— 霰弹弹药
["bm_wp_upg_a_custom_desc"] = "使用了更大号的弹丸，相较于默认的00型猎鹿弹拥有更大冲击力。", -- ———— 000
["bm_wp_upg_a_custom2_desc"] = "使用了更大号的弹丸，相较于默认的00型猎鹿弹拥有更大冲击力。这种类型的子弹在市场上更为稀有。", -- ———— 社区000？
["bm_wp_upg_a_piercing_desc"] = "能够对远距离目标实施更有效的打击，同时箭形的弹头能够穿透敌人的护甲。", -- ———— 箭形弹
["bm_wp_upg_a_slug_desc"] = "射出一发独头弹，能对敌人的身体及护甲、盾兵所持的盾牌、和部分较薄的墙体进行穿透。", -- ———— 独头
["bm_wp_upg_a_slug2_desc"] = "射出一发独头弹，能对敌人的身体及护甲、盾兵所持的盾牌、和部分较薄的墙体进行穿透。这种类型的子弹在市场上更为稀有。", -- ———— 有社区独头这玩意吗
["bm_wp_upg_a_dragons_breath_desc"] = "在发射同时点燃其中的易燃颗粒的弹药，能烧穿敌人的护甲及盾牌。",
["bm_wp_upg_a_explosive_desc"] = "射出一发高爆弹，弹头爆炸所造成的冲击能够伤害并震慑敌人。这种类型的子弹在市场上更为稀有。",

-- ———— 未知武器（附凤扳龙）
["addation_083b0386d5ac2bbd"] = "机械瞄具", 
["addation_a864ee48e21b4134"] = "标准枪管", 
["addation_2146194e7de3fd79"] = "标准延长枪管", 

-- ———— 屁用没有的小饰品
["bm_menu_charm"] = "小挂件", 
["bm_wp_upg_charm_bag"] = "小挂包", 
["bm_wp_upg_charm_cloaker"] = "Cloacker公仔", 
["bm_wp_upg_charm_dallas"] = "耷拉斯", 
["bm_wp_upg_charm_grenade"] = "摇摇欲炸", 
["bm_wp_upg_charm_piggy"] = "存钱罐公仔", 
["bm_wp_upg_charm_skulldozer"] = "Skulldozer公仔", 
-- ———— 万圣节
["bm_wp_upg_charm_pumpkin"] = "南瓜头公仔", 
["bm_wp_upg_charm_pumpkin"] = "由Luke Millanta制作。", 
-- ———— 恶名3.3
["bm_wp_upg_charm_diamond"] = "血钻", 
["bm_wp_upg_charm_musket"] = "迷你手炮", 
["bm_wp_upg_charm_pyramid"] = "古峰", 
["bm_wp_upg_charm_toast"] = "本的烤面包", 
-- ———— 星风账号
["bm_wp_upg_charm_skullz"] = "骨刺扎堆", 
-- ———— 2021圣诞节/冬日幽灵
["bm_wp_upg_charm_ball"] = "圣诞彩球", 
["bm_wp_upg_charm_choco"] = "暖心热巧", 
["bm_wp_upg_charm_flake"] = "寒冷尖角", 
["bm_wp_upg_charm_igloo"] = "小小冰屋", 
["bm_wp_upg_charm_lusse"] = "藏红花面包", 
["bm_wp_upg_charm_snow"] = "冬日老雪人", 

-- ——————————————————————近战(共186条)——————————————————————
["bm_melee_weapon"] = "枪托",
["bm_melee_weapon_desc"] = "在武装抢劫当中，用枪托殴打平民通常都比射杀或刺伤他们来的快捷。通常来说，你要么是拿枪屁股去抡人，要么是拿枪把子去锤人。",
["bm_melee_fists"] = "拳头",
["bm_melee_fists_desc"] = "虽然你不是拳击手，但你还是能靠大力出奇迹的。只需要一些力量、速度和恰当的时机，你就可以一拳瞬间把人锤懵逼。",
["bm_melee_brass_knuckles"] = "350K黄铜指虎",
["bm_melee_brass_knuckles_desc"] = "指虎类的武器已经存在于世数百年了。黄铜指虎能将出拳的力量集中在更小更坚硬的区域，增加其造成的组织损伤。打得够狠的话你甚至能把骨头打断。",
["bm_melee_kabar_tanto"] = "Ursa坦托式直刀",
-- ———— 描述未知 The URSA Tanto Knife is an exclusive, indestructible fighting/utility knife. it has a tanto blade, shaped like the tip of a Katana; polymer grip; stealth black design. A modern take on the classic URSA Knife.
["bm_melee_toothbrush"] = "诺娃的利刃",
-- ———— 无描述
["bm_melee_kabar"] = "URSA军刀",
["bm_melee_kabar_desc"] = "URSA军刀及其耐磨，坚不可摧 / 其历史可以追溯到1942年。博伊刀片，锯齿刀背，干净利落。绝对的经典。",
["bm_melee_briefcase"] = "50 Blessings 专用手提箱",
-- ———— 无描述
["bm_melee_swagger"] = "短手杖",
-- ———— 无描述
["addation_4fa5e34b51396776"] = "战术手电筒", 
["addation_1d133bef92be64d2"] = "如果你觉得从敌人背后一抡子抡死有些太不公平，为什么不试试用这支手电筒的光线给他们一个善意的提醒呢？(顺带闪瞎他们的狗眼)", 
["addation_e950cf7b6020c938"] = "阿拉巴马剃刀", 
-- ———— 描述未知
["bm_melee_nin"] = "射钉枪",
-- ———— 描述未知
["bm_melee_fork"] = "妈了个叉",
-- ———— 无描述
["bm_melee_spatula"] = "刨丝器",
-- ———— 无描述
["bm_melee_shovel"] = "K.L.A.S.铁锹",
["bm_melee_shovel_desc"] = "K.L.A.S.铁锹被军队广泛用于多种领域。这种铁锹可以说是人手一个了，生存专家、潜水员、野营者、驴友、园丁或是战后重建团队。它也可以作为武器——-利用它锋利的边缘，你可以用它斩开骨肉。如果你正确地去使用它的话，它就这么多功能了。但你从不按套路出牌。",
["bm_melee_moneybundle"] = "一沓钱",
["bm_melee_moneybundle_desc"] = "用皮带捆着一沓钱的做法和钱本身一样古老，毕竟用钱打人这事已经被土豪和皮条客做了好久了。",
["bm_melee_fight"] = "空手道 \"打不过，告辞。\"",
["bm_melee_fight_desc"] = "在遥远海之彼岸的领土内发现的秘密武术。",
["bm_melee_boltcutter"] = "断线钳",
-- ———— 无描述
["bm_melee_shawn"] = "肖恩的羊毛剪",
-- ———— 无描述
["bm_melee_boxcutter"] = "美工刀",
-- ———— 无描述
["bm_melee_microphone"] = "麦克风",
["bm_melee_microphone_desc"] = "你是说麦克风？",
["bm_melee_selfie"] = "自拍杆",
-- ———— 无描述
["bm_melee_bayonet"] = "军刺",
-- ———— 无描述
["bm_melee_gator"] = "弯刀",
-- ———— 无描述
["addation_8d87cc9c51dc655d"] = "铁链鞭", 
-- ———— 描述未知
["addation_752fb83c58e059cf"] = "电击铜指虎", 
-- ———— 无描述
["bm_melee_topaz"] = "破冰镐",
-- ———— 无描述
["addation_762710cb1d3ace8a"] = "迅捷之刃", 
-- ———— 描述未知
["bm_melee_baton"] = "伸缩警棍",
["bm_melee_baton_desc"] = "劫匪和执法者最喜欢用它来控制场面和驱赶暴民了。比起传统的固定警棍，伸缩警棍的优点太多了。轻便而实用，更隐蔽而又更吓人。",
["bm_melee_slot_lever"] = "大乐透",
["bm_melee_slot_lever_desc"] = "在维加斯的赌场中，如果你没点好手气，你就有可能收获这么一个可悲又可笑的\"奖品\"。用它的厄运与失智之力殴打条子们吧。",
["addation_822d776b848857f0"] = "沙锤", 
["addation_5875ab38399b291e"] = "感受那节奏。", 
["addation_338cab45a124d767"] = "不锈钢制注射器", 
["addation_353bd14bada76ac0"] = "不用担心，老老实实说出来你怕针就好，医生是不会觉得你是胆小鬼的。", 
["addation_7c8d0f9c0dff755b"] = "注满毒液的注射器，能对敌人持续造成伤害，并有几率控制敌人。", -- ———— 近战效果描述
["addation_3e83c7437b991e22"] = "剑斗的坦托刀", 
["addation_ae3400a9d868efc0"] = "日本的坦托刀(一种短剑)，其以与匕首相似的造型而出名。", 
["addation_ae1269728523f62f"] = "计划打乱者", 
["addation_63da2bf62eb0fe96"] = "老板打乱了我们的计划, 并告诉我们周六要继续加班.", 
["bm_melee_bat"] = "棒球棍",
-- ———— 无描述
["bm_melee_oldbaton"] = "经典警棍",
["bm_melee_oldbaton_desc"] = "经典是无法被战胜的！",
["bm_melee_hockey"] = "冰球棍",
["bm_melee_hockey_desc"] = "专为冰球运动而设计的硬质冰球棍。某种意义上，它在冰球以外的领域也很有用。",
["bm_melee_ballistic"] = "特种刀具",
-- ———— 无描述
["bm_melee_pugio"] = "潜水刀",
-- ———— 无描述
["addation_ba6566beca112158"] = "刽子手", 
-- ———— 描述未知
["addation_04694acf4fa607dd"] = "便携式ECM(物理)", 
-- ———— 无描述
["bm_melee_kampfmesser"] = "Krieger军刀",
["bm_melee_kampfmesser_desc"] = "Krieger军刀是德军的制式军刀。优秀的刀柄，几何刀头，使它成为近战的绝佳选择。",
["bm_melee_buck"] = "小圆盾",
-- ———— 无描述
["addation_a87fa4dc40254508"] = "蝴蝶刀", 
-- ———— 描述未知
["bm_melee_branding_iron"] = "奴隶刻印",
-- ———— 描述未知
["bm_melee_detector"] = "金属探测器",
["bm_melee_detector_desc"] = "你以后再也不怕钥匙找不着了！",
["bm_melee_croupier_rake"] = "庄家的耙子",
["bm_melee_croupier_rake_desc"] = "用来耙钱的道具？劫匪配上它真是再合适不过了！让这些警察明白明白为什么庄家总会赢。",
["addation_c7511a689fa474a5"] = "双持大风车", 
["addation_c9b4bf55a791c668"] = "Kazaguruma(风车,日语)是把快速而致命的近战武器，削肉如同切黄油。", 
["bm_melee_bullseye"] = "战斗短柄斧",
-- ———— 无描述
["addation_40f69d74dc8e4903"] = "伐木电锯", 
-- ———— 描述未知
["addation_89554f6e258b48e8"] = "大哥大8000x", 
-- ———— 描述未知
["addation_752fb83c58e059cf"] = "电击指虎",
-- ———— 描述未知
["bm_melee_model24"] = "育碧服务器捣烂器",
-- ———— 无描述
["bm_melee_scalper"] = "斩首战斧",
-- ———— 无描述
["bm_melee_switchblade"] = "弹簧刀",
["bm_melee_switchblade_desc"] = "纽约街头青年斗殴时的必备武器，不打架时还能用来打打节拍哼支歌。",
["bm_melee_boxing_gloves"] = "OVERKILL拳击手套",
-- ———— 无描述
["addation_879df6eb7bd78ca8"] = "拳刃匕首", 
-- ———— 描述未知
["addation_5d134b15796774da"] = "警用皮拍", 
-- ———— 描述未知
["bm_melee_meat_cleaver"] = "德拉冈的屠刀",
-- ———— 无描述
["bm_melee_sandsteel"] = "新作武士刀",
-- ———— 无描述
["bm_melee_twins"] = "冲绳风十手",
["bm_melee_twins_desc"] = "冲绳风十手是冲绳岛的执法者的配械，十手同时具有进攻性和防御性，在抢劫时它也是一件用于快速打击任何敌人的完美工具。",
["bm_melee_pitchfork"] = "干草叉",
-- ———— 无描述
["bm_melee_bowie"] = "阿肯色州刺刀",
-- ———— 无描述
["bm_melee_micstand"] = "麦克风支架",
["bm_melee_micstand_desc"] = "让首临舞台的胆怯变为对舞台的统治。",
["bm_melee_chef"] = "杀人狂的刀",
-- ———— 无描述
["bm_melee_x46"] = "X-46军刀",
-- ———— 无描述
["bm_melee_tiger"] = "手甲钩",
["bm_melee_tiger_desc"] = "当你可以双持两把刀的时候, 你还会只用一把刀吗？",
["bm_melee_beardy"] = "倒钩斧",
-- ———— 无描述
["addation_c44a9944a48dd1d5"] = "铁钩", 
-- ———— 描述未知
["bm_melee_cleaver"] = "切肉刀",
-- ———— 无描述
["bm_melee_taser"] = "电击棍",
["bm_melee_taser_desc"] = "这是你期待已久的东西，它超赞的，用电疗报复这些自鸣得意的Taser吧。食我大招，闪电连击！",
["bm_melee_taser_info"] = "能使其接触目标受到电击控制的装备。", -- ———— 近战效果描述
["bm_melee_mining_pick"] = "淘金热",
-- ———— 无描述
["bm_melee_hammer"] = "极乐木工",
-- ———— 无描述
["bm_melee_shillelagh"] = "克洛芙的实木棍",
-- ———— 无描述
["bm_melee_stick"] = "牧羊人手杖",
-- ———— 无描述
["bm_melee_scoutknife"] = "侦察兵军刀",
-- ———— 无描述
["bm_melee_gerber"] = "Berger 战斗刀",
["bm_melee_gerber_desc"] = "Berger战斗刀是一把流行的折叠战术刀。它使用高科技材料，轻便且便于携带，使它成为一把快速而危险的武器。",
["bm_melee_fairbair"] = "壕坑军刀",
-- ———— 无描述
["bm_melee_tomahawk"] = "生存斧",
["bm_melee_tomahawk_desc"] = "在历史上它被用于多种用途，例如向敌人投掷或者偶尔近身肉搏。这把武器几乎所有罪犯都能一定程度上精通，只有通过正确的抢劫才能使你开始意识到斧头作为工具同时又是武器的真正能力———主要还是作为武器。",
["bm_melee_morning"] = "晨星锤",
-- ———— 无描述
["bm_melee_poker"] = "拔火棍",
-- ———— 无描述
["bm_melee_baseballbat"] = "路西尔棒球棍",
["bm_melee_baseballbat_desc"] = "一把能让你打出全垒打的棒球棍。",
["bm_melee_great"] = "巨剑",
-- ———— 无描述
["bm_melee_whiskey"] = "江城格伦酒瓶",
-- ———— 无描述
["bm_melee_freedom"] = "自由之矛",
-- ———— 无描述
["bm_melee_dingdong"] = "\"叮咚！\"突入工具",
-- ———— 无描述
["bm_melee_tenderizer"] = "松肉锤",
-- ———— 无描述
["bm_melee_machete"] = "大砍刀",
-- ———— 无描述
["bm_melee_becker"] = "多功能砍刀",
["bm_melee_becker_desc"] = "这是一把大砍刀，常在热带国家中被用来在雨林中砍灌木丛，对抗暴乱或用于农业。这把砍刀也常常被用来干其他事，例如撬开椰子、骨头、干庭院活，当然还有抢银行。",
["bm_melee_cqc"] = "苦无",
["bm_melee_cqc_desc"] = "最初被当作农具使用，它曾被见于东方暗影刺客的战斗之中。苦无携带方便，手里，咬在嘴里，皮带上或者挂在指间，方便随时准备战斗.",
["bm_melee_rambo"] = "Trautman军刀",
["bm_melee_rambo_desc"] = "Trautman军刀是一把带着重型刀刃的求生刀。它长而带锯齿的刀身和锋利的刀尖使它在丛林和战斗中颇具优势。",
["bm_melee_fireaxe"] = "消防斧",
-- ———— 无描述
["addation_298dc5629eac66be"] = "双手大直尺", 
["addation_a555daaa49b7535f"] = "这把大直尺是我们做过最大的一个。别看它又大又粗，拿来做测量活一点也不费劲和尴尬。", 
["addation_792bd4dd420ae64b"] = "拳刺匕首", 
-- ———— 描述未知
["addation_041c0330377bc6fd"] = "掘地三尺勺", 
-- ———— 无描述
["addation_aa493f2b80a65193"] = "纯金三尺勺", 
["addation_fa2e4a25bb6c4a46"] = "完成成就\"最大的勺子送给最好的你\"解锁", -- ———— 解锁条件

-- ——————————————————————护甲(共16条)——————————————————————
["bm_menu_armors"] = "护甲",
["bm_armor_level_1"] = "两件套西服",
["bm_armor_level_1_desc"] = "毫不影响行动，完全不引人注目。$NL;$NL;任何有自尊心的罪犯都应该穿着的基本两件套西装。$NL;$NL;它不会为你提供额外的防护，但它拥有最高的隐匿性，这使得它成为当你想要神不知鬼不觉地融入人群中再进行抢劫时的最佳选择。$NL;$NL;\"西服通常是为一些特殊场合准备的，例如婚礼，葬礼，还有抢劫。\"",
["bm_armor_level_2"] = "轻型防弹背心",
["bm_armor_level_2_desc"] = "对行动力有轻微影响，不易被察觉。$NL;$NL;轻型防弹背心易于穿戴，属于较为便携的防弹护甲。其内置的特质夹层能有效地吸收你所受到的伤害，使它成为自卫时的不二之选。$NL;$NL;\"轻型防弹背心被政治官员、重要人员，乃至空军士官、行政及外交安保人员所广泛使用。\"",
["bm_armor_level_3"] = "标准防弹背心",
["bm_armor_level_3_desc"] = "对行动力有轻微影响，不易被察觉。$NL;$NL;防弹背心是一件穿戴在上躯干的标准软质护甲。它能很好地承受小口径手枪及霰弹枪的弹丸。对于穿越在战线中的人，它是必不可少的装备。$NL;$NL;\"防弹背心常被警务人员、安保人员，以及保镖所使用。\"",
["bm_armor_level_4"] = "重型防弹背心",
["bm_armor_level_4_desc"] = "对行动力有一定影响，容易被人发现。$NL;$NL;重型防弹背心是一件穿戴在上躯干的护甲，内部装有硬质加强夹板。带有护肩和侧翼保护的现代化防弹背心，能有效地提供保护。$NL;$NL;\"重型防弹背心被广泛装备于现役士兵、警部战术单位，和人质救援部队。\"",
["bm_armor_level_5"] = "防弹衣",
["bm_armor_level_5_desc"] = "对行动力有很大影响，容易被人发现。$NL;$NL;该款防弹衣由Gensec安保公司基于其经典款式而研制出的现代化版本，能吸收火器弹药和爆炸破片带来的伤害。$NL;$NL;它结合了重型防弹背心与膀部护具，对脊椎部位有更好的保护。$NL;$NL;\"防弹衣被广泛装备于海军陆战队员、作战士兵和Gensec FTSU作战部队。\"",
["bm_armor_level_6"] = "联合战术防弹衣",
["bm_armor_level_6_desc"] = "对行动力有很大影响，人群中最靓的活靶子。$NL;$NL;为应对来自现代战争的各种挑战，联合战术防弹衣应运而生。它由高性能防弹材料制成，被设计成用于携带大量负载，例如子弹袋、无线电和其他附件。$NL;$NL;\"联合战术防弹衣被现役士兵、特种部队和其他世界军事组织单位使用。\"",
["bm_armor_level_7"] = "改良型联合战术防弹衣",
["bm_armor_level_7_desc"] = "走最慢的路，当最靓的靶子。$NL;$NL;这套改良型联合战术防弹衣是从Gensec安保公司偷来的一件试验原型。$NL;$NL;基于白山基地的技术，它使用了软式与硬式护甲结合的设计。合身的多层紧密纤维层与特制弧度的金属面板相结合，既能够弹开子弹，又能抵御爆炸伤害。总之，它提供了绝对的防御。$NL;$NL;\"非卖品，Gensec安保公司正在极力追回这套护甲。\"",
["bm_menu_armor_max_health_store"] = "可通过前总统天赋储存的最高血量：$amount;",

-- ——————————————————————面具(一堆。)——————————————————————
["bm_msk_bear"] = "马克",
["bm_msk_bear_desc"] = "来自俄罗斯的问候。$NL;$NL;我觉得这是世界上最好的游戏。$NL;$NL;这只是一头熊。$NL;$NL;在这之前都是空白。$NL;$NL;感谢你。$NL;$NL;——— Vasiliy",

-- ———————— 联动
-- ———— 迈阿密热线1
["bm_msk_panther"] = "布兰登",
["bm_msk_panther_desc"] = "布兰登拥有优于常人的移动速度。$NL;$NL;布兰登是只黑豹...虽说如此，其终究也是猫科动物。有意思的是，由于生理构造的原因，猫科动物里只有狮子、老虎、猎豹与美洲豹能够吼叫。这么一想，黑豹这动物就算在同一科里也挺弟弟的。",
["bm_msk_rooster"] = "理查德",
["bm_msk_rooster_desc"] = "理查德喜欢花时间去质问他人。$NL;$NL;你喜欢伤害别人吗？$NL;在电话里给你留言的人是谁？$NL;你现在在哪里？$NL;为什么这段交谈会存在于你我？",
["bm_msk_horse"] = "唐璜",
["bm_msk_horse_desc"] = "唐璜很享受破门而入的感觉。$NL;$NL;咚咚咚，是谁在敲门？唐璜在此，准备好受死。$NL;$NL;顺道提醒一下：在迈阿密热线中，玩家佩戴此面具被靠在墙角完成绝地连杀可以获得2200分奖励。",
["bm_msk_tiger"] = "托尼",
["bm_msk_tiger_desc"] = "托尼会用他的双拳日死胆敢招惹他的人。$NL;$NL;托尼是一名生于70年代的美意混血。他那老虎面具，与他及其粗鲁且暴力的行事风格，使他的形象被深深地刻在无数人的心里。",

-- ———— 迈阿密热线2
["bm_msk_alex"] = "艾里克斯",
["bm_msk_alex_desc"] = "名为艾利克斯的姐弟。$NL;$NL;如同天鹅——他们习性凶猛；但又不同于天鹅——他们利用电锯和微冲杀出一片天地。如同天鹅——他们依靠彼此；但又不同于天鹅——他们为屠杀而生。",
["bm_msk_biker"] = "机车男头盔",
["bm_msk_biker_desc"] = "如果你从骨子里是那种寻求刺激、不计后果，过着得过且过的劫掠生活，那么这点保护措施还是有点必要的。这个道理也适用于手持屠刀胡乱挥砍的疯子。",
["bm_msk_corey"] = "科瑞",
["bm_msk_corey_desc"] = "身为草原中食物链的最底层(还是味道偏好的那种)，你必须得快人一步，利用各种骗术来做到反客为主。科瑞就是这类人的化身。斑马通常习性温顺，热爱和平，且为素食主义者(食草)。前面三点科瑞一点没占。",
["bm_msk_jake"] = "杰克",
["bm_msk_jake_desc"] = "出门撞见蛇可不是什么好事，但如果你遇到的是眼镜蛇，那真是恭喜你，最毒的都被你遇上了;^)$NL;一旦它的扇头展开，那是在向你表示威胁——看到直接跑。它的尖牙足以刺透象皮——看到直接跑。只要一小滴它的毒液就能致人于死地———看到...mmp的看到它直接转身跑就是了，眼镜蛇是会喷毒液的。",
["bm_msk_richter"] = "里克特",
["bm_msk_richter_desc"] = "如同老鼠一般，里克特喜欢暗中杀人。他能设法穿过一切阻碍——潜入安保最严的银行或私宅。他能躲过警卫的一切眼线，同时将死亡如同瘟疫那样散播出去。他杀人不带怜悯，毕竟他只是拿钱办事。", -- ———— 结尾nothing personal我不好说具体是什么意思，结合前文应该指的是杀的人和他无关，但我觉得也能是指他是局外人
["bm_msk_tonys_revenge"] = "托尼的复仇",
["bm_msk_tonys_revenge_desc"] = "近乎完美的捕食者。老虎敏捷且强壮，它们充满暴力，但又极富耐心。它们能暗中尾随，但又能在一瞬间将威胁展现出来。它是完美的杀戮机器。但近年来，野生老虎的数量正在逐渐锐减。由于虎鞭有入药的价值，它已经成为偷猎者的目标。小心别被活捉了。",
["bm_msk_richard_begins"] = "理查德回归——起源",
["bm_msk_richard_begins_desc"] = "这是\"理查德回归\"喷绘前的版本。$NL;$NL;不喜欢原始的版本？这是你改变历史的机会。",
["bm_msk_richard_returns"] = "理查德回归",
["bm_msk_richard_returns_desc"] = "这副面具是心理问题的深层映射吗？没准是分离性人格障碍？还是精神分裂症？精神失常？亦或者说，它什么也不会映射，但它是前面所属症状的诱因？",

-- speedrunner
["bm_msk_hothead"] = "炙热之首",
["bm_msk_hothead_desc"] = "集火山之怒于身，激进的炙热之首将以火焰蔓延般的速度点亮整个夜晚！是什么引燃了他心中的烈火？他又是为了什么而奔跑？很少有人能得到他的回答，毕竟也没几个人快到能跟到他身边去问他。就算跟上了，他的声音也跟不上。",
["bm_msk_speedrunner"] = "急速奔跑者",
["bm_msk_speedrunner_desc"] = "是时候进行急速奔跑了！急速奔跑者是纽冲城区的奔跑冠军。Running, sliding, swinging his way toward crime and those in need, he accepts no less than first place. 奔跑对他来说...就如同生命！",
["bm_msk_falcon"] = "猎鹰头",
["bm_msk_falcon_desc"] = "光是速度快有什么用！隼鹰的快节奏生活使他丢掉了自己的饭碗，于是他化身成为了纽冲城人人都需要的英雄。他力求摧毁那些快节奏的东西，把这座城市还给大家。究竟是这座城市疯了而他正常——还是他疯了而这座城市正常？",
["bm_msk_unic"] = "独角受",
["bm_msk_unic_desc"] = "快看谁来了？是独角受！在纽冲城的阴暗街角里，有什么能明亮的过他的笑容？驰骋于原野，与伙伴在丛间嬉戏，独角受力求于向世人展现这世上的正能量。他的粉色紧身衣和紫色芭蕾鞋着实让他在众奔跑者中脱颖而出！",

-- ———— 圣诞大盗
["addation_a5d2ae89b89d230f"] = "空头支票达拉斯", 
["addation_f4ff137a35aa31f2"] = "空头支票达拉斯终于决定不再靠黑胶布缠脸的形式来掩盖身份，他下定决心用真的达拉斯面具来纪念他的偶像，但那在线打印出的玩意有些货不对板...即便如此，他依旧打算靠着神器(指面具)护体，指挥空头支票帮去洗劫一家中国古董店。监控记录显示空头支票达拉斯在闯进店里时意外撞碎了最大的花瓶。此后他向店主道歉，并抢走了收银机里所有零钱逃了出去。也许那个霓虹笑脸面具下的人还红着脸。", 
["addation_cc529fe71ecbab34"] = "空头支票钱恩斯", 
["addation_5f2d049656c2ffce"] = "空头支票钱恩斯渴望疯狂。但老实说，那个面具下的不过是个找刺激的普通人。当他试图逼自己陷入疯癫时，他在抢劫过程中中在一个警察面前劫持了条贵宾犬你说这是不是脑子有病？他还错选了条凶残的杂种狗。那狗疯咬团队中的每个人，让他们抱头鼠窜。劫案之后的报道称这狗有狂犬病的症状，也许空头支票钱恩斯终将成为他想成为的疯子...", 

-- ———— 挺进地牢联动
["addation_b2e327372d38bb83"] = "子弹头", 
["addation_47bb3b862992022b"] = "装备上他的无限亵渎之剑子弹，子弹倾泻着他所有力量和战斗之心。", 
["addation_a4e2ba78b4bc9ace"] = "军人", 
["addation_72925ee386ad2d5f"] = "马林是Primerdyne研究所的守卫。一场实验事故释放出了空间惧魔，一些人说他擅离职守不管人死活，另外一些人庆祝他是个救了所有人的英雄！", 
["addation_132ee77a77ed75eb"] = "罗伯特", 
["addation_1f666bcdb70ef75e"] = "罗伯特是机械杀戮军团的荣誉成员。当它的主人EMP_R0R命令它杀死人类抵抗组织首领时，它人性未泯没有下手。", 
["addation_72503e65b749f4c9"] = "教徒", 
["addation_042a688ed8b92505"] = "总被称作老二的教徒将挑战所有挡他前面的人。装备上快抢，这名挑战者不容小视！", 

-- ——————————————————————枪械皮肤(好多条。)——————————————————————
["bm_menu_quality_fair"] = "久经沙场",
["bm_menu_quality_fine"] = "略有磨损",
["bm_menu_quality_good"] = "破损不堪",
["bm_menu_quality_mint"] = "崭新出厂",
["bm_menu_quality_poor"] = "战痕累累",


["bm_menu_safe_event_01"] = "犯罪盛宴2 保险箱",
["bm_menu_drill_event_01"] = "犯罪盛宴2 钻机",
["bm_menu_drill_event_01_desc"] = "这个钻机能打开一个犯罪盛宴2保险箱",
["bm_wskn_b92fs_forest"] = "\"镀铜\" Copper",
["bm_wskn_famas_forest"] = "\"造币系统\" Coin Ops",
["bm_wskn_huntsman_forest"] = "\"黑色闪电\" Black Thunder",
["bm_wskn_m134_forest"] = "\"3000场劫案/分钟\" 3000 heists/min",
["bm_wskn_m95_forest"] = "\"紫雾\" Purple Haze",
["bm_wskn_r93_forest"] = "\"像素火焰\" Fire Pixel",
["bm_wskn_judge_camohex"] = "\"贪婪\" Greed",
["bm_wskn_mg42_camohex"] = "\"埋葬\" Tomb",
["bm_wskn_new_m14_camohex"] = "\"数码烈焰\" Digital Burn",
["bm_wskn_serbu_camohex"] = "\"贪婪\" Greed",
["bm_wskn_ak74_luxury"] = "\"伤心的大胡子\" Sad Almir",
["bm_wskn_p90_luxury"] = "\"子弹突击\" Bullet Breakout",
["bm_wskn_ppk_luxury"] = "\"Cloaker风格\" Cloakerize",
["bm_wskn_new_m4_payday"] = "\"保险箱破坏狂\" Safe Crasher",
["bm_wskn_plainsrider_linked"] = "\"林克\" The Link",
["bm_wskn_deagle_bling"] = "\"生财之道\" Midas Touch",
["bm_wskn_deagle_bling_desc"] = "在全世界最好玩的枪械改造模拟游戏中，精心打造的沙鹰模型。传说级皮肤不可改造。",

["bm_msk_sputnik"] = "人造卫星",
["bm_menu_safe_weapon_01"] = "人造卫星 保险箱",
["bm_menu_drill_weapon_01"] = "人造卫星 钻机",
["bm_menu_drill_weapon_01_desc"] = "这个钻机能打开一个人造卫星保险箱",
["bm_wskn_judge_woodland"] = "\"像素\" Pixel",
["bm_wskn_p90_woodland"] = "\"红星闪闪\" Red Stars",
["bm_wskn_plainsrider_woodland"] = "\"北极平原\" Arctic Plains",
["bm_wskn_ppk_woodland"] = "\"小型豹纹\" Little Leopard",
["bm_wskn_rpg7_woodland"] = "\"今日头条\" Headline",
["bm_wskn_serbu_woodland"] = "\"宇航员\" Cosmonaut",
["bm_wskn_flamethrower_mk2_goldstripes"] = "\"圣者巴索\" St. Basil",
["bm_wskn_g36_goldstripes"] = "\"冰冻豹纹\" Ice Leopard",
["bm_wskn_new_m4_goldstripes"] = "\"条纹风格\" Stripe On",
["bm_wskn_new_raging_bull_goldstripes"] = "\"黑色公牛\" Black Bull",
["bm_wskn_b92fs_luxury"] = "\"狂怒之熊\" Angry Bear",
["bm_wskn_m95_luxury"] = "\"俄罗斯套娃\" Matrjoschka",
["bm_wskn_new_m14_luxury"] = "\"太空帽计划\" Helmet Space Program",
["bm_wskn_famas_hypno"] = "\"撕裂夜鸮\" Breaching Owl",
["bm_wskn_huntsman_hypno"] = "\"子弹熊之枪\" Bullte Bear Gun",
["bm_wskn_ak74_rodina"] = "\"弗拉德的母国\" Vlad's Rodina",
["bm_wskn_ak74_rodina_desc"] = "特别改制的AK——嗜血如命——专为战争和犯罪设计。传说级皮肤不可改造。",

["addation_69d4a64d7f533be8"] = "第一世界", 
["bm_menu_safe_event_red"] = "第一世界 保险箱",
["bm_menu_drill_event_red"] = "第一世界 钻机",
["bm_menu_drill_event_red_desc"] = "这个钻机能打开一个第一世界保险箱",
["bm_wskn_huntsman_golddigger"] = "\"狼性点缀\" Wolf Ornament",
["bm_wskn_p90_golddigger"] = "\"探矿之人\" Prospector",
["bm_wskn_ppk_golddigger"] = "\"典雅瓷砖\" Classic Tiles",
["bm_wskn_r93_golddigger"] = "\"金色破片\" Golden Flakes",
["bm_wskn_m134_golddigger"] = "\"不差钱\" Big Spender",
["bm_wskn_m95_golddigger"] = "\"Beta-2型\" Beta-2",
["bm_wskn_new_m14_golddigger"] = "\"珍D棒\" Ausome",
["bm_wskn_ak74_golddigger"] = "\"黄金矿脉\" Gold Vein",
["bm_wskn_serbu_golddigger"] = "\"鸢尾花\" Fleur de Lis",
["bm_wskn_famas_golddigger"] = "\"世界树\" Yggdrasil",
-- 金皮为犯罪盛宴2的生财之道

["bm_menu_safe_event_dinner"] = "屠宰场 保险箱",
["bm_menu_drill_event_dinner"] = "屠宰场 钻机",
["bm_menu_drill_event_dinner_desc"] = "这个钻机能打开一个屠宰场保险箱",
["bm_wskn_deagle_bloodbath"] = "\"突击进行中\" Assault Wave",
["bm_wskn_judge_bloodbath"] = "\"狂乱\" Frenzy",
["bm_wskn_new_raging_bull_bloodbath"] = "\"受害人冲刷者\" Victim Shower",
["bm_wskn_plainsrider_bloodbath"] = "\"浴血\" Blood Drenched",
["bm_wskn_b92fs_bloodbath"] = "\"血龙\" Blood Dragon",
["bm_wskn_flamethrower_mk2_bloodbath"] = "\"猛虎危机\" Tiger Hazard",
["bm_wskn_new_m4_bloodbath"] = "\"危机当前\" Danger Ahead",
["bm_wskn_mg42_bloodbath"] = "\"切肉机\" Meat Slicer",
["bm_wskn_rpg7_bloodbath"] = "\"公平警告\" Fair Warning",
["bm_wskn_g36_bloodbath"] = "\"安全区\" Perimeter Secure",
-- 金皮为人造卫星的弗拉德的母国

["bm_menu_safe_overkill_01"] = "大狂杀 保险箱",
["bm_menu_drill_overkill_01"] = "大狂杀 钻机",
["bm_menu_drill_overkill_01_desc"] = "这个钻机能打开一个大狂杀保险箱",
["bm_wskn_b92fs_bloodsplat"] = "\"有问必答8号球\" 8 Ball",
["bm_wskn_m134_bloodsplat"] = "\"喷洒玫瑰\" Spraying Roses",
["bm_wskn_flamethrower_mk2_bloodsplat"] = "\"焚化之死\" Incinerated Death",
["bm_wskn_judge_wooh"] = "\"将军\" Checkmate",
["bm_wskn_p90_skullimov"] = "\"技艺过人\" Overskill",
["bm_wskn_deagle_skullimov"] = "\"嘣！\" Boom!",
["bm_wskn_g36_bloodsplat"] = "\"火炬\" The Torch",
["bm_wskn_rpg7_bloodsplat"] = "\"地下电影\" Dinemageddon",
["bm_wskn_huntsman_bloodsplat"] = "\"一组锋线\" First Line",
["bm_wskn_r93_bloodsplat"] = "\"天降横祸\" Death From Above",
["bm_wskn_new_m4_skullimov"] = "\"渐变斑马纹\" Fade Zebra",
["bm_wskn_m95_bombmatta"] = "\"狂热列车\" Hype Train",
["bm_wskn_mg42_bloodsplat"] = "\"骷髅斑点\" Skull Spotted",
["bm_wskn_plainsrider_skullimov"] = "\"催眠头皮\" Hypno Scalp",
["bm_wskn_ak74_bloodsplat"] = "\"小舅子\" Little Brother",
["bm_wskn_new_m14_bloodsplat"] = "\"心肌梗塞\" Heart Attack",
["bm_wskn_serbu_stunner"] = "\"地毯式轰炸\" Carpet Bombing",
["bm_wskn_b92fs_wooh"] = "\"棕河\" Brown River",
["bm_wskn_ppk_bloodsplat"] = "\"深红之吻\" Crimson Kiss",
["bm_wskn_r93_wooh"] = "\"手雷突击波\" Grenade Repellant",
["bm_wskn_famas_bloodsplat"] = "\"悼念\" Commemore",
["bm_wskn_new_raging_bull_bloodsplat"] = "\"更加瓦甘莎\" Extra Vaganza",
["bm_wskn_flamethrower_mk2_fire"] = "\"龙之领主\" Dragon Lord",
["bm_wskn_rpg7_boom"] = "\"绿色笑容\" Green Grin",
["bm_wskn_m134_bulletstorm"] = "\"半缺不残\" The Gimp",
["bm_wskn_flamethrower_mk2_fire_desc"] = "龙之领主之名因1976年的唐氏起义而闻名，鸦片巨头唐将军将他的竞争对手们邀至他台北的货舱中，并一把火把他们烧了。(当然，部分台北市民也未能幸免)",
["bm_wskn_rpg7_boom_desc"] = "曼努埃尔·洛佩斯是一个成功的毒枭，他的基地位于巴兰基利亚港口。他深爱着海洋，更爱在海洋中杀戮。洛佩兹喜欢从直升机上猎杀鲨鱼 — 带着他标志性的绿色的笑容. ",
["bm_wskn_m134_bulletstorm_desc"] = "\"半缺不残\"所用的金属来自于从第一次海湾战争，福岛战争，市场花园行动,索姆河战役，布尔战争中退役的武器。",

["bm_menu_safe_dallas_01"] = "达拉斯 保险箱",
["bm_menu_drill_dallas_01"] = "达拉斯 钻机",
["bm_menu_drill_dallas_01_desc"] = "这个钻机能打开一个达拉斯保险箱",
["bm_wskn_famas_dallas"] = "\"拉斐特猎人\" Lafayette Hunter",
["bm_wskn_flamethrower_mk2_dallas"] = "\"铬色燃烧\" Chromed Combustion",
["bm_wskn_huntsman_dallas"] = "\"双头爬虫\" Reptilian Two Heads",
["bm_wskn_mg42_dallas"] = "\"铬色支配者\" Chromed Dominator",
["bm_wskn_new_raging_bull_dallas"] = "\"快枪猎人\" Quickdrawn Hunter",
["bm_wskn_r93_dallas"] = "\"爬虫针刺\" Reptilian Sting",
["bm_wskn_ak74_dallas"] = "\"毛子爬虫\" Reptilian Russkie",
["bm_wskn_deagle_dallas"] = "\"爬虫尖牙\" Reptilian Fang",
["bm_wskn_new_m14_dallas"] = "\"长角猎人\" Longhorn Hunter",
["bm_wskn_ppk_dallas"] = "\"铬色麻雀\" Chromed Sparrow",
["bm_wskn_b92fs_dallas"] = "\"纽扣猎人\" Buckle Hunter",
["bm_wskn_judge_dallas"] = "\"掌上爱国者\" Pocket Patriot",
["bm_wskn_serbu_dallas"] = "\"权利爱国者\" Power Patriot",
["bm_wskn_g36_dallas"] = "\"铬色窒息\" Chromed Strangler",
["bm_wskn_m95_dallas"] = "\"穿刺爱国者\" Piercing Patriot",
["bm_wskn_p90_dallas_sallad"] = "\"阿拉莫·达拉斯\" Alamo Dallas",
["bm_wskn_p90_dallas_sallad_desc"] = "杰斯特·瓦兰特从不会担心留下蛛丝马迹，毕竟她将肉锤的头部衔在枪口，以便将目标砸成肉泥。如果不是她早早地了结了自己，她的身份将永远成谜，毕竟光是得确认受害者的身份就是个大问题。",

["bm_menu_safe_surf_01"] = "鲍迪 保险箱",
["bm_menu_drill_surf"] = "鲍迪 钻机",
["bm_menu_drill_surf_desc"] = "这个钻机能打开一个鲍迪保险箱",
["bm_wskn_akm_waves"] = "\"碧海蓝天\" Le Grand Bleu",
["bm_wskn_asval_waves"] = "\"波浪蛇\" Wave Snake",
["bm_wskn_baka_waves"] = "\"力量\" Chikara",
["bm_wskn_m16_waves"] = "\"越共不会冲浪\" Charlie Don't Surf",
["bm_wskn_s552_waves"] = "\"无拘无束\" Hang Loose",
["bm_wskn_usp_waves"] = "\"口无遮拦\" Lip Jibber",
["bm_wskn_aug_waves"] = "\"乌龟翻\" Turtle Roll",
["bm_wskn_colt_1911_waves"] = "\"激进派\" Radical",
["bm_wskn_mac10_waves"] = "\"沙加\" Shaka",
["bm_wskn_scar_waves"] = "\"神法\" Kapu",
["bm_wskn_ak5_waves"] = "\"肉华夫\" Meat Waffle",
["bm_wskn_mosin_waves"] = "\"呜呜啊呜\" Coo Coo Ca Choo",
["bm_wskn_polymer_waves"] = "\"流线型\" Aerodynamic",
["bm_wskn_striker_waves"] = "\"激流\" Riptide",
["bm_wskn_x_g22c_waves"] = "\"部落世仇\" Tribal Feud",
["bm_wskn_r870_waves"] = "\"大巫师\" Big Kahuna",
["bm_wskn_r870_waves_desc"] = "传奇劫匪阿法诺·\"洛奇\"·琼斯，他以遵循萨摩亚祖先的传统，追寻刺激为荣，并在他的猎枪上刻下了象征着他拥有的最大荣耀——完成尾崎八项——的刺身。",

["bm_menu_safe_event_flake"] = "圣诞 保险箱",
["bm_menu_drill_event_flake"] = "圣诞 钻机",
["bm_menu_drill_event_flake_desc"] = "这个钻机能打开一个圣诞保险箱",
["bm_wskn_new_mp5_ginger"] = "\"嚯-嚯-嚯\" Ho-Ho-Ho",
["bm_wskn_p226_ginger"] = "\"软雪\" Soft Flake",
["bm_wskn_m249_ginger"] = "\"大礼物\" Big Present",
["bm_wskn_saiga_ginger"] = "\"碧蓝冻土\" Blue Tundra",
["bm_wskn_m1928_ginger"] = "\"圣诞红酒\" Xmas Noir",
["bm_wskn_ksg_ginger"] = "\"常青之树\" Evergreen",
["bm_wskn_x_b92fs_ginger"] = "\"子弹响叮当\" Jingling Bullets",
["bm_wskn_g22c_ginger"] = "\"惊喜来敲门\" Gluckseliger Uberfall",
["bm_wskn_wa2000_ginger"] = "\"圣诞老人好帮手\" Santa's Helper",
["bm_wskn_akmsu_ginger"] = "\"寒林仙境\" Wintry Wonder",
["bm_wskn_x_1911_ginger"] = "\"圣诞老人的奴隶们\" Santa's Slayers",
["bm_wskn_x_1911_ginger_desc"] = "他知道你睡在哪儿，他知道你何时入睡。$NL;他从烟囱悄悄潜入，就像那该死的怪物。$NL;准备接受他的愤怒，你绝对不想得到的礼物。$NL;太迟啦，他已出动，你的尖叫无人听到。",

["addation_d8493ae356e973ee"] = "山羊收藏", 
["bm_menu_safe_event_bah"] = "山羊 保险箱",
["bm_menu_drill_event_bah"] = "山羊 钻机",
["bm_menu_drill_event_bah_desc"] = "这个钻机能打开一个山羊保险箱",
["bm_wskn_ak5_baaah"] = "\"比利\" Billy",
["bm_wskn_r870_baaah"] = "\"羊蹄\" Cloven Hoofs",
["bm_wskn_wa2000_baaah"] = "\"长角\" Long Horn",
["bm_wskn_x_g22c_baaah"] = "\"潘神\" Pan",
["bm_wskn_m16_baaah"] = "\"萨蒂尔\" Satyr",
["bm_wskn_polymer_baaah"] = "\"太空山羊\" Spacegoat",
["bm_wskn_usp_baaah"] = "\"娇小绵羊\" Ram Petite",
["bm_wskn_m249_baaah"] = "\"机械山羊\" Machine Goat",
["bm_wskn_x_1911_baaah"] = "\"践踏\" Stampede",
["bm_wskn_ksg_baaah"] = "\"愤怒的羊\" Raging Goat",
["bm_wskn_model70_baaah"] = "\"五香熏羊肉\" Don Pastrami",
["bm_wskn_model70_baaah_desc"] = "刺客有时会为他们的目标留好名片，如果你的智商足够的话，它们只会被那些你想让其知晓你的人发现。\"牧场主\"就明显做不到这一步，他的子弹暴露了他自己。它们全被他的宠物羊贝奇舔了一遍。也难怪他在杀手社区中默默无闻。",

["addation_37c76e16b3a83464"] = "沃尔夫收藏", 
["bm_menu_safe_pack_01"] = "沃尔夫 保险箱",
["bm_menu_drill_pack_01"] = "沃尔夫 钻机",
["bm_menu_drill_pack_01_desc"] = "这个钻机能打开一个沃尔夫保险箱",
["bm_wskn_saiga_wolf"] = "\"霰弹\" Hagelbrak",
["bm_wskn_g22c_wolf"] = "\"小垃圾\" Liten Skit",
["bm_wskn_scar_wolf"] = "\"伤疤\" Scarred",
["bm_wskn_colt_1911_wolf"] = "\"芬莉斯\" Fenris",
["bm_wskn_mosin_wolf"] = "\"独狼\" Lone Wolf",
["bm_wskn_striker_wolf"] = "\"幼子军女领袖\" Denmother",
["bm_wskn_baka_wolf"] = "\"哈提\" Hati",
["bm_wskn_akm_wolf"] = "\"大坏蛋\" Big Bad",
["bm_wskn_p226_wolf"] = "\"猪警官\" Polisgris",
["bm_wskn_mac10_wolf"] = "\"斯库尔\" Skoll",
["bm_wskn_x_deagle_wolf"] = "\"基利与库力奇\" Geri and Freki",
["bm_wskn_asval_wolf"] = "\"隐匿之狼\" Smygvarg",
["bm_wskn_aug_wolf"] = "\"长爪\" Longclaw",
["bm_wskn_m16_wolf"] = "\"地狱\" Helvete",
["bm_wskn_s552_wolf"] = "\"长啸\" Howl",
["bm_wskn_par_wolf"] = "\"饿狼\" Hungry Wolf",
["bm_wskn_par_wolf_desc"] = "通过多年精修机械，沃尔夫终于把他理想的设计变为了现实，创造出了\"饿狼\"。这把改装后的KSP轻机枪体现出了它的创造者的暴力精神，它将会成为沃尔夫他自己，和散布他所享受的混乱的延续。顺带一提，这把枪的弹药盒上刻有购物清单。",

["addation_becdb4658c8ff034"] = "吉米 保险箱", 
["addation_ee137a056fa0764a"] = "吉米 钻机", 
["addation_061a72141aea5a64"] = "这个钻机能打开一个吉米保险箱", 
["addation_102e00a5d839725b"] = "需要双持技能或天赋", 
["addation_28c1291158db828a"] = "需要双持技能或天赋", 
["addation_5ec1af22bc18fd88"] = "\"单频自组网\" AdHoc Mono", 
["addation_2c322e960df59169"] = "\"公理号\" The Axiom", 
["addation_a846f138ca1f2b33"] = "\"铜斑蛇\" CopperHead", 
["addation_d3acb23859c06cae"] = "\"暗网-999\" Tor-999", 
["addation_55c706748877b707"] = "\"印相纸\" Velox", 
["addation_c38396e8faf78214"] = "\"双芯片\" Twin Chip", 
["addation_fab92a243582c078"] = "\"维克斯格斗术\" Vix CQC", 
["addation_42d750bcd4292029"] = "\"全向弓\" OmniBow", 
["addation_f444a441375b75e7"] = "\"拉克斯格斗术\" Lux CQC", 
["addation_6d66eb28c73972fd"] = "\"农杆素\" Aggrocinn", 
["addation_810c632fed20e94d"] = "\"我将时刻注意你\" IMUR Spotter", 
["addation_079fc36886136e24"] = "\"流逝\" Efflux", 
["addation_200d8f1ec919380c"] = "\"抗体悖论\" Novus Paradox", 
["addation_1ec6a3ec38a59779"] = "\"达克斯格斗术\" Dax CQC", 
["addation_91bfa0bbb7fa7bd9"] = "\"原子原子\" AtomAtom", 
["addation_7c37c4f836cf2d20"] = "\"尚不稳定\" Astatoz", 
["addation_63822602f3975936"] = "这把AMR-16还没到达它的极限，它还需我们对它进行进一步的调整。在整个地球上仅有几克砹物质，但吉米仍设法搞到了些。这些放射性物质淬炼了AMR-16把它改造成了\"尚不稳定\"。唯一的问题是砹有点不稳定———而且又致命。改造时小心点。", 

["addation_d12a835208c0e7e9"] = "辛妮 保险箱", 
["addation_53bda8de000eea15"] = "辛妮 钻机", 
["addation_ca440163d23ea176"] = "这个钻机能打开一个辛妮保险箱", 
["addation_643ffffd3e744bae"] = "\"死亡铅格\" Lead Dead Plaid", 
["addation_6a6e09a048bc5232"] = "\"狂舞时刻\" Mosh Time", 
["addation_11e2e7488db6d051"] = "\"作秀盛宴\" Poser Bash", 
["addation_77311470ad07d3da"] = "\"蹦迪时刻\" Pogo Time", 
["addation_6bf7941eef5f0357"] = "\"狗咬狗\" Dog Eat Dog", 
["addation_bedd3ee9fcc05041"] = "\"奥斯特伯格\" Osterberg", 
["addation_11a04403127baa75"] = "\"脑死亡\" Braindead", 
["addation_31c25f89850dc986"] = "\"快乐悲观者\" Happy Cynic", 
["addation_53a733233f28676a"] = "\"小凶兆\" Minor Threat", 
["addation_9de03302d2d0d00f"] = "\"反-条命\" Anti-Life",
["addation_c65e3c6ce794e29f"] = "\"竖起中指\" Middle Finger Handout", 
["addation_8372b0f34ac02d3f"] = "\"无礼帝王\" Offensive Monarch", 
["addation_30180a02a1235737"] = "\"呕吐\" Spewer", 
["addation_4a260f211165e897"] = "\"铁丝网\" BarbWire", 
["addation_d2402c0abd3a7748"] = "\"愤怒的寂静\" Angry Silence",
["addation_5f08ff1441a01d5d"] = "\"无政府朋克\" Anarcho", 
["addation_7306a809d868cbcd"] = "泰昔是名臭名远扬，只为金钱的枪械锻造师，但他也足够老道，对所有枪械了如指掌。\"无政府朋克\"就是泰昔的经典之作，因存世数量稀少而被争相抢购。没人知道泰昔的真名或是出身，不过也没人打算去了解———毕竟如果你知道了他的一二，他会用跆拳道把你打哭出来。", 

["addation_15d46e2cee7c010e"] = "飞车党 保险箱", 
["addation_a78b147c1e567661"] = "飞车党", 
["addation_c34fec906330753d"] = "\"砍刀\" Chopper", 
["addation_1b7790920b62c2fc"] = "\"暴力摩托\" Road Rash", 
["addation_01f37c1055595ddd"] = "\"马力\" Horsepower", 
["addation_94862686e079d409"] = "\"排气管消音器\" Muffler", 
["addation_77a8eaf5443c5b64"] = "\"活塞头\" Pistonheads", 
["addation_f3b7fc34bad31c0f"] = "\"鹿角\" Buckhorns", 
["addation_5d8f609b32a6f729"] = "\"火花塞\" Spark Plug", 
["addation_58a052c36ecbc088"] = "\"流浪之人\" Nomad", 
["addation_79fc00f43522c25e"] = "\"少数派\" One Percenter", 
["addation_96fcffb6e8b7994a"] = "\"平叉\" The Fork", 
["addation_7456bfac49490170"] = "\"柏油吞噬者\" Asphalt Eater", 
["addation_7e010c37b35706a7"] = "\"机车装饰\" Trimmad Moppe", 
["addation_b8ab35e838717989"] = "\"安全帽\" Brain Bucket", 
["addation_0e57cf1957ad54ec"] = "\"耙尺\" Rake", 
["addation_1cff8940aff02613"] = "\"转矩\" Torque", 
["addation_6ea1173a383baa65"] = "\"顶点\" Apex", 
["addation_24994e113dc49b23"] = "这把\"顶点\"是拉斯特的好伙计机械师送给他的礼物。对拉斯特来说，射光霰弹枪子弹后，直接抡起袖子把对方打到屎都流出来可谓是家常便饭，所以他的挚爱——\"破坏者12G\"霰弹枪——被特别改造了一翻。\"顶点\"便因此而生，这样一来，他就不用再刻意去留意枪内弹量了。", 

["addation_0f92bb666dbdf649"] = "社区1号", 
["addation_ee90272f04a9295f"] = "社区1号 保险箱", 
["addation_b3c4aec08b155b02"] = "社区1号 保险箱", 
["addation_c599280912f2e4d7"] = "\"复古\" Throwback",
["addation_1fecd09d85d225f1"] = "\"烈焰沙鹰\" Flaming Deagle",
["addation_55b0c15231650e07"] = "\"好战分子\" Warpig",
["addation_947edbe38e059c48"] = "\"像素战争\" PIXELWAR",
["addation_cb2afa2a0176ae14"] = "\"华丽装饰\" Opulent",
["addation_355957187a524842"] = "\"开路者\" Splitter",
["addation_08559814b3f5c9b3"] = "\"M90迷彩\" M90 Camo",
["addation_9fc4711c147d5df8"] = "\"皇室\" Royal",
["addation_8f1ab34c5e367189"] = "\"丰收\" The Harvest",
["addation_308987989fd2d15a"] = "\"钻石碎片\" DIAMOND SPLINTER",
["addation_ca61c787982d95a8"] = "\"科技\" Technology",
["addation_7600a06cfd872ca5"] = "\"蓄力一击\" Jack Shot",
["addation_24a847d0cb8dccf1"] = "\"花茎之刺\" Floral Thrust",
["addation_41a156d7d9cde162"] = "\"空艇\" Airship",
["addation_c4caef3990e66e69"] = "\"射星\" Shooting Star",
["addation_c7450f593d74ca3d"] = "\"上将\" Admiral",
["addation_aefebb63555676c1"] = "原属于一名海军军官，但很不幸的是，他那不争气的子孙们将其卖了出去换钱。最终，这把奢华的霰弹枪终于在地下世界里找到了一席之地，而它的枪口也终于能沾染死亡。", 

["addation_7aca4867483ec1da"] = "钱恩斯", 
["addation_56e68d17e808c1b8"] = "钱恩斯 保险箱", 
["addation_6758af552ecdceff"] = "\"寒夜\" Night Chill",
["addation_210533acf66196d1"] = "\"响尾蛇\" Rattler",
["addation_44b561dd67ed1f43"] = "\"夜行者\" Nightstalker",
["addation_960032bf52fa8811"] = "\"廓尔喀\" Ghurka",
["addation_82e1ef349043b02f"] = "\"海外军团\" Legionnaire",
["addation_9f984c738447ea1b"] = "\"北风之神\" Boreas",
["addation_e37dd5c37cc93a1c"] = "\"埋伏\" Ambush",
["addation_5a733578cedca716"] = "\"寂静打击\" Silent Strike",
["addation_97b4cc510397db22"] = "\"沙漠突击队\" Dessert Commando",
["addation_cf6e547c68a20147"] = "\"灰色阿尔法\" Gray Alpha",
["addation_e160a46be77946b1"] = "\"Zulu\" Zulu",
["addation_09deb8f307948f1b"] = "\"皇家长官\" Royal Commander",
["addation_3c85e0ec86672307"] = "\"死亡之面\" Face of Death",
["addation_94330d11a94c07a0"] = "\"灰色猎手\" Gray Hunter",
["addation_53d64fe37487ec04"] = "\"严酷死神\" Grim Reaper",
["addation_0a5dbacc64aa2c8d"] = "\"战神\" Mars Ultor",
["addation_ba9b4151febff79e"] = "富含了战争与复仇的武器。这把步枪拿来射杀那些正在朝你射击，和伺机朝你射击的王八犊子们真是再合适不过了。",

["addation_3c77737dd6c12758"] = "霍斯顿", 
["addation_4ba8a33841d29c50"] = "霍斯顿 保险箱", 
["addation_db7077475b11295b"] = "\"刀片分割者\" Razor Splitter", 
["addation_b2616b4782b92b0c"] = "\"金刚鹦鹉\" Macaw",
["addation_89b446ca3eaeec55"] = "\"G型毒素\" G-Toxin", 
["addation_5c0396ef925c1a54"] = "\"魔术\" Magic", 
["addation_b6ab4639e93159dd"] = "\"重磅炸弹\" Blockbuster", 
["addation_1bfff16d36c04e67"] = "\"星之眷族\" Star Spawn", 
["addation_55edc9a791ce0d76"] = "\"派对破坏者\" Party Crasher", 
["addation_f2d9b72c5b769fdc"] = "\"恶魔\" Demon", 
["addation_598d9ee4d8207beb"] = "\"浴火凤凰\" Plush Phoenix", 
["addation_fcf54bfb1a73e909"] = "有些时候，枪不仅仅是武器。在此之中囚禁着灵魂。当它被人持有时，一股力量会在他的血液中流淌，并为他注入毁灭的欲望。在此之后，现世将化为地狱，而他则会被称之为恶魔。", 
["addation_7c0dbf58880089b7"] = "我们之中的少数人是幸存者。千辛万苦不会磨灭我们。它一直都在我们身边，以备不时之需。它们近乎被遗忘于烈焰之中，但它们却在最后关头浴火重生，并为我们带来应得的荣耀。", 

["addation_470d53600fed0229"] = "社区2号", 
["addation_7618eb064d4e3c56"] = "社区2号", 
["addation_470d53600fed0229"] = "社区2号 保险箱", 
["addation_b9c93ae4c85a8b01"] = "\"穿刺射击\" Puncture Shot", 
["addation_c9bf3e9baf4c319f"] = "\"虎鲨\" Tigershark", 
["addation_a11f0615d7f3eaf8"] = "\"战区\" Battle Zone", 
["addation_d3753fc8765c639f"] = "\"经典之作\" Vintage", 
["addation_447989cbe7d01a72"] = "\"古旧品\" Ancient", 
["addation_4c016e2255afcc0f"] = "\"皇家之蓝\" Royale Blue", 
["addation_bfe3c4693e14550c"] = "\"智者\" Wiseguy", 
["addation_608b11f6a1cd543b"] = "\"载入中\" Loading", 
["addation_5576faea33141217"] = "\"家室拆迁者\" Homewrecker",
["addation_e2b7f133ac03e882"] = "\"战斗医生\" Combat Medic", 
["addation_9fe80ca849d20f2c"] = "\"冷却\" Cooldown", 
["addation_dc8e47befed289a0"] = "\"城市迷彩|金属\" Urban Camo | Metallic", 
["addation_86cf6504b92721b1"] = "\"脊柱抽液\" Spinal Tap", 
["addation_5de2ee541a876c88"] = "\"大马士革\" Damascus", 
["addation_9bd3babb67cc0f51"] = "\"孤注一掷\" High Stakes", 
["addation_686b0a4deb7d96da"] = "\"愤怒公牛\" El Toro Furioso", 
["addation_b1eab7cba0580cf2"] = "曾是传奇墨西哥银行劫匪\"愤怒公牛\"的配枪，而其因只身操办全部抢劫过程的胆识而出名。", 

["addation_b88e4353dd70af4e"] = "疤面煞星", 
["addation_685701358b6f4453"] = "疤面煞星 保险箱", 
["addation_6d4e41ea3bd7ecc3"] = "\"大鳄碾压器\" Gator Masher", 
["addation_de022b6105ea0941"] = "\"沼泽地\" Everglade", 
["addation_2c21c0050718f9d0"] = "\"基韦斯特\" Key West", 
["addation_0e08032fe38f7e78"] = "\"米诺尔人\" Seminole", 
["addation_0e6ed4df3f84abbd"] = "\"尽享沙滩\" Beach Bum", 
["addation_e2c4d5c6ff8207d6"] = "\"恶行&骰子\" Vice & Dice", 
["addation_a5aa9707e57547ec"] = "\"傲慢\" Hubris", 
["addation_6b3751c9276582e9"] = "\"上流社会\" High Life", 
["addation_c326bae15bf4d250"] = "\"阳光惊喜\" Sunshine Surprise", 
["addation_a2551b305e4555f8"] = "\"迈阿密式调味\" Miami Spice", 
["addation_1c8646921f672a15"] = "\"曼尼的复仇\" Manny's Revenge", 
["addation_3f8891558b844adf"] = "\"大王\" The Boss", 
["addation_b5087f48a6dbcb4e"] = "\"飞翔的鹈鹕\" Flying Pelican", 
["addation_9a8d598360336a39"] = "\"小伙子\" Chico", 
["addation_f6d308e26b6b3b1b"] = "\"古巴人\" Cuban", 
["addation_562eff05cf3c023b"] = "\"庄中暴徒\" Mansion Mauler", 
["addation_b34c2316c425cd8e"] = "\"小伙伴 7.62\"步枪的特殊原型版。这把无价且独特的作品于2016年底从阿灵顿枪械博物馆中消失。", 

["addation_dc91c56b245917ae"] = "约翰威克", 
["addation_dc91c56b245917ae"] = "约翰威克 保险箱", 
["addation_a8c94553572c0df2"] = "\"刀骑兵\" Hakkapeliitta", 
["addation_e2bdf21b7b54dc6f"] = "\"枪骑兵\" Man-at-arms", 
["addation_46134e84b18b58fe"] = "\"重装兵\" Hoplite", 
["addation_4c612777a12076a8"] = "\"步兵\" Lansquenet", 
["addation_3b93d6009247b353"] = "\"龙骑兵\" Dragoon", 
["addation_ac2c01f90f098800"] = "\"近卫军\" Janissary", 
["addation_6883d2818bdeb3be"] = "\"全甲骑兵\" Cataphract", 
["addation_929c5f17a8b99516"] = "\"骑士\" Knight", 
["addation_96d9fc8a480f3ff9"] = "\"十字军斗士\" Crusader", 
["addation_fa690375eacdd20a"] = "\"哥萨克骑兵\" Cossack", 
["addation_b2ab41f5d8d4318e"] = "\"蒙古骑兵\" Mongol", 
["addation_b38f224638604a9a"] = "\"日本武士\" Samurai", 
["addation_020bd6a06a7b83e7"] = "\"马赛战士\" Masai", 
["addation_8b93c664e327e439"] = "\"普鲁士军队\" Prussian", 
["addation_588a8efb0df53cda"] = "\"苏人\" Sioux", 
["addation_e1ff8573fcd86669"] = "\"刺客\" Assassin", 
["addation_5380cd9141780c83"] = "由传奇刺客持有的一对传奇冲锋枪。", 

["addation_601838e3fa18733c"] = "社区3号 保险箱", 
["addation_929233b37c625572"] = "社区3号", 
["addation_186aca1dc97db814"] = "\"新月形\" Crescent", 
["addation_6af17f75aa535532"] = "\"万无一失\" Failsafe", 
["addation_2fc005a11deb607b"] = "\"贪婪巨炮\" Greed", 
["addation_1d0f57f58fd32631"] = "\"炸药\" Dynamite", 
["addation_e0dea7082308a32a"] = "\"现代化\" Modernized", 
["addation_1791ef6e9fe4714b"] = "\"最后一人\" Last Man Standing", 
["addation_7b09c2f6c4c47f3e"] = "\"迪斯科\" Disco", 
["addation_f8aded05cc95cb8d"] = "\"雕琢\" Engraving", 
["addation_529fb13223d50935"] = "\"暗影袭击\" Cloaked", 
["addation_0cf51633798fe07b"] = "\"电力所\" Powerhouse", 
["addation_68f62de32194f031"] = "\"上校\" The Colonel", 
["addation_2013ace949bec0a1"] = "\"硝化\" Nitro", 
["addation_827cf287b3e65a22"] = "\"霓虹狂凶\" Frenzy", 
["addation_4f348cdc9112c22b"] = "\"无法无天\" Outlow", 
["addation_0f844e65c51e462f"] = "\"狼群战术\" Wolfpack", 
["addation_79c58cfde6e5ac16"] = "\"黄金都市\" City of Gold", 
["addation_ce7b9f951d482211"] = "这把枪曾被一位名叫奥多德欧罗的劫匪持有，他对金条有着近乎疯狂的执念。他曾因在警察局门外顺手牵羊一位老妇的口袋而入狱，出狱后他将此枪典当出手，发誓此生不再沾染金子。", 

["addation_735abb9d8ec46bc4"] = "桑格雷斯", 
["addation_735abb9d8ec46bc4"] = "桑格雷斯 保险箱", 
["addation_03ff7bfe478739f5"] = "\"特诺奇提特兰\" Tenochtitlan", 
["addation_70484ee9656f165a"] = "\"卓柏卡布拉\" Chupacabra", 
["addation_2e3eef1fbb8adfa2"] = "\"托尔特克人\" Toltec", 
["addation_2e23aae8728fc560"] = "\"枪手\" Pistolero", 
["addation_664684ad2398ae82"] = "\"蒂华纳\" Tijuana", 
["addation_fb1131ba68d8b237"] = "\"屍鹰\" Caracaras", 
["addation_dfccbb27a6ac27e4"] = "\"蒙特祖马\" Moctezuma", 
["addation_22c749421c2699a9"] = "\"玛雅\" Maya", 
["addation_4f09d38e825b8daf"] = "\"奇瓦瓦州\" Chihuahua", 
["addation_bd187819d41ae173"] = "\"奥尔梅克\" Olmec", 
["addation_775138b30c88f600"] = "\"阿兹特克人\" Aztec", 
["addation_e815c6e5b5ca92b6"] = "\"华雷斯\" Juarez", 
["addation_a69e3adc7177ad68"] = "\"蝎子\" Scorpion", 
["addation_6a061330ac69a9a3"] = "\"流浪者\" Los Mariachis", 
["addation_18dd49177af2a527"] = "\"潘丘·维拉\" Pancho Villa", 
["addation_8fafd41efb7e38d9"] = "\"蒙特雷\" Monterrey", 
["addation_6d04570f9aa9649a"] = "这些被精工改饰的枪械们一边诉说着墨西哥犯罪界的曾经，一边继续为它杀出着未来。", 

["addation_6c7740b2a335842a"] = "社区4号", 
["addation_e6fa4eb35783b345"] = "社区4号 保险箱", 
["addation_b3c7633eeb3963a2"] = "\"简洁外形\" Nutshell", 
["addation_1e50a7692f1aa74b"] = "\"Zeal部队\" The Zeal", 
["addation_8ffdcaa7f37392e3"] = "\"生而为盗\" Born to Steal", 
["addation_084d08b011ae7e94"] = "\"大灾变\" Apocalypse", 
["addation_39b1d844ec71f70f"] = "\"起源\" Genesis", 
["addation_e5a284e15fb9ff29"] = "\"谢帕德任务9号\" M9 Shepard", 
["addation_3f03dae89f9e2dc9"] = "\"DEVA\" DEVA", 
["addation_3e84dc085569691a"] = "\"生化泄露\" Biohazard", 
["addation_05431de5285902d1"] = "\"掠食者\" Predator", 
["addation_ed70632bb710796d"] = "\"天佑美利坚\" MURICA", 
["addation_14b21d2497fc0f5b"] = "\"传教士\" The Preacher", 
["addation_361f401a12e52821"] = "\"恶毒之女\" The Jezebelle", 
["addation_27c252daa6f5a820"] = "\"战争之矛\" The Spear of War", 
["addation_0ced021bb77569f2"] = "\"血线\" Bloodline", 
["addation_af706ebe891fdca4"] = "\"灰烬之希望\" Hope of Ashes", 
["addation_96ec7185e6b081e0"] = "\"漏油\" Oil Spill", 
["addation_cdbd77b033131c64"] = "漏油是危险且致命的。当然，我不是指海上的浮油或是工作室地上的油渍，而是指那种能把敌人射成渣渣的漏油。", 

["addation_a179d8deabd9a2dd"] = "奥德斯通的传承 保险箱", 
["addation_4f97297f372dc565"] = "\"U.S.O.突击队\" U.S.O. Commando", 
["addation_f5a69f70dcfa39da"] = "\"小乔治\" Little Georg", 
["addation_1a8dcd7487a2ed04"] = "\"迷彩MP40\" Tarnschmeisser", 
["addation_5b425fbae8aaa5d9"] = "\"恶魔的钢琴\" The Devil's Piano", 
["addation_d27a86fd5c08c274"] = "\"山姆叔叔的派对\" Uncle Sam's Party", 
["addation_ea8c9fb3bb9e4a08"] = "\"土匪燃烧者\" Bandit Burner", 
["addation_f8bdc69acaa7b82a"] = "\"天降神兵\" The Drop Buddy", 
["addation_27c59414f6a52717"] = "\"自由斗士\" Freedom Fighter", 
["addation_3736350ea6f9cabd"] = "\"母国\" Motherload", 
["addation_26ce6ecb9e28d1fe"] = "\"皇家指令\" Royal Order", 
["addation_0157d6a0327fcd3f"] = "\"上层操控者\" Big Time Operator", 

["addation_195352db6c1c5188"] = "社区5号 保险箱", 
["addation_34ab3f9559b4eed3"] = "社区5号",
["addation_0d9c2dfa060ccd0e"] = "\"火热迈阿密\" Hot Miami", --808a3997ac6db1db
["addation_6314a52032cdebf7"] = "\"和平行者蓝\" Peacekeeper Blue", 
["addation_cc0bce0d441ec2ee"] = "\"化学物标志\" Hazchem", 
["addation_7e6a567bd8afc0b5"] = "\"特殊单位\" Special Force", 
["addation_d7ad9df4f16a225c"] = "\"失眠\" Insomnia", 
["addation_95064117622ced97"] = "\"探测之下\" Under the Radar", 
["addation_096741ea59801114"] = "\"整装待发\" Suit Up", 
["addation_d0f0cf79ee44e821"] = "\"斯佩克特\" Spector", 
["addation_d14e5da63d69f2d1"] = "\"细节\" Respect", 
["addation_599e9385ba9b5db6"] = "\"嗨\"爆\"全场\" BoomBox",
["addation_20bc6e76f6151e8e"] = "\"乔瑟琳\" Jocy", 
["addation_16470d54e9dddad2"] = "\"过载\" Overload", 
["addation_a2f26438707b1d0d"] = "\"同花大顺\" The Royal Flush", 
["addation_c42b52202ff5309c"] = "\"背叛者\" Oathbreaker", 
["addation_0c8450747f55311d"] = "\"情如烈火\" Flames of Passion", 
["addation_2b49da4f400f0b76"] = "\"猎头者\" Headhunter", 
["addation_050bea93b4541564"] = "这把精心打造的马克十型冲锋枪在柏林的一间仓库里被找到，这把枪的主人是在世界犯罪历史上臭名卓著的赏金猎人：\"猎头者\"他现在已有九年没有过犯罪活动，但在他二十年的活跃时间里，他满世界追杀并残忍地终结着他的目标们。\"猎头者\"的真实身份至今未知。", 

["addation_14f273ff7055661c"] = "社区6号", 
["addation_d82c9f6fdcb103df"] = "\"凌凌漆\" 00G", 
["addation_969b681f157c2146"] = "\"战区\" Battle Zone", 
["addation_d17715288b4f78f4"] = "\"正中靶心\" On Point", 
["addation_2f2b6c8dbb6b091e"] = "\"这把步枪\" This Rifle", 
["addation_0b09643ba05fe790"] = "\"推土机\" Bulldozer", 
["addation_694bd89f927e0dba"] = "\"宙斯双子\" Castor and Pollux", 
["addation_ae244b989c380463"] = "\"花言巧语\" Rhetoric", 
["addation_fdeb9976c6ba679b"] = "\"驶作俑者\" MOTORIST", 
["addation_253d3c4152e85ce3"] = "\"热浪\" Heat Wave", 
["addation_214681b312705e2a"] = "\"大钻石\" The Diamond", 
["addation_90c6b939634dbf53"] = "\"试做品\" Prototype", 
["addation_0a4af42f1e33db01"] = "\"大师\" The Master", 
["addation_13e08109374400d6"] = "\"风暴\" The Tempest", 
["addation_90823d73cb57762c"] = "\"EVA\" EVA", 
["addation_aa04e487217111d4"] = "\"竞争对手\" Opposition", 
["addation_1dbffdba4e2b2078"] = "\"领头羊\" Vanguard", 

["addation_4f1b12c71b87bb76"] = "杜克 保险箱", 
["addation_2f80df84a0b55487"] = "\"邦尼\" Bonnie", 
["addation_a60c0b0f7166665b"] = "\"克莱德\" Clyde", 
["addation_07f651e83a8a2d43"] = "\"沙漠种马\" Desert Stallion", 
["addation_7620cf990fa7bb78"] = "\"氧化剂\" Oxidator", 
["addation_82c2fce447bb71f5"] = "\"苍白圣母\" Pallido Madre", 
["addation_e5a0d7e4802e8ad7"] = "\"铜绿\" Copper Green", 
["addation_6ed2d234d20dbcc8"] = "\"正义明珠\" Justice Pearl", 
["addation_ba2de013eadd5baf"] = "\"古朴抛光\" Classic Finish", 
["addation_6719efc03f980d78"] = "\"腐蚀之花\" Corrosive Blossom", 
["addation_7ca50220e1b1176b"] = "\"纹理双子\" Twins of Grain", 
["addation_33d8d1e1c521b802"] = "\"金蛇\" Golden Serpent", 
["addation_65f03053f78f0592"] = "\"王者\" The King", 
["addation_109d65a88846eba2"] = "\"总统之油\" Presidential Oil", 
["addation_4e82aa23145c303e"] = "\"五星黄铜\" The Five Brass", 
["addation_c4542a7b5ab3ce10"] = "\"灰渍\" The Ash Stain", 
["addation_93eb333ae38cd870"] = "\"杜克的微光\" Duke's Glimmer", 

["addation_c307b654ad81f4a9"] = "社区7号", 
["addation_12e81a78c688ba45"] = "\"Cloaker的黄金\" Cloaker Gold", 
["addation_73181946e065341c"] = "\"大熊\" The Bear", 
["addation_f8bab28b4b0791d8"] = "\"拉萨路之手\" LAZARUS ARMS", 
["addation_7e653de99186602a"] = "\"飞翔\" Flight", 
["addation_3f87fe7580afb1ad"] = "\"火车头\" Loco",
["addation_6cfc336cb8f6caf8"] = "\"陷入僵局\" Deadlock", 
["addation_46d7c12cb46fec01"] = "\"名为英雄之人\" A Man Called Hero",  
["addation_dca3be54b4961e56"] = "\"探员Z\" Agent Z", 
["addation_4c17961357ed9a38"] = "\"棉花糖\" Cotton Candy", 
["addation_ae27f57f0d13f7f3"] = "\"\"BUFF\"玩具枪\" BUFF", 
["addation_e9e09322300e853f"] = "\"荧光灯\" Fluorescent", 
["addation_e92abd743dcbc4ac"] = "\"专家之选\" PRO-TOUCH", 
["addation_fa430c79b4e560a1"] = "\"赛博空间\" Cyberspace", 
["addation_c108d0cde2efb114"] = "\"日蚀\" Eclipse", 
["addation_f829f815ac06e92d"] = "\"亥伯龙神\" Hyperion", 
["addation_fba09b4242527988"] = "\"苍穹\" Firmament",  

["addation_da8fcad4c5b930c4"] = "\"不朽巨蟒\" Immortal Python", 
["addation_040f6dd0cdd4523e"] = "\"不朽巨蟒\" Immortal Python", 
["addation_d3eb2dff05f1b18f"] = "\"不朽巨蟒\" Immortal Python", 
["addation_9e0d19da21da2128"] = "\"不朽巨蟒\" Immortal Python", 
["addation_8c1ce7ca28acd902"] = "\"不朽巨蟒\" Immortal Python", 
["addation_ec371e761efe29c0"] = "\"不朽巨蟒\" Immortal Python", 
["addation_d0a992fe58919e5c"] = "\"不朽巨蟒\" Immortal Python", 
["addation_f540081c905335f3"] = "\"不朽巨蟒\" Immortal Python", 
["addation_a83096dba060469b"] = "\"不朽巨蟒\" Immortal Python", 
["addation_da250a9704d6ab3d"] = "\"不朽巨蟒\" Immortal Python", 
["addation_b9c553d13d2e6186"] = "\"不朽巨蟒\" Immortal Python", 
["addation_a63d19df671d44fa"] = "\"不朽巨蟒\" Immortal Python", 
["addation_04aec66a1723fcb5"] = "\"不朽巨蟒\" Immortal Python", 
["addation_816a318e959052cb"] = "\"不朽巨蟒\" Immortal Python", 
["addation_708c8008dd97a7fb"] = "\"不朽巨蟒\" Immortal Python", 
["addation_dc6def7159e25edc"] = "\"不朽巨蟒\" Immortal Python", 
["addation_0cc6e12f7e72c20d"] = "\"不朽巨蟒\" Immortal Python", 
["addation_214570a1e6a604c9"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_7b1d3ff6477da014"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_d012ff8ee3502b21"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_797d2cb98b88e501"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_49b59e7f0a321257"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_0d84aaee46994647"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_d0ea2c1d8615753b"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_be43902a4273b307"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_2c46dd68ec0472d9"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_75f9be48a6bbcbaa"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_b771f28e31d64508"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_191ddc3981fe9c91"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_c4f93048a108c115"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_b827d0fa60b50739"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_d5b62c0a5f7a686e"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_5192cfa8c4b8be50"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_db5b27ce720e1e45"] = "该武器皮肤为成就奖励，不可被交易或售出。", 
["addation_b59a4f97c1eccdc5"] = "再完成 $NUM; 个成就后解锁。", 
["addation_bfad01ae140f2d12"] = "该皮肤需要在解锁1000个成就后方可使用。", 
["addation_fec09d7c55a54f10"] = "\"不朽巨蟒\" Immortal Python", 
["addation_884d846c4f27fe08"] = "这个护甲是 ##1000成就里程碑## 的奖励。该皮肤不可被交易或出售。",

["addation_a7b5d55835ac3014"] = "社区8号 保险箱",
["addation_bbe7280f3a942842"] = "\"天佑美利坚\" MURICA",
["addation_c777ffe5c3ea0c28"] = "\"皇家之蓝\" Royale Blue",
["addation_83159f80c5df4af3"] = "\"消防员\" Firefighter",
["addation_f2581c35473d4b49"] = "\"暴乱\" Riot",
["addation_d968b1ad3f85859b"] = "\"名为英雄之人\" A Man Called Hero",
["addation_751c9a7ad52d897b"] = "\"雪地迷彩\" Snow Camo",
["addation_c232ee86fd62f21a"] = "\"毫不留情\" No Mercy",
["addation_beca57616a60f946"] = "\"电池\" Battery",
["addation_24b2f4832aea8ff4"] = "\"地下氖气\" Underground Neon",
["addation_6169cb332b49ede8"] = "\"粉碎之线\" Shattered Line",
["addation_d468436536a5bc27"] = "\"荧光灯\" Fluorescent",
["addation_d05b29346724d130"] = "\"着魔\" Possessed",
["addation_bee29e9597003a18"] = "\"大马士革\" Damascus",
["addation_a9cc608299a65846"] = "\"赌台主持\" Croupier",
["addation_1b70e3dafc647bbf"] = "\"橙色泼溅辛妮\" Orange Splashes Sydney",
["addation_83d74f6eb6be275e"] = "\"保护者\" Protector",
["addation_ca84cfd6a853c6e6"] = "这把巨鹰步枪被高度改装为适合特种精英保镖使用。它在无数首席会议中为各国领导人提供了绝对安全的保障。", 

["addation_4bbcdab2c8ec5d30"] = "社区9号收藏", 
["addation_921a96db42c5586f"] = "社区9号", 
["addation_85be40eca8f0df34"] = "社区9号保险箱", 
["addation_159fed4ff9d1fe36"] = "\"除血剂\" Bloodshed", 
["addation_5c11315b545f87d9"] = "\"淡出\" Fade Out", 
["addation_7186467ea450fbf4"] = "\"街头之热\" The Street Heat", 
["addation_93c6f69624de069d"] = "\"细胞模型\" Blueprint", 
["addation_725e3f9915ac80e1"] = "\"医疗包\" Medic Bag", 
["addation_91d1877fdcdf7460"] = "\"幸存者\" Survivor", 
["addation_57db59bf5b7a5e21"] = "\"刀片骷髅\" Razor Skull", 
["addation_5534be7ad564737f"] = "\"驶作俑者\" MOTORIST", 
["addation_b57b1b34d8804192"] = "\"野火\" Wildfire", 
["addation_8a5b9097794c3418"] = "\"崩坏圣人\" Corrupted Saints", 
["addation_a63eefd65990fc80"] = "\"熔岩骑士\" Magma Knight", 
["addation_e1f99a7c53282fd1"] = "\"鬣狗\" Hyena", 
["addation_b00f6f4821512033"] = "\"恐怖前夜\" Last Night", 
["addation_edd0c58613ddb57f"] = "\"鲍德温的军备\" Baldwin\'s Armament", 
["addation_515747dbcb042b3d"] = "\"情绪稳定\" Equilibrium", 
["addation_65807ad43164fae8"] = "\"幸运豪赌者\" The Lucky Gambler", 
["addation_a8775e6d33bf3e84"] = "这把OVE9000电锯拥有一段奇幻且血腥的历史，它曾属于一名传奇赌徒，他最终被虚荣心与复仇心冲昏了头脑，最终自取灭亡。",

["bm_wskn_ak74_luxury_desc"] = "包含改造配件",
["bm_wskn_p90_luxury_desc"] = "包含改造配件",
["bm_wskn_ppk_luxury_desc"] = "包含改造配件",
["bm_wskn_new_m4_payday_desc"] = "包含改造配件",
["bm_wskn_plainsrider_linked_desc"] = "包含改造配件",
["bm_wskn_b92fs_luxury_desc"] = "包含改造配件",
["bm_wskn_m95_luxury_desc"] = "包含改造配件",
["bm_wskn_new_m14_luxury_desc"] = "包含改造配件",
["bm_wskn_famas_hypno_desc"] = "包含改造配件",
["bm_wskn_huntsman_hypno_desc"] = "包含改造配件",
["bm_wskn_famas_golddigger_desc"] = "包含改造配件",
["bm_wskn_ak74_golddigger_desc"] = "包含改造配件",
["bm_wskn_serbu_golddigger_desc"] = "包含改造配件",
["bm_wskn_rpg7_bloodbath_desc"] = "包含改造配件",
["bm_wskn_g36_bloodbath_desc"] = "包含改造配件",
["bm_wskn_mg42_bloodbath_desc"] = "包含改造配件",
["bm_wskn_m95_bombmatta_desc"] = "包含改造配件",
["bm_wskn_serbu_stunner_desc"] = "包含改造配件",
["bm_wskn_plainsrider_skullimov_desc"] = "包含改造配件",
["bm_wskn_p90_skullimov_desc"] = "包含改造配件",
["bm_wskn_new_m4_skullimov_desc"] = "包含改造配件",
["bm_wskn_deagle_skullimov_desc"] = "包含改造配件",
["bm_wskn_r93_wooh_desc"] = "包含改造配件",
["bm_wskn_judge_wooh_desc"] = "包含改造配件",
["bm_wskn_b92fs_wooh_desc"] = "包含改造配件",
["bm_wskn_ppk_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_flamethrower_mk2_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_r93_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_new_m14_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_new_raging_bull_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_m134_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_huntsman_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_ak74_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_rpg7_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_g36_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_mg42_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_b92fs_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_famas_bloodsplat_desc"] = "包含改造配件",
["bm_wskn_b92fs_dallas_desc"] = "包含改造配件",
["bm_wskn_g36_dallas_desc"] = "包含改造配件",
["bm_wskn_judge_dallas_desc"] = "包含改造配件",
["bm_wskn_m95_dallas_desc"] = "包含改造配件",
["bm_wskn_serbu_dallas_desc"] = "包含改造配件",
["bm_wskn_x_g22c_waves_desc"] = "包含改造配件",
["bm_wskn_mosin_waves_desc"] = "包含改造配件",
["bm_wskn_striker_waves_desc"] = "包含改造配件",
["bm_wskn_ak5_waves_desc"] = "包含改造配件",
["bm_wskn_polymer_waves_desc"] = "包含改造配件",
["bm_wskn_akmsu_ginger_desc"] = "包含改造配件",
["bm_wskn_wa2000_ginger_desc"] = "包含改造配件",
["bm_wskn_g22c_ginger_desc"] = "包含改造配件",
["bm_wskn_m249_baaah_desc"] = "包含改造配件",
["bm_wskn_x_1911_baaah_desc"] = "包含改造配件",
["bm_wskn_s552_wolf_desc"] = "包含改造配件",
["bm_wskn_aug_wolf_desc"] = "包含改造配件",
["bm_wskn_m16_wolf_desc"] = "包含改造配件",
["bm_wskn_x_deagle_wolf_desc"] = "包含改造配件",
["bm_wskn_asval_wolf_desc"] = "包含改造配件",
["addation_e2742579a67ef07d"] = "包含改造配件", 
["addation_1d4e30fc3e4924fd"] = "包含改造配件", 
["addation_e8bdaf4fb3efdce4"] = "包含改造配件", 
["addation_c362af9fc5ed4984"] = "包含改造配件", 
["addation_cdfbc8d958ff801b"] = "包含改造配件", 
["addation_38caa4cdc2e0bb44"] = "包含改造配件", 
["addation_59f71a0eeed4987e"] = "包含改造配件", 
["addation_4337aba1b53d4847"] = "包含改造配件", 
["addation_a3fd1f1034a0c538"] = "包含改造配件", 
["addation_83c85459bf46e8ce"] = "包含改造配件", 
["addation_5ccc0cd67e4df0fd"] = "包含改造配件", 
["addation_ce8741f37906bc5f"] = "包含改造配件", 
["addation_5f53cbf4ed542c09"] = "包含改造配件", 
["addation_198b9467eb2f9891"] = "包含改造配件", 
["addation_efb4f01ea7f80221"] = "包含改造配件", 
["addation_b84b89895a7ab2d4"] = "包含改造配件", 
["addation_cffb4e1cb90a9776"] = "包含改造配件", 
["addation_d44e19b016feffa9"] = "包含改造配件", 
["addation_cba375a91ecf2338"] = "包含改造配件", 
["addation_6883b3fbe1f97d31"] = "包含改造配件", 
["addation_83be1d9fe4acfcbe"] = "包含改造配件", 
["addation_c05ae9da6bdd637a"] = "包含改造配件", 
["addation_0f9146238581762d"] = "包含改造配件", 
["addation_25e3283d87370ef7"] = "包含改造配件", 
["addation_c3ce5537a692bd04"] = "包含改造配件", 
["addation_0398f12f05dec0e0"] = "包含改造配件", 
["addation_3264ba7e33061859"] = "包含改造配件", 
["addation_e8200a74511cb001"] = "包含改造配件", 
["addation_f29c3d2126851d44"] = "包含改造配件", 
["addation_d0f45f742d17de67"] = "包含改造配件", 
["addation_9ac5af4982ee99b7"] = "包含改造配件", 
["addation_b6c03c2f5090e485"] = "包含改造配件", 
["addation_b132938e0962937b"] = "包含改造配件", 
["addation_19ca585783fb9fb1"] = "包含改造配件", 
["addation_0ef2c3e7efcbbf91"] = "包含改造配件", 
["addation_29a8bffe7a99787d"] = "包含改造配件", 
["addation_686b2e61da731151"] = "包含改造配件", 
["addation_eea9c54c60216b2c"] = "包含改造配件", 
["addation_0130b7e6a024dbe8"] = "包含改造配件", 
["addation_87c433f5e884e267"] = "包含改造配件", 
["addation_489fd7d1c1429d7c"] = "包含改造配件", 
["addation_eb5baf69d33ce5de"] = "包含改造配件", 
["addation_fc2639dc09ab99e4"] = "包含改造配件", 
["addation_46a8f1dd60dd1a12"] = "包含改造配件", 
["addation_7c6aee0731a1faec"] = "包含改造配件", 
["addation_57de45f17ca1099f"] = "包含改造配件", 
["addation_7a3363291b543990"] = "包含改造配件", 
["addation_df7ddb6cbad79ca5"] = "包含改造配件", 

-- ——————————————————————护甲皮肤(共45条)——————————————————————
-- ———— 护甲保险箱
["addation_e851f0bbb3e4bd17"] = "护甲保险箱", 
["addation_f24b5d19011c24f9"] = "护甲保险箱", 
["addation_ff7c44a5a398c4d3"] = "\"都市迷彩\" City Camo", 
["addation_eb247dd74f4c7deb"] = "\"沙漠迷彩\" Desert Camo", 
["addation_86d5c7bf0680fa44"] = "\"林地迷彩\" Woodland Camo", 
["addation_6df7dcb0a6f292d2"] = "\"头骨\" Skull", 
["addation_9c1a693e69357e77"] = "\"SWAT风格\" SWAT", 
["addation_290d566161982259"] = "\"朋克骨架\" Bone", 

-- ———— 二战护甲
["addation_4ada785c84f5178a"] = "二战护甲保险箱", 
["addation_278b182feac5b49d"] = "\"德国迷彩\" German Camo", 
["addation_53d908f3bc2b04c3"] = "\"俄罗斯迷彩\" Russian Camo", 
["addation_1c899face3ce8580"] = "\"英国伞兵\" British Paratrooper", 
["addation_374638483c66c8ef"] = "\"谢尔曼坦克\" Sherman Tank", 
["addation_6756db5fc6d7183d"] = "\"投弹者夹克\" Bomber Jacket", 
["addation_b199fbf4d23fe303"] = "\"海军上将\" Navy Admiral", 

-- ———— 社区1号护甲
["addation_c57fbbdf4d98e7f2"] = "社区1号护甲保险箱", 
["addation_6060b6753de11536"] = "\"Gensec样式\" Gensec", 
["addation_eb54303a2646df00"] = "\"火热迈阿密\" Hot Miami", 
["addation_808a3997ac6db1db"] = "\"火热迈阿密\" Hot Miami", 
["addation_7cb4c18a99c01b39"] = "\"环卫保洁\" B.I.N.", 
["addation_3791fbb1a67246f2"] = "\"亦匪亦警\" Police", 
["addation_f6194c73d88f2a2c"] = "\"M90型迷彩\" M90 Camo", 
["addation_874e9cfe2b4dca48"] = "\"嗜血成性\" Slayer", 

-- ———— 犯罪狂欢
["addation_90e0e129b2dd3571"] = "\"纯黑\" Black", 
["addation_04ec64edd911e482"] = "\"深绿\" Green", 
["addation_97ec19e701548675"] = "\"骨灰\" Grey", 
["addation_a99fbdecb5a4af66"] = "\"军蓝迷彩\" Navy Blue", 
["addation_ff8daa00c65746fe"] = "\"黄褐\" Tan", 
["addation_d8597fc7a2202c5a"] = "\"数码迷沙\" Desert", 
["addation_c6d89bb4a68056cb"] = "\"暮色散沙\" Desert Twilight", 
["addation_8ae3919afc456935"] = "\"劫如迷灰\" Gray Raider", 
["addation_61da35e019311e3f"] = "\"卡其与黑\" Khaki Eclipse", 
["addation_50c1b6a376c8ae0d"] = "\"标准卡其\" Khaki Regular", 
["addation_9cd834f324146f46"] = "\"灰雾蒙蒙\" Misted Gray", 
["addation_2fa52372588f9cd5"] = "\"深海迷蓝\" Nevy Breeze", 
["addation_970bd05742b1ec3a"] = "\"深林暗影\" Somber Woodland", 
["addation_d4221d56a168a82b"] = "\"乌木树桩\" Tree Stump", 
["addation_f76be16814345db3"] = "\"数码迷林\" Woodland Tech", 
["addation_60026b597b5a90ba"] = "该护甲皮肤可以通过游玩##犯罪狂欢##获得。", 

-- ——————————————————————服饰(217条)——————————————————————
["addation_5ceb0becc3c347ae"] = "服饰", 
["addation_5fe443dd5100f25c"] = "护甲与服饰",
["addation_fc54d89b1067d20a"] = "装备服饰",  
["addation_850b20992c819409"] = "浏览服饰", 
["addation_b992a11690fee2aa"] = "自定义服饰", 
["addation_66ffa9e470cb98c3"] = "自定义服饰", 
["addation_17a2183f51372fc1"] = "浏览样式", 
["addation_f3a0d91c5d6f124a"] = "装备样式", 
["addation_67967e309c50ecd0"] = "裁缝1号", 
["addation_05c7c89694a97b7a"] = "裁缝3号", 
["addation_7e4471f5a070f6b2"] = "购买裁缝1号DLC以解锁", 
["addation_1ced2ba876f6f0cd"] = "购买裁缝2号DLC以解锁", 

["addation_32985e032db3134f"] = "默认服饰", 
["addation_9806bb6add41ab2b"] = "劫犯的默认服饰，配上已选择的护甲。", 
 
["addation_c842a465f268c244"] = "条纹闹事者", 
["addation_2a384793633d2920"] = "道理你都懂，你只需说出三次咒语。时刻记住... 他能搞到所有你想要的东西，他能骇入所有你想骇的设备。念出他的名字，他将赎你出狱。贝恩！贝恩！贝...",

["addation_be912d912e478991"] = "万中无一", 
["addation_9045ccaee5e85f64"] = "霍斯顿曾在纽约的一次夜间行动中失手，被三辆警车围追堵截。将沾满敌人血渍的武器和面具丢进下水道后，他径直前往他最喜欢的夜总会去避避风头。(顺带去那儿痛饮一杯。)在经过一家商场的时候，这套西服吸引住了他的眼球。意识到自己不能再继续保持低调的霍斯顿迅速闯了进去换上了那套西服。等第一辆警车驶过路口时，霍斯顿早已凭借他的英式风范，搭讪着排队等候入场的女士了。车前灯一次次地从他眼前经过... 而驾驶员一直没认出他的目标。", 

["addation_89aca297ee12ac27"] = "街头乐手", 
["addation_1917c9c9c7cad56e"] = "制作一件正统的街头乐手服的难度可不容小觑。有些看起来简单的结构，在背后往往都蕴含着代代相传的复杂工艺。", 
["addation_9d5a2af1722ce0cc"] = "午夜夜曲", 
["addation_c7d987c635493096"] = "沃尔夫走进唱片店，一心想购买他最爱的乐队的新唱片(真的会付钱的那种)。当他关上身后的门时，他难得地露出了恐惧的表情。12英寸的唱片盒在哪？他气冲冲地走到柜台，抓住穿着运动服的混蛋的衣领，咬牙切齿地说到：\"他娘的唱片呢？\"。在那可怜的收银员解释着光碟要比黑胶唱片高级时，沃尔夫则在不断地咒骂着货架上的每一个\"高级\"碟片...", 
["addation_501fa2086a4151c8"] = "尘土恶魔", 
["addation_2a8738ff24a5d7aa"] = "在从军队退役后，钱恩斯需要暂时失踪一段时间，去到某个能够让他尽情放纵的地方。有人告诉他旧金山是个好地方，但他们没考虑过那边成群的摇滚乐队。我们都知道钱恩斯爱死摇滚乐队了是吧？尤其是特别低俗的那种(并没有)。总之，钱恩斯没在旧金山待多久，于是他开始往南部走，并在墨西哥的马里亚奇节上被当成了特型演员，直到命运为他安排了接下来的计划。至今，还没人敢问他是否喜欢那边的传统音乐...", 
["addation_c12444b778a2632d"] = "圣徒之肤", 
["addation_26e49654538b5300"] = "这套服饰的布料背后有一个故事。一位织布工，坐着骡子赶了五天的路，与骡子分享着仅有的一点点水，与高岩峭壁、狂风暴雨、拦路盗贼做搏斗，最终赶在庆典之前到了裁缝面前，制作了这件衣服来纪念他死去的女儿。在庆典当天，他发誓他在天空中听到了女儿的欢笑声。", 
["addation_bd78dc07d3953034"] = "特奥蒂华坎", 
["addation_fd0e46dd14656a4d"] = "传说有一只沙漠蜘蛛，当风吹过它那错综复杂的网，将会发出瘆人的惨叫声。有人说这些网是捕捉到了那些死于枪战的灵魂，另一些人则认为网会补捉古代玛雅神谴责当今现状的愤怒之声。", 
["addation_4e1d1108c0e5d4b4"] = "卡翠娜骷髅", 
["addation_3931f4222703ffa0"] = "亡命之徒从献给他死去爱人的花束中取出一支玫瑰。他发誓要让夺走她生命的联盟成员血债血偿。他将穿上她记忆中的那件刺有玫瑰的外衣，去向他们讨回公道。", 
 
["addation_81aff21a9f003f8c"] = "黑水制服", 
["addation_81dd55729b299b9a"] = "黑水的制式军服，侧臂上缝有黑水logo。", 
["addation_674bf950ebeba549"] = "雨衣", 
["addation_162969766e9b3491"] = "朴素的黄色雨衣，能为穿戴者遮风挡雨。鲜明的颜色有利于在能见度低的暴雨中避免发生车撞人的交通事故。", 
["addation_da0c970bd5528028"] = "手术服", 
["addation_590765916427f598"] = "医护工作者在医疗前线奋斗时会穿的防护服。服饰的整体配色相对温和，同时也能凸显出沾染的血渍或是其他体液。", 
["addation_f99e2f276903df10"] = "战术迷彩服", 
["addation_4a8b4fc2db989364"] = "潜行专用服饰。舒适的服饰结构不会对潜行时的动作造成拘束，软质的黑色材料方便穿戴者在夜间行动时藏身于黑暗之中。专门设计的口袋方便穿戴者携带装备与弹药。", 
["addation_f62a982b03260be1"] = "晚礼服", 
["addation_b4aaf904b4f90390"] = "为重要场合准备的晚礼服。独特的黑白设计，搭配出众的黑色领结。", 
["addation_a5a5f029c861eb8d"] = "冬季迷彩大衣", 
["addation_5121e833717accd3"] = "军用冬季迷彩样式的全身服饰。整体样式意在降低穿戴者在雪地中的可见度。",
["addation_71f16c27e7c3a2dc"] = "传统战术式", 
["addation_3fb054101b4f789d"] = "永远也不要拒绝一件上好的全身式战术护甲，战术口袋这种东西是永远也不嫌多。在Payday帮早期的生涯中，钱恩斯特地花了两个月时间来组装、测试、调整与研究这套护甲，企图突破其极限。多年过去，它依旧维持了大部分当初的设计，并在高强度抢劫中广受成员的青睐。", 
["addation_7c6afd57a8d53b6a"] = "维修工", 
["addation_8fac1bca284fcd53"] = "当无法拿捏下一步行动的时候，扮演维修工永远都是不二的选择。这大概是无数低俗电影和垃圾连续剧里最无脑的套路，但它又绝对能为剧情提供突破口。你要是一天不看电视不上厕所绝对憋得慌，而富人们只在意自己的游泳池能时刻保持崭新出厂的状态，这就使维修工人(不论男女)都能随意进出泳池。不管怎么说，这套行头也是相当实用，有许多装东西的口袋，方便在狭小空间内作业。穿着这行头往保险箱里灌水时，没人会来怀疑你的。", 

["addation_93bf26623fa2a513"] = "运动便服", 
["addation_32887ed3986c7fe0"] = "虽说穿着两件套西服抢劫能现得你相当的\"专业\"，还能给在场的人质一种居高临下的权威感，但实战方面，它一点也不舒适和实用。光是舒适这点，你觉得在银行里激情互射，对着保险箱上下其手时，西服这玩意不碍得慌吗？久而久之，在江湖上就有了这条约定俗成的规矩：如果不是在严肃/正式场合，劫匪们被允许穿着更为实用的运动便服行事。", 
["addation_95399f4360670fd4"] = "达拉斯 - 毁约者", 
["addation_d9d48348d9cbf629"] = "小知识：达拉斯最初为芝加哥黑帮办事，而这件外套从一开始就陪伴着他。他与年轻的女线人马克有着一些矛盾，而这也成为了未来他选择背叛组织的诱因。", 
["addation_5d89cad8c62b405c"] = "钱恩斯 - 百夫长", 
["addation_6f7fd7025597b2fe"] = "小知识：钱恩斯在与喝得半醉的弗拉德碰面，并听他唾沫横飞地叨逼叨了大半小时卖保险箱发大财以后，他将旧的那件运动服丢了，买了这件。", 
["addation_f01169ab39c5c4d4"] = "霍斯顿 - 骗术师", 
["addation_1bcf5d791e86b323"] = "小知识：在90年代那会，霍斯顿曾痴迷过一小段时间的健身。他跑步，举重，甚至还去学了点板球。在那段时间里，他对健身的狂热几乎掩盖住了对威士忌的狂热。几乎。", 
["addation_fcee8bf16ba4e827"] = "休斯顿 - 追逐者", 
["addation_30110f7a7e6427e4"] = "小知识：在达拉斯开始他的犯罪生涯时，休斯顿还在亚特兰大郊区经营者一家枪店，钱恩斯是那儿的常客。一次达拉斯背叛了芝加哥的黑帮，急需掩人耳目，休斯顿收留了他，好让他避开风头。那是休斯顿唯一一次觉得自己独立于他的哥哥。", 
["addation_217e16ce0e19bcfe"] = "沃尔夫 - 低吠者", 
["addation_80f1996a2688fb98"] = "小知识：沃尔夫在瑞典北部的基律纳郊区有一座小木屋，他每年都会回到那里，在林间尽情奔跑(据说在沃尔夫奔跑的时候，熊都怂着不敢出来！)", 

["addation_aa73179170c8b225"] = "作秀之人", 
["addation_4ab5b506288980da"] = "敌人低迷的意识能使劫匪有可乘之机，而正确的服饰正好能分散敌人的注意力，让他们分不清场上的状况：“马戏团进城了？哪门子的小丑会带把枪？”照这样的思路来看，只要你穿得五彩斑斓、造型别致，抢劫什么的都不是事。总之这件服饰不仅外表光鲜亮丽，同时能让你觉得像是罪犯的君王。", 
["addation_0f2602da664ff07b"] = "惶恐之紫", 
["addation_6172009ecea25c4c"] = "他游走在大街小巷之中。作为一名不知名反社会者，没人知道他的名字或是来历。据说他是拿铅笔杀死黑帮的第一人，但如果你有机会能与他面对面相做，你绝对会坚信这个谣言。而他的衣裳... 他的衣裳... 不知他是真疯，还是精于扮演的天才？还请您自行想象。", 
["addation_7ff5b796b5791b88"] = "讲师之白", 
["addation_02f106f4e97d8412"] = "杜克在大学时的一名讲师很喜欢在穿着白色西服时搭配颜色花哨的衬衣。直到有一天他被指控作为一个大型走私链中的一环，不断地为学校博物馆提供稀有珍品，他作为讲师的伪装也因此打破。此事一出，各界哗然，学校也几近废校。而这位讲师也在事情败露后销声匿迹。杜克经常会穿着这套与他风格类似的服饰，对他表以纪念与缅怀。", 
["addation_bd0c8b267571deb0"] = "漫画风绯红", 
["addation_40545565c8a7ef51"] = "这件西服承载了无数令人闻风丧胆的劫匪的记忆。再具风格化的面具，也支持不起这件衣服所承载的分量，但来自生活的磨练，使他充满了百战不殆的决心。这名劫匪会是谁呢？谁会如此疯狂，穿着如此鲜艳的服饰，使自己成为警察视线中的焦点呢？", 
["addation_4fe23667bdcfd08e"] = "黑白分明", 
["addation_54e4c5905050be5c"] = "左与右，生与死，愉悦感与无止境的臆想使你的人格一分为二。不管怎么说，你至少能和另一个你进行思想上的辨证了...", 
["addation_15657b4bbdafbece"] = "古旧之黑", 
["addation_5c7d08feb0a99658"] = "很久很久以前，在一群小偷之中，有一只弱小的老狼。老狼喜怒无常，善用暴力，还会靠假扮老妇来讨要金钱。有一天，老狼的脑海中突然浮现出一个想法。他偷了一件黑色丝绒西服，并试图依此混入当地大学的讲座中，以为自己能够富人们手中诓骗一些金钱。不幸的是，他在入口处就被园丁给撞上了。园丁拉响了警报，而老狼也被迫折回了它的巢穴。", 

["addation_9369a49d7c0927e1"] = "传统风格", 
["addation_c507c289668c94ba"] = "在传统的犯罪事业中，你所携带的装备是重要的一环。机动性与耐用程度将决定你今天是吃大餐还是吃牢饭，而这套装备就是为防止翻车而生的。全身式内衬，搭配强化版多功能背心，在适配全地形的同时方便穿戴者携带重组的道具。", 
["addation_a93d4c2613d45973"] = "灰色困境", 
["addation_46a7d06792a3fe8b"] = "只有极少数人能在探知困境时情愿抛弃一切。年轻时的达拉斯天真地以为他能够做到无所拘束，而这差点就葬送了他的理智与自由。当时他身穿的正是这套装备，而事实证明，那天正是它拯救了达拉斯一命。", 
["addation_a34b1b666413db84"] = "狂杀之红", 
["addation_f7b872c7e7ed2c60"] = "拿城市名作为自己名字的人脑袋里都在想什么？这是巧合还是单纯的因为他们懒？难不成是因为缺乏想象力？再或者是因为贝恩，他们从很早开始就谋划着更大的计划，某个宏伟的计划。所以接下来会是什么，名字基于德克萨斯州的拉伯克的劫匪？叫东京也不错？感觉是不是有些过了？我们还能这样延续多久呢？还能延续到第三部吗？真正的答案也许只有生者才能悟到。", 
["addation_d840c9f419a957a2"] = "钱恩斯的迷彩", 
["addation_e699f28831d8d2df"] = "在安全屋中的某处(你可以放心大胆地去找)有一个保险箱，钱恩斯将对他意义特殊的物品存放其中。这套制服正是他的收藏之一。出于某种原因，他十分珍重这套制服，只会在特殊场合中穿上它。要是有劫匪胆敢\"借用\"它，钱恩斯就会请对方尝尝他的铁馍馍。", 
["addation_fae4dc131ffdeddb"] = "尘中恶魔赭", 
["addation_ee40dd96587ae3aa"] = "Payday帮迄今为止还从未接手过南部地区的活(除去南部边境)。但为了以防万一，洛克储备了大量沙漠款式的制服，以便在沙漠平原中提供良好的隐蔽。", 
["addation_a3520263dc8be43d"] = "一桶子蓝", 
["addation_5491182620c033a5"] = "曾经有个劫匪叫史蒂夫，他有个绝佳的抢劫计划。他叫上了他的伙伴，开始了计划，但很快就失败了。他们抢劫了一家银行，但跟开玩笑似的，他们穿了件贼鸡儿蓝的制服，比画家身上沾染的蓝色还蓝。控制住人质，迫使他们参与，直至某人损毁了地板，祈祷条子不会从正门突入。", 

["addation_ece507668b499673"] = "阳光黎各", 
["addation_f78bc4f5dfc5a302"] = "除了防弹，好的防护应该理所应当地起到掩人耳目的作用。这套上世纪80年代风格大衣的宽松口袋能很好地隐藏住武器，而多样的面料能够根据天气的变化进行调整。", 
["addation_743485be1bd413c0"] = "腼腆之蓝", 
["addation_279dd0b6b670eb8f"] = "有一次桑格雷斯奉命护送一架装载了非法来源的武器的飞机从巴西飞往墨西哥，他的伙计，当时正好穿着这身行头，在飞行途中突然反水企图劫机。在短暂的搏斗后，桑格雷斯将他一脚踹出了货舱门。当他的(前)同伙在半空中尖叫着挥舞双臂时，桑格雷斯明锐地注意到了蓝色的西服与蓝天竟融为一体，直至他\"bia\"地摔倒地上。",
["addation_937d39959ba5dbc7"] = "迪斯科白", 
["addation_8a92541f1bb1eb36"] = "据说，迈阿密警局的档案中存有这样一张照片，达拉斯身着你眼前的这身衣服，开着敞篷的法拉基尼F型驰骋在大街上。当然，这只是谣言。每当有人提及这件事，达拉斯就会情绪激动地否认这件事，而迈阿密警局也会有一名身份不明的人员试图用各种方法摧毁档案馆：灌水，纵火，或是炸毁...", 
["addation_d46d5d5381fb5e87"] = "凯迪拉克粉", 
["addation_a6ac28050126813d"] = "拉斯特曾在德克萨斯州的丁东市执行任务———侦察当地的Overkill-MC集团时———穿着这套行头。当他钻入当地的下水道时，四周的人向他投去了异样的目光，但没有一个人胆敢惹他的麻烦。当有人敢在德克萨斯街头穿着这身行头，那他绝对是那种有种的人。", 
["addation_3b19a32d9e5482fd"] = "沼泽之灰", 
["addation_edede34845b3b164"] = "吉米坚信，这套衣服的伪装色牛逼到足以骗过佛罗里达沼泽地的鳄鱼。霍斯顿愿意出两万美刀，让他亲身证明一次。他至今还拖着没试，每当有人在安全屋内提起这事，他只是挥挥手，轻描淡写地说:\"咕了咕了，明天再说。\"", 
["addation_532004b0e9fec24a"] = "黑色庆典", 
["addation_3a0a010889f8eb26"] = "劫匪的内心永远坚如磐石，而且他们中的极少数人会常涂睫毛膏，但这是有理由的，也许他们在某个时间，打心底突然想尝试下哥特风，毕竟谁还没得过和中二病呢？当然这也可能是假的，也许他们只是单纯不想穿带色的衣服。", 

["addation_e1087ffd8802349f"] = "典雅样式", 
["addation_4d3f3724221a906f"] = "穿着这身服饰的劫匪行事时的动作往往都饱含最郑重的敬意，但又随意且熟练。服饰整体下缚上宽的剪裁与这类劫匪简直是天作之合。", 
["addation_0e4bd0165bff8963"] = "灰色救赎者", 
["addation_7dc933148b938283"] = "很久以前，有一团黑影穿过黑暗的地下犯罪世界，带走了最闻风丧胆的暴徒的性命。没人知道他生前经历了多残酷的折磨。恐惧吞没了美国的犯罪头目们，没人知道何时复仇将降临至他们头上。只有极少数人瞥见了这游荡中的恐惧，但没人能说清它是一个还是一群。他们唯一能描述出的只有那死亡的穿着———就像这一件一样。",
["addation_68cbabc093998cd5"] = "神父的白色谎言", 
["addation_b883eb77d1d838d4"] = "帮派首领带着他的家人走入一家餐厅，准备坐下来美餐一顿。在此前的一周里，他下令扫清了一整个帮派。但他不知道的是，那个帮派的唯一幸存者，已经在卫生间内等候多时。还未等首领脱下他的外套，幸存者就从背后开了一枪，了结了这场血雨纷争。", 
["addation_99bf481ede96604f"] = "子弹铜棕", 
["addation_b885da3b91ab052c"] = "阳光散落在深绿色的车漆之上，一辆V8发动机跑车正疾驰在高速公路上，而后面紧跟着不下十辆警车。他们在旧金山拥挤的街道中来回穿梭。一滴汗水流过驾驶员的脖颈，使她分神撞入了(并不)著名的伦巴弟大街。当警察还在苦苦搜寻之时，她已经弃车而逃。在此之后，没人知道具体发生了什么，但有谣言称当他们追寻她至唐人街后，她棕色的外衣成功帮她混入了人群之中。", 
["addation_d78d5b42ebcd1d4c"] = "工人之蓝", 
["addation_fae944275bfe73f6"] = "索科尔曾于一位名叫德米特里的建筑工人有着好交情。他们曾在同一个酒吧观看棒球节目，一周复一周。这件大衣总让索科尔回想起当初的日子，毕竟德米特里有一件相似的外衣。他的外衣被磨得很旧，衣角已经被磨破，也沾染了许多尘土。但他因此为荣，毕竟每一个小污渍都对应着一个有关自豪工作的生活故事。", 
["addation_064310a098e3a05f"] = "战利品之黑", 
["addation_7107ef58db0240f3"] = "被一名著名的赏金猎人穿着十年的夹克。多年来他一直试图猎杀贝恩，早在Crime.net建立之前。最终他不幸失手，死在了贝恩手下，而这件夹克也被当作战利品保留了下来。", 

["addation_db72ad341d3f1acc"] = "仪表堂堂圣诞装", 
["addation_26d2544d7c6ab5c3"] = "圣诞前日，劫匪们顺利潜入至金库面前，但却无功而返。憨批洛克，无意中忘记带上打包的钻机，此前无人发觉。当图奇还在撤离车内龟缩之时，吉米气得砸碎了一扇玻璃，毕竟他有这能耐。玻璃碎片但落在克洛芙，桑格雷斯，夹克男和威克身上。没人愿意相信，弗拉德的小舅子会将他的圣诞\"好运\"降临于世。", 
["addation_fb685a20aadf505f"] = "精灵盛宴", 
["addation_807e58a060e05d04"] = "一栋小木屋坐落于白雪覆盖的森林之中，一缕缕烟雾从石烟囱中升起。一切是如此安静，只有树木枝叶被寒风吹动时的沙沙声。在不远处的洞窟内，一家野鹿正在其中相依取暖，躲避捕食者。但仅在今夜，沃尔夫(狼)并未外出觅食。他坐在小屋的炉火旁，手握着一杯蜂蜜酒，沉思着他作为劫匪的曾经。", 
["addation_6f957c7c9a70780b"] = "意外伤害鲁道夫", 
["addation_b2b9d99271cc962f"] = "杜克在圣诞前夜喝了太多的白兰地。当他在试图组装老霍赠予他的老式英制左轮时，他的睡意逐渐朦胧起来。随着响亮的一声\'叮\'，扳机被弹飞了出去，而杜克的一只爱猫——此前一直蹲坐在桌子旁的凳子上看着他——也紧随其后，飞扑了过去。它们都撞在安全屋内的圣诞树上，而圣诞树也因此从顶楼摔下，狠狠地砸在地上。随即就是一声惨叫，和一句\"上面他妈发生啥了？\"。几分钟后，钱恩斯戴着圣诞帽，手捂面部，气冲冲地走上楼，看起来很生气的样子。他移开他的手，露出那又红又肿，像驯鹿那样通红的鼻子，就好像被倒下的树木砸了一脸那样...", 
["addation_493deb45b2826cb9"] = "奇迹幻蓝", 
["addation_52a4973e805da22b"] = "辛妮探出小巷，看着闪烁着红蓝灯光，大响着警笛的警车呼啸而过。她理了理装满物资的包裹，并拨通了电话。\"喂？\"，电话另一头传来声响。\"是我。就在34号路口。一切安全，尽快赶来\"，她回复到，挂断了电话并开始等待。冷风呼啸，吹得雪花四处打转，她注视着黑暗，焦急地发着牢骚。几分钟后，一辆货车出现，司机下车向她打了声招呼。\"货物都在哪？\"他们走入小巷，辛妮指着一堆纸箱，上面躺着一条母狗，正在喂养着它的幼崽。辛妮拿出一大捆钱，递给了那名司机，\"你知道该做什么的，老兄\"。司机接过钱并回复到：\"你尽管放心，我会确保它们的安全的。\"", 
["addation_798670a03cfd0b65"] = "圣诞老拉斯特", 
["addation_93686737021c5af5"] = "好巧不巧的，拉斯特的机车坏了。他是赶不上安全屋的圣诞派对，也喝不到治郎的加蛋黄的清酒了。淦。他背上背包，开始徒步而行。太阳开始消失在雪地之下。当他走过一座破旧的农房时，他听见里面传来一声尖叫。拉斯特犹豫了。虽说这并不关他的事，但偶尔瞎掺和一次也不算坏事。透过窗户，他隐约看到有人倒在地上。他冲入屋内，发现一位在装饰圣诞树时不慎摔倒的老妇人。在帮助并悉心照顾她过后，他被邀请留下来喝杯茶再走。他很幸运地得知谷仓内存放有一辆仍能启动的经典老式机车能供他使用。也许他不会错过那场派对...", 

["addation_f1ebc59f48c60270"] = "肮脏的圣诞老人", 
["addation_fd243ed30571f289"] = "说真的，要是圣诞老人穿着这一身从你家烟囱里摔下来，你绝对不能指望他给你带来什么好康的礼物。不光如此，他可能还会在走之前顺走你家的牛奶和小饼干。不过就像贝恩先前说的那样：\"收获之日即为收获之时！\"，让圣诞老人收获点东西权当是做好事了。", 

["addation_7103baf1718d6291"] = "喜庆大劫匪", 
["addation_080c93685edcda6e"] = "圣诞老人的精灵都罢工了！今年北极的玩具产量为零！还不快穿上圣诞老人的衣服，替他从全国各地的银行、珠宝店、保险柜内拿点\"慈善基金\"（指赃款），并将快乐散播出去（指被劫产业获得巨额保险金），这样小劫匪们今年就不会收到煤块了。", 

["addation_e27c482a801ee872"] = "复仇枪手", 
["addation_b3fc27042c12e39d"] = "相传有那么一位扮作音乐家的枪手，他会为遭遇不公的人打抱不平，为无力反击的受害者代以复仇。当然了，这种描述好像和Payday帮没啥关系。", 
["addation_e68d0d00b0f6518d"] = "暗黑枪手", 
["addation_231f8d766f094872"] = "拉斯特和他的对手面对面而站，两人都紧盯着对方手中的枪管。太阳照在他们的额头上，好像时间静止了那样。拉斯特感受着持枪手的手心开始出汗，他开始小心地压下扳机。突然，一只乌鸦落在了两人之间。它左右看看，好像在判断谁能活过接下来的几分钟。它转头看向拉斯特，叫了一声，而他立刻按下扳机，了结了他的对手。", 
["addation_51342e5e9c9be291"] = "银色猎杀", 
["addation_ab717135cc3617a9"] = "一个孤独的身影骑着马进了小镇，他的腰上别有枪支，身后则背着吉他。由于长途跋涉，他的白色西服的边角上的磨损现得尤为刺眼。与它的马并行的，是一只郊狼，它疲惫地拖着它的长腿移动着。他们在一家破旧的酒吧前停下，男人拔出了枪，正对着前门瞄准，并射击。随着内部传来一声惨叫，郊狼立马冲了进去，几秒钟后，它背着一名暴徒样的试图出来。男人下马，把那具尸体丢到马背上，并往警长办公室走去...", 
["addation_9a38c8db18fd298d"] = "血色制造者", 
["addation_8d2db3d26df01bd8"] = "随着枪手逐渐倒地，他最后的气息将干裂地面的沙子吹了起来。在他的附近，一只蝎子默默地看着这一切。当秃鹰开始在他的尸体上盘旋，一个影子落到了他身上，一个陌生人在他身边蹲下。一只略显粗糙，饱经风霜的手伸了下来，拿走了枪手的手枪。一双冰冷的蓝色眼睛注视着枪身的金属。在感到满意后，目光这头的人站了起来，并向远处的地平线走去。", 
["addation_528a43a99c735f7b"] = "智者", 
["addation_fa46c0e5ae33fb37"] = "在桑格雷斯还小的时候，他住的镇子里来了一支游浪墨西哥乐队。那时他被小号乐手吸引住了。当他鼓起勇气上前询问，如何有朝一日成为一名音乐家，那名乐手说：\"你需要不断练习，小伙子。没日没夜地练习。它将代表你的一生，你的灵魂，你的爱人。\" 好吧，我们都知道桑格雷斯最终没有成为音乐家，但他的确听从了乐手的话，将他的全身心投入在... 他的职业之中。", 
["addation_94d4694af1f5688a"] = "坏蓝小伙", 
["addation_f0ca0714d76580b5"] = "达拉斯走上舞台，一把夺过吉他手的吉他。吉他手刚想反抗，但被达拉斯的\"信不信我特么宰了你\"的眼神瞪了回去。达拉斯握着吉他的指板往柜台走去，那边正有一位穿皮衣的正在骚扰一位女士。在其他人反应过来前，达拉斯抬手把吉他抡圆了往混混头上砸去。混混应声倒地，脸上满是被木头碎片划出的伤痕，而达拉斯则抓起一瓶和他一样刚烈的酒，转身离去，留下那名混混昏死在地上。谁说骑士精神已死？", 

["addation_d8a1127361c7d03c"] = "说唱之人", 
["addation_d0abaa8c1536839d"] = "这是被压迫者的节奏，它基于从城市街头诗人内心酝酿出的狂怒，试图掩盖住城市中心的喧嚣。贫民区的声音将被永世回荡，社会制度的围墙将会倒塌，并最终开启新的未来。", 
["addation_01d1da65f56927d2"] = "犯罪大师的神速", 
["addation_807d1524146b0bfc"] = "三个混混将治郎包围在小巷内，对他说着种族歧视的话，并要求他拿出钱包。真希望他们能明白，这将对他们，和他们的帮派带来多大的打击。治郎的内心静如止水，他还急着赶路，没时间也没理由花功夫应付这三个谜之自信，蛮不讲理的混混。几分钟后，治郎独自走出巷子。从巷子内可以隐约听到混混们的垂死呜咽声，他们的血液混杂着沥青缓缓流入雨水沟中...", 
["addation_b086788550d4e9da"] = "嘻了个哈", 
["addation_691072b8216a57ab"] = "加思有着滑滑板时绝不穿这种裤子的好习惯。万一他穿着这裤子为Payday帮跑腿时，裤脚不小心卡进轮子，把他绊个狗啃泥，再被卡车司机撞转生就不好了。", 
["addation_73f2767412fb63bc"] = "狼狈之人", 
["addation_828eac816d18646d"] = "马文几天没吃东西了，该死的Snoopfather帮洗劫了他的房子，并抢走了他最后的积蓄(这些钱被很合逻辑地藏在了一捆假莴苣中)。想着他那空空如也的胃，他径直走向Snoopfather的领地寻求复仇...", 
["addation_a819a192edec9351"] = "时髦战争", 
["addation_b7549fd22dd10f04"] = "这是史前从未有过的战争，对阵双方都带上了大规模杀伤性武器，金属vs嘻哈，这是最终的厮杀。最终谁会获胜？是穿着斑马紧身裤的那队，还是反穿裤衩的那队？", 
["addation_575a1fd8e9c54614"] = "影之老吴", 
["addation_da13d32adc2032e8"] = "警笛响起，城市功夫大师正在房顶间穿梭。时间流逝，他的心脏在耳内有节奏地跳动。他每一步都逐渐契合上节奏。在前方，两个屋顶之间有段很大的空隙。建筑的另一侧的烟囱上，则挂有为他准备好的奖品。他做好了准备，是时候起跳了，他的一只脚勾上了边缘...", 

["addation_a4d7f4189687336e"] = "偷盗至死", 
["addation_da9a4851e88b5b1d"] = "想当年，抢个劫真是再简显意赅不过了。骇入就是单纯拿小刀切个电线，枪手靠的都是硬实力，打开保险箱的方法和撤离司机的安排也更加重要。", 
["addation_957ac7e8bc197b20"] = "小小庇护所", 
["addation_7f9921530b4cbf86"] = "钱恩斯带着他的自豪与喜悦，踩下他那1968年产敞篷车的油门，以每小时88英里的速度驰骋在死亡谷的高速公路上，卷起一道尘埃。他希望油箱内的油还够用。在汽车后座，霍斯顿正鼾声大作，空麦芽酒瓶在他脚边滚动。后视镜中，蓝色的闪光灯在远处闪烁，并不断靠近。已经无路可逃了，钱恩斯减慢车速，保持在55迈。灯光在不断靠近，警笛声也逐渐盖过引擎声，好像巡警队正是冲他们而来。出乎钱恩斯的意料，警车径直经过了他们，明显在追捕其他猎物。",
["addation_aeb1131f59936000"] = "蜥蜴之主", 
["addation_aa532280f57ff16f"] = "房间内烟雾弥漫。仿佛是为舞者准备的聚光灯，苍白的阳光透过肮脏的窗户，投下了阴影。所有人都带等待蜥蜴之主的搞来。门打开了，他就站在那，光线照出了他身体的轮廓。一道光线反射到他的眼角，并从他的视网膜中反射出来，展现出类似爬行动物的光芒。他在沙漠中到底看到了什么？", 
["addation_3683137624976bd3"] = "加利福尼亚之梦", 
["addation_09fb38ef3559fc57"] = "人群正向台上的魔王尖叫，四个大音响在不断循环着拉锯音，这是光线与音乐的狂欢。人们都太投入于此了，没人注意到一名技术人员把乐队的备用设备装上了车，开进了黑暗之中寻找最近的庇护...", 
["addation_cb0c060bc0e0146b"] = "和平制造者", 
["addation_b51c7145ed3a3a58"] = "杜克翻阅起了他的老照片。我的天，杜克家族在六七十年代的打扮不讨喜了，真就不存在时尚感那种。他父亲曾就穿过这身你敢信？不过没准劫匪们穿上这身就能好看点？", 
["addation_ae45b0768e3e1056"] = "白兔", 
["addation_bf481b14e1abc471"] = "1960年末，他出生于世。他的一生曾充满混乱、背叛与厄运，直到他遇到了将会成为他人生导师的人。导师教会了他许多事情，为他讲解了世界的运作方式。导师谈及过一本书，它只被少数人所知，能够解答世间的一切奥秘。他将这件事铭记于心。他最终成为了世界最伟大的犯罪首脑，他将对所有冤枉过他的人施以报复，并负责策划最终无人知晓的最伟大的劫案...",  

["addation_1ba66d814b674970"] = "朋克暴徒", 
["addation_11fa352fb1732bab"] = "穿着朋克摇滚服饰就好比穿着全身护甲，你的内心得饱含藐视\"文明\"社会规则的荣耀感。一件真正的朋克夹克，上面的饰钉和配件都得是自己手工做上去的，每一个部件都得对穿戴者有着较深的意义。当然如果你只是想对全世界竖个中指的话，前面的就当我没讲。", 
["addation_1d83f3e4bd8176f7"] = "生活大爆炸", 
["addation_4701a7ffb5246c53"] = "辛妮曾经为了参加庆祝近期犯罪顺利的安全屋派对，脑一抽在当天把他的头发染成了亮橙色。那天晚上，弗拉德也来了，就跟他平时\"你依我就依，你不依我还依\"的作风一样。当他看到辛妮的头发时，他实在憋不住，用俄语吐槽说她像\"一根过熟的胡萝卜\"。不幸的是，辛妮还真就听懂了。一段时间过后，弗拉德在厕所里，笑着揉着他流着血的鼻子，决定以后永远也不再对辛妮的发色再指手画脚。\"不管怎么说\"，他想，\"挨了这次打也他妈值了！\"", 
["addation_cd390309b621c8dc"] = "人生如战场", 
["addation_754a44ec3710c1f7"] = "朋克曾令无数家长对当今的道德伦理产生恐惧，同时也拯救了无数废弃仓库，使它们以\"临时音乐会场\"的名义重获新生。在1980的一个晚上，德拉冈来到了伦敦码头等待他的合约人前来为他安排工作，一个有关臭名昭著的\"死亡周\"7天莫西干派对的活。那天，合约人并未现身，而此后德拉冈也再没获得他的音讯。到现在为止，他也不清楚到底发生了什么。", 
["addation_b5785da124047bc0"] = "白色婚礼",
["addation_70efdeca93db0904"] = "一天晚上，霍斯顿正从利物浦的冲撞演唱会回来，他嘴里哼哼着当晚他最喜欢的歌，走进了一条小巷。突然，从垃圾箱后面窜出来一个挥舞着刀子的光头暴徒。老霍此时满脑子都循环着那超牛逼的吉他solo，于是他一脚把持刀的光头小赤佬踢回了他原属的垃圾箱内，一边继续哼着他最爱的歌...", 
["addation_2aed10bc8d44da90"] = "洛克威海滩", 
["addation_238af32b6e20b8d4"] = "在纽约的音乐家圈子内，没人不知道1983年的\"音乐商店大洗劫\"。事情是这样，夹克男在他开始他的犯罪生涯之前，曾于一个与他关系较好的朋克乐队一起巡演，帮忙做些后台工作来换取一些啤酒和毒品。一天晚上，就在演出开始之前，乐队主唱最心爱的吉他的G弦断了。由于对老琴弦的音质并不满意，他指名了要在*所有商店都关门的情况下*搞到特定的琴弦，所以夹克男不得不靠些... 特殊手段... 来搞到新琴弦。他最终在演出开始五分钟前搞到了琴弦。", 
["addation_5b716ea9937730d8"] = "反世俗角马", 
["addation_882d81ff3ab211cd"] = "容忍。容忍着被一大堆破事多围绕着。它好似一块砖头，压在每个人的心头，迫使他们去忍受。除非你是那种高举拳头，敢于反抗的人。要是哪个劫匪穿着这身走进银行，那就是在向世界证明他无所畏惧！",  

["addation_83882edf570f54eb"] = "长袍绅士", 
["addation_644a22daa9a92b21"] = "有些人认为西服大衣早在上世纪90年代就已过时，但Payday帮从来不赶什么潮流——他们穿啥都显得体。", 
["addation_58a2520d14014aa8"] = "忧郁大衣", 
["addation_df72e4363ea1dc7c"] = "款式低调的深色大衣，专为想在夜间独行的劫匪设计...", 
["addation_e5dba323f23003cb"] = "猎手气质", 
["addation_4a05ec7690bc35c3"] = "无时不刻透露着你的优雅气质，无论你是在郊区的安全屋内，在战场上，还是坐在撤离车的后车位上。", 
["addation_0f75be5018b71056"] = "大气蓝色", 
["addation_ae0d229bf34d7f91"] = "优质且简洁的款式，如果你在劫案过程中透露出政治家一般的气质的话，这件服饰是不二之选。", 
["addation_60f33b2027cc8898"] = "虔诚之黑", 
["addation_37cd827c3e32bd68"] = "你可以不虔诚，甚至不信教，但你依旧能无时不刻地享受这件大衣的暗淡色调。", 

["addation_9c9cfbe7c6bfd0c8"] = "争强好胜", 
["addation_48422b92ad0715ab"] = "专为那些为得胜利不择手段的人而设计的服饰。", 
["addation_46b2795cf9628f0e"] = "沿路抢匪", 
["addation_150412b1a341d802"] = "让那些马车车夫立刻认识到你对马车上货物的渴望。", 
["addation_1d5433d582f1f816"] = "红色枪手", 
["addation_b54ab622472b8f26"] = "不管你在对你侧目相待的家伙身上开多少个弹孔，他的血色都无法盖过这套服饰浮夸的颜色。", 
["addation_3cc70b2be514a1aa"] = "卖弄风骚", 
["addation_b423bfea036084f5"] = "专为那些在与敌人进行决斗时，想要在等待正午期间在气质上先压过对手的枪手准备。(在等钻机的时候也没问题，你依旧是全场最靓的仔。)", 
["addation_cfbf9efbd40ba410"] = "狂暴沙尘", 
["addation_b385f6a361480b4c"] = "穿着沙尘卷土而来，物理性地让敌人看不到你。", 

["addation_ff21d81232941d4d"] = "恶名皮衣", 
["addation_63e46f8bf6c82373"] = "多披一件皮衣永远是正确的，它不光能让你看起来牛逼闪闪，还能让那些妄图招惹你的傻逼们再多想想搞事的后果。", 
["addation_3f317d4461da5572"] = "恶名黑色", 
["addation_1a3870bdd30b5406"] = "无论你是穿越时空的杀人机器，还是某个想在下场劫案中展现50年代工匠精神的人，这套服装都能满足你的要求，", 
["addation_bf8191b484072478"] = "恶名白色", 
["addation_7e1ab979eca6d1a5"] = "黑白配色最适合那些想在泥泞中摸爬滚打的劫匪了。", 
["addation_f6e4f1c51d5c0407"] = "恶名红色", 
["addation_e90a2a79bde955af"] = "用这喜庆的大红色凸显出你的恶名气质。", 
["addation_29779a3c980fd1ff"] = "恶名土色", 
["addation_2005fdac5afba9f6"] = "她骑着马缓缓走来，引得酒馆中刚抢得一笔的劫匪驻足观看。", 

["addation_5b62af6ff58bb99f"] = "劫匪帝国", 
["addation_9b66a3fcdd7b5fdd"] = "遥想当年，那时的动作片都和神仙打架似的。一群肌肉猛男做出反物理飞扑、子弹射得跟不要钱、尘土沙子溅得到处都是，典型的90年代末风格。如果你也想想体验那种feel的话，这套服饰将会是不二之选。", 
["addation_c188b0442bc5afc0"] = "棕色阵列", 
["addation_908767c99cea444f"] = "使用科斯林皮革制成，色调较浅且深沉。", 
["addation_436f056cccaa1686"] = "白色阵列", 
["addation_fa780d23fb53e256"] = "干净整洁的款式，保你成为摄影机下最靓的仔。虽说在混战中没人有闲心在意谁是谁。", 
["addation_7778e7d18bc9b502"] = "红色阵列", 
["addation_413cbf6d2b527857"] = "以红黑配色为主题，配以轻质漆皮外衣。", 
["addation_501eb8bfaf70081d"] = "黑色阵列", 
["addation_0d16c241304baa5d"] = "亮黑色的原型款，被部分怀旧人士视作最佳款式。", 

["addation_51fec7c21207a0d8"] = "剧院经理", 
["addation_efa6d6177a8dcc3f"] = "这套服饰上的白色纹理，象征着死亡。这是所有联盟老大的结局——当他们所犯下的罪孽赶上他们之时，即是他们寿命终结之时。", 

["addation_0f9a588f2d4ec72a"] = "龙纹夹克", 
["addation_4f314921048edc02"] = "不得不说，这些三合会的在把中年黑手打扮成精神小伙这方面还真有些能耐，不光穿着舒适，还不影响他们进行正常的黑道工作。说真的他们做的只不过是与时俱进：现代剪裁，太空布料，工坊制造。绝对不是70年代的垃圾功夫片里那种劣质戏服，我发誓。", 
["addation_726eeccf3d4191df"] = "龙纹夹克(异色)", 
["addation_8833741674d0e6de"] = "就这衣服，富家子弟都是跪着求爸爸妈妈给他买，好成为学校足球比赛上最靓的仔。", 
["addation_f5ae28009df6f3a4"] = "龙纹夹克(黑色)", 
["addation_11985b50f8c87440"] = "黑底夹克一染色，如黑夜之中一点光。", 
["addation_f7a92b9f8b38a9a6"] = "龙纹夹克(红色)", 
["addation_9de8d11c89b1f081"] = "有人指出，红色作为一个醒目的颜色，将显著地将敌人对你的注意力吸引到上半身。想法不错，但不值得尝试。", 

["addation_193b9da885ae511c"] = "武者风范", 
["addation_9a67f766d293c736"] = "对那些有幸能将工作经验转化为一门艺术类别的劫匪或杀手来说，这件服饰再适合他们不过了。传统剪裁，低调布料，在加上最新的战术纤维科技，穿在身上风吹雨打都不怕！", 
["addation_ea9cd696e4d9a814"] = "武术灰", 
["addation_2d33f9a7e5266792"] = "穿这身的都是喜欢在雨天行事的文艺青年。", 
["addation_9def01a2ec7fb57f"] = "红底金纹", 
["addation_ccb9e0398ac58455"] = "你的受害者最后所看到的将会是这件服饰那牛逼闪闪的纹理...除非你是从背后干掉他的。穿着这么牛逼的衣服去潜行，不觉得挺暴殄天物的吗？", 
["addation_3439a29c66f5e4c5"] = "武术棕", 
["addation_e6d545002c7b2c33"] = "为那些专挑阴沟小巷下手，既想不引人注目又想穿得漂漂亮亮的劫匪设计。", 
["addation_6025594e082d4bbb"] = "武术蓝", 
["addation_b398b3606f4e01d4"] = "忧郁的不一定都是蓝调。虽身着蓝色，该动手时还是得动手。", 

["addation_7f4a25b1b35f9042"] = "三合会便服", 
["addation_21cd00cb75b3bb0a"] = "再牛逼的三合会大佬，在过度劳累之后，也会腰腿酸痛、精神不振，好像身体被掏空。不过来砸场子的哪管你肾不肾虚，所以你身边得常备肾宝-啊不应该是趁手的兵器来保护自己，就像那位坟头草都一米多高了的索萨一样。这件衣服也是同理，虽然它保不住你的性命，但它能你落命的时候保住你的王霸之气！", 
["addation_ebb777bbd72c5272"] = "三合会灰色便服", 
["addation_1da738db9d5293d6"] = "为不想引人注目的劫匪设计的灰色款。", 
["addation_a560758588e91f12"] = "三合会红色便服", 
["addation_177cd91ed0f84fdb"] = "红配黑，脸不黑。", 
["addation_7b39479018f963c4"] = "三合会图纹便服", 
["addation_c0f026446c51d6da"] = "70年代风与现代的融合。", 
["addation_3594de6a6207d51b"] = "三合会蓝色便服", 
["addation_baa306bccdd2e0ba"] = "如果瑞典国王想当劫匪，还想穿中国款的杀手服，那他大概就会选这件。", 

["addation_f1be8ec256fc7017"] = "处刑使者", 
["addation_039e8ec01436181c"] = "这套服饰隐隐地透露着黑帮的霸气，不是吗？霸气的风格，搭配合适的大衣，有型又耐穿，保证你今天（或今晚）的工作有个好手气。", 
["addation_6eab88a1a9f788e1"] = "都市刑者", 
["addation_7d545d27e8c93539"] = "款式低调，但霸气侧漏。谁穿应该都有型。", 
["addation_5c430447fc47eab4"] = "三叶刑者", 
["addation_81b2c6284dfb81c4"] = "适合穿上在圣帕特里克挑个好日子办事。", 
["addation_3555864a0ac4a2bd"] = "巡察刑者", 
["addation_f095527456ef6ac9"] = "如果你正巧在搜查一颗粉色钻石的下落，而且你正巧还操着口可以的法国口音，这套服饰绝对适合你。它还带着个放放大镜的口袋呢。", 
["addation_ba4ce7a5a41ac380"] = "黑暗刑者", 
["addation_2d27dc75132ffe43"] = "低调且忧郁。如果你叼着根雪茄或是烟斗的话就更搭了。但装逼时也别忘了——$NL;不能抽$NL;烟$NL;抽烟$NL;死人的", 

["addation_be2b7310b4d1def4"] = "劫匪上将", 
["addation_a8c1fa63fce28cc6"] = "两军阵前，你一手执剑，一手放在这精心剪裁的服饰胸前。你的气质无一不被部下所敬畏，被敌军所畏惧。听啊！战斗的号角已经吹响！士兵的战吼已经响起！准备迎战！再之后——$NL;得得得得得得得得！啥？又坏了！这破钻机都不给劫匪点闲工夫做做白日梦！不过还好...至少你看着还算精神。", 
["addation_4f2392c2f153a8a6"] = "典雅上将", 
["addation_81906524f658cea0"] = "凸显优雅与领袖气质。", 
["addation_1533f168afdea394"] = "纯白上将", 
["addation_b3f8d492f6504899"] = "别的不说，这衣服的干洗费挺贵的。", 
["addation_3d0c50f9398ee234"] = "绯红上将", 
["addation_d186379186e3cf47"] = "跟你战斗过后的地面一个色。", 
["addation_f6679f493692ca90"] = "法军上将", 
["addation_3d30d4b046b529af"] = "战斗或游行用。$NL;本体不包含佩剑DLC。", 

["addation_ee3f32204d51ed3b"] = "老电工了", 
["addation_84c1126bcc333203"] = "无论你是想在大晚上去农场主家偷电，还是想悄咪咪潜入会议室，偷走所有没上锁的东西。无论目的是啥，这套行头都能满足你。", 

["bm_suit_boss"] = "劫匪圣徒", 
["bm_suit_boss_desc"] = "仔细想来，Payday帮干的事也没那么的复杂，也就是打打灰衣服的NPC、黑衣服的NPC，还有杀了会扣钱，还会站路中间当人肉盾牌的NPC。是，他们偶尔也会做点迷惑劫案，但和黑道圣徒里那帮人相比，Payday帮真的只配当拎鞋的。说真的，异种入侵、惊天阴谋、地狱传送门，有了这些缠身还怎么干活？总之，作为一个团队对另一个团队的敬意，穿上这身行头，向地下世界传播黑道圣徒们的精神吧。", -- ———— 垃圾润色，这段真的难翻

["bm_suit_highinttech"] = "战术款尼龙", 
["bm_suit_highinttech_desc"] = "轻便与功能性兼具，相较西方的同类竞品有着更高的能动性，深受亚太地区的警卫、雇佣兵与三合会成员喜爱。", 
["bm_suit_var_highinttech_default"] = "战术款尼龙(黑灰)", 
["bm_suit_var_highinttech_default_desc"] = "基本纯黑的款式。", 
["bm_suit_var_highinttech_orange"] = "战术款尼龙(朱红)", 
["bm_suit_var_highinttech_orange_desc"] = "朱红打底的款式。", 
["bm_suit_var_highinttech_green"] = "战术款尼龙(白色)", 
["bm_suit_var_highinttech_green_desc"] = "白色显干净的款式。", 
["bm_suit_var_highinttech_blue"] = "战术款尼龙(海蓝)", 
["bm_suit_var_highinttech_blue_desc"] = "海蓝色的款式。", 

["bm_suit_lowinttech"] = "传统款尼龙", -- ———— 直接和第一个颜色(黑色)共用了
["bm_suit_lowinttech_desc"] = "亚太地区的大城市所流行的街头服饰，耐穿且舒适，深受三合会与其他黑帮人士喜爱。", -- ———— 直接和第一个颜色(黑色)共用了
["bm_suit_var_lowinttech_yellow"] = "传统款尼龙(白色)", 
["bm_suit_var_lowinttech_yellow_desc"] = "贴身又实用。白色款式。", 
["bm_suit_var_lowinttech_red"] = "传统款尼龙(朱红)", 
["bm_suit_var_lowinttech_red_desc"] = "贴身又实用。朱红款式。", 
["bm_suit_var_lowinttech_blue"] = "传统款尼龙(海蓝)", 
["bm_suit_var_lowinttech_blue_desc"] = "贴身又实用。海蓝款式。", 

["addation_20c8b26960645074"] = "八年之庆", 
["addation_82c58dbb576c1ede"] = "劫匪的生涯能有几个八年？虽然不是什么大数目，但你依旧坚持下来了不是吗？开箱无数，运包无数，实乃劫匪中的佼佼者。因此，让我们用风度与奢华，来庆祝这个八年吧！", 
["addation_6c93907c1c2a208f"] = "八年之红", 
["addation_cb1a35a85ca0ace9"] = "为喜欢在红日升起之时庆祝的人而准备。", 
["addation_1dcf7d1e12508ab3"] = "八年之蓝", 
["addation_5b0cd07ada896cd9"] = "为喜欢在午夜之时庆祝的人而准备。", 
["addation_fc3c16cdaebc4514"] = "完成支线任务\"钱雨不止\"以解锁", 

["addation_7054234c01555317"] = "赛博卫衣", 
["addation_28c893cfa17b2f31"] = "结合了电子元素的现代卫衣。", 
["addation_888bb0919411b873"] = "赛博卫衣(黑色)", 
["addation_c9e18cbf840885f6"] = "电子风与黑暗紧密交织。", 
["addation_06473a46994b3127"] = "赛博卫衣(绿色)", 
["addation_7bef7106e6c351f3"] = "当你需要身着卫衣在丛林中行事时，这款卫衣能维持住你的style。", 
["addation_6a12d266c6fe3cda"] = "赛博卫衣(黄色)", 
["addation_e55e5df35f8b288c"] = "衣黄心不黄！", 
["addation_e53adaf16f919681"] = "赛博卫衣(红色)", 
["addation_356aa37587d2b663"] = "象征着你骇入网络时的火热。", 

["addation_265330fe062c5abb"] = "赛博风衣", 
["addation_a98474875125b8a6"] = "很好地将现代元素融和进了黑暗风格的风衣之中。", 
["addation_3a07e1e25f688fd3"] = "赛博风衣(黑白)", 
["addation_db70fdb5ca13dbc5"] = "有着老式电视的怀旧风格。", 
["addation_42917c8b19354884"] = "赛博风衣(绿色)", 
["addation_7913f62899d22800"] = "让你显得尖*酸*刻薄。", 
["addation_f4324f18c5b7f71e"] = "赛博风衣(黄色)", 
["addation_edc16a3227f3d635"] = "就像黑屏中的一条黄线。", 
["addation_2e119c11246f5eaf"] = "赛博风衣(红纹)", 
["addation_d9add6272f8f1558"] = "维持住边缘的火红。", 

["addation_ae0827ac92790fee"] = "十年庆典", 
["addation_b2824d94eadbbad0"] = "我们抢了十年下来。整整十年。好一个犯罪狂欢。我们已经等不及下一个十年了。你呢？$NL;$NL;想法提供：Angusburgers", 
["addation_c11aeb0d26da739c"] = "最有威严的小丑", 
["addation_b825bd3d574519f4"] = "当达拉斯还在为了掩人耳目，帮忙经营钱恩斯的靶场时，他从未想过会成为有史以来最成功的劫匪，直到他遇见贝恩。他坚持了下来，他维持住了他的色彩，而且仍在不断变强。这件服饰可能会被一些人所嘲笑，但任何劫匪小丑都将以穿上此身为荣。$NL;$NL;想法提供：Angusburgers", 
["addation_09dfaebcebe808b1"] = "为人圆滑的小丑", 
["addation_fda6f4796ee229d3"] = "从霍斯顿的早年间，干着各种见不得人的勾当，从谢菲尔德一直做到伦敦，他就一直等待着做件大事。而在十年(不算蹲牢子的时间)Payday帮经历下来，这个小丑仍将进步，而这就是他的服饰。$NL;$NL;想法提供：Angusburgers", 
["addation_68978c1a872b34a1"] = "歇斯底里的小丑", 
["addation_eb651126717af0e5"] = "如果沃尔夫做得到的话，他绝对会把这件服饰的内衬换成他家乡瑞典的羊毛。不过就DC区外加其他劫案发生地的天气来看，这样做挺不理智的。不过如果他真这么做了，他就得把这件服饰的名称改成“哪哪都痒的小丑”了。挺不酷炫的，不是吗？$NL;$NL;想法提供：Angusburgers", 
["addation_6ddf85df658a6ca5"] = "最为酷炫的小丑", 
["addation_89a3aeac4ea3b226"] = "武器专精，能砸能抢，健谈诗人，钱恩斯就是个多面手。如果说达拉斯是Payday帮的大脑的话，钱恩斯就是心脏了。穿上这套服饰来庆祝十周年吧！$NL;$NL;想法提供：Angusburgers", 

["bm_suit_classyske"] = "露骨劫匪", 
["bm_suit_classyske_desc"] = "啊，又到了这个时候，凡人们终于能穿上自己心心念念了一整年的疯狂衣服在外面逛了！但我们不一样，我们可是劫匪不是吗？我们想穿啥就穿啥，想啥时穿就啥时穿。即使是要融入节日气氛之中，也要采用最*骨感*的方式！$NL;$NL;由Luke Millanta制作。", 
["bm_suit_var_classyske_default"] = "黑到骨子", 
["bm_suit_var_classyske_default_desc"] = "啊，又到了这个时候，凡人们终于能穿上自己心心念念了一整年的疯狂衣服在外面逛了！但我们不一样，我们可是劫匪不是吗？我们想穿啥就穿啥，想啥时穿就啥时穿。即使是要融入节日气氛之中，也要采用最*骨感*的方式！$NL;$NL;由Luke Millanta制作。", 
["bm_suit_var_classyske_red"] = "骨血相容", 
["bm_suit_var_classyske_red_desc"] = "想成为成千上万人的梦魇吗？这套服饰可适合那些一天到晚和血打交道的劫匪了（如果他能避开吸血鬼和公牛的话。）$NL;$NL;由Luke Millanta制作。", 
["bm_suit_var_classyske_cream"] = "蓝包骨头", 
["bm_suit_var_classyske_cream_desc"] = "要是在万圣节之外的时间馋南瓜派的话，配着香草奶油的蓝莓派将会是不错的代替品。按照这个逻辑的话，在万圣节之外的时间穿着外白内蓝的衣服，不也能假装在过万圣节了吗。$NL;$NL;由Luke Millanta制作。", 

["bm_suit_overkillpunk"] = "议会浩劫", 
["bm_suit_overkillpunk_desc"] = "都市风格，再加上那么点的狂拽酷炫——万金油搭配。再配上合适的衬衣和领带，齐活。完美的杀戮机器。", 

["bm_suit_elegantscarf"] = "俊俏智匪", 
["bm_suit_elegantscarf_desc"] = "不要小瞧风格与才华。这套盛装将给别人留下完美的第一印象，无论你在计划什么，都会显得你无比优雅。", 

["bm_suit_lonorwa"] = "死寂之冬", 
["bm_suit_lonorwa_desc"] = "时髦又帅气，温暖又舒适。想埋伏于芬芳大雪之中？有这身，没烦恼。", 
["bm_suit_var_lonorwa_default"] = "死寂之冬(土黄)", 
["bm_suit_var_lonorwa_default_desc"] = "最经典的款式。保暖功能肉眼可见。", 
["bm_suit_var_lonorwa_white"] = "死寂之冬(雪白)", 
["bm_suit_var_lonorwa_white_desc"] = "想和雪地融为一体？该款就是为你准备的。", 
["bm_suit_var_lonorwa_orange"] = "死寂之冬(橙绿)", 
["bm_suit_var_lonorwa_orange_desc"] = "稍微显眼点也不是件坏事。", 
["bm_suit_var_lonorwa_blue"] = "死寂之冬(冰蓝)", 
["bm_suit_var_lonorwa_blue_desc"] = "亮色暗色的完美融合。", 

["bm_suit_rusbear"] = "拉橇能手", 
["bm_suit_rusbear_desc"] = "谁说非得顶着严寒在外抢劫？穿着这套去抢劫，既温暖，又靓仔。", 
["bm_suit_var_rusbear_default"] = "拉橇能手(经典)", 
["bm_suit_var_rusbear_default_desc"] = "显眼是显眼了点，不过至少血溅在上面反而不会那~~~~~么的显眼了。", 
["bm_suit_var_rusbear_quilt"] = "拉橇能手(海蓝)", 
["bm_suit_var_rusbear_quilt_desc"] = "想要出海？为何不试试这套合适的颜色？", 
["bm_suit_var_rusbear_blacmor"] = "拉橇能手(黑檀)", 
["bm_suit_var_rusbear_blacmor_desc"] = "适合夜间劫案的配色。", 
["bm_suit_var_rusbear_arctic"] = "拉橇能手(乳白)", 
["bm_suit_var_rusbear_arctic_desc"] = "在雪地中有很好的迷彩效果。", 

-- ———————— 手套
["addation_1ce0b51d907d2272"] = "手套", 
["addation_bccef85e03d2d5e4"] = "装备手套", 
["addation_80040dc86b1721b2"] = "浏览手套", 

["addation_8cd3dfce40288231"] = "默认手套", 
["addation_85b77ae2ca23dd7c"] = "使用服饰默认使用的手套", 

["addation_360db2a5c5d73a44"] = "劫匪标配", 
["addation_d2b4a8a72bef8fa9"] = "戴上手套准备偷窃。", 

["addation_0d36a245046d8d99"] = "幸运棋盘",
["addation_4063f70cb254a5ce"] = "对劫匪们来说，被客户评头论足可谓是家常便饭。戴束不妥的领带去见客户，下一秒就有可能脑袋开花。穿件成品西服参加老大女儿的婚礼，下次的高调活动可能就没你了。但像这样的手套，给人的印象既不会太好也不会太坏，只会觉得上面的花纹太过于杂乱。这也是为什么吉米钟爱这副手套，一副能为他带来好运的棋子。", 

["addation_e303191d1ffe3449"] = "幽灵劫匪", 
["addation_b9f7239ba96838db"] = "来无影，去无踪。", 

["addation_5f4b2a047ad75c57"] = "军用手套", 
["addation_469592d3934e4f78"] = "杀敌乃日常工作。", 

["addation_2302bf66bcae22e3"] = "暗影化身", 
["addation_47049d0f2737091f"] = "暗中把钱偷。", 

["addation_0ce1f69e0f23eb82"] = "大师风范", 
["addation_0a72d5252d372030"] = "没人比你更了解你的事业。", 

["addation_382cb07c0ec7dbfc"] = "黑暗劫匪", 
["addation_e382d4942815c002"] = "月黑风高夜，劫匪行动时。", 

["addation_31ffb2d257eda4ed"] = "伤痛召唤", 
["addation_0511e3baccd927c7"] = "是时候让他们尝尝苦头了。", 

["addation_5089128a2bf796cd"] = "手骨轮廓", 
["addation_584bef70c5f46aa2"] = "将你的内在套在外面。", 

["addation_fb14bf1be395b036"] = "快枪之手", 
["addation_d309527703fef721"] = "先发制人，百发百中。", 

["addation_fd6c063945a0ad8c"] = "发声号角", 
["addation_30a1f253ac5f19c5"] = "颠覆常规的勇士。", 

["addation_d347ce3e32349802"] = "鲜花之子", 
["addation_b31927cf44c175b0"] = "你入伙应该不是为了钱(确信)。", 

["addation_8d119be7a698244f"] = "蕉黄染黑", 
["addation_e888a9521b2eada4"] = "穿着这副手套骑车，把迎面而来的车辆司机吓得魂飞魄散。", 

["addation_488cbbbd6547f58f"] = "纯色硬尾", 
["addation_717d48778e4f8fb2"] = "拉斯特的机车座位底下永远备着这种手套，虽说他拿它们揍人的次数要比真正当机车手套的次数来得多。", 

["addation_57964d678f09e91f"] = "冰色硬尾", 
["addation_9e61338030d4b085"] = "比纯色的更蓝，但和纯色的一样耐操。", 

["addation_bf8cae958a4f183d"] = "火色硬尾", 
["addation_4f1e7635cfe0c6d8"] = "为了加利福尼亚的晚霞。", 

["addation_281ed7e3595d31c5"] = "霞光硬尾", 
["addation_279f455e88023389"] = "为了十月里的一次次骑行。", 

["addation_d83b0857916b3693"] = "简约黑色", 
["addation_438c8070e81cd890"] = "较为谨慎的款式适合较为低调的劫匪。", 

["addation_f517350f7165d00a"] = "告辞不谢", 
["addation_303656e3f34e4b44"] = "图奇的最爱。", 

["addation_0e27bdd76494ede7"] = "尊贵象征", 
["addation_bbda849b274de963"] = "辛妮曾经有这么一副手套，但一场劫案下来，白手套都变红了。", 

["addation_8603e53386904a24"] = "二次检查", 
["addation_130b639f45ddbe96"] = "每一位劫匪都应该防止手指受结晶损伤，不论是低温的那种还是碳化物的那种。", 

["addation_81e2a0e1b8391e7e"] = "雪上加霜", 
["addation_644774bd3b3dd616"] = "乔伊在寒冬夜晚进行骇入工作时的首选。$NL;(译注：我觉得没几个人能懂这梗，建议自己试试戴毛线手套快速敲键盘打字。)", 

["addation_d7504adb484ad72b"] = "逆风行者", 
["addation_b0e450198b186775"] = "既能用于在城市道路上疾驰，又能在你对银行柜台的窗玻璃重拳出击时保护你的关节骨。", 

["addation_10b3d07697394106"] = "战斗前线", 
["addation_c7acd2d3e9ae2e6a"] = "比华盛顿条子的制式手套质量要高。", 

["addation_7a0407ee54179891"] = "性感虎纹", 
["addation_968feaa865edb203"] = "用这副有型的手套，向世人展示你如困兽一般的团结。", 

["addation_d9a859042caaabdd"] = "霓虹都市", 
["addation_9fe8e82d3f212480"] = "这副手套拥有着90年代的呼唤。$NL;Payday帮表示：\"呼你姥姥，滚回去。\"", 

["addation_6dffc326cd8ae379"] = "无尽宇宙", 
["addation_b005e5c9eaa2595d"] = "无尽宇宙", -- ———— 不确定为啥有俩
["addation_514273bcfd75a757"] = "每一名劫匪都只是太空中的一粒星尘，漂浮在这无垠的宇宙之中。谁知道在广阔的星空中，存在有多少银行，正等着正确的人的掠夺。", 

["addation_ff0e54f54fadf71b"] = "炙手熔岩", 
["addation_c3118f028e8253f1"] = "火山永远只会带来坏事，而戴着这副手套的劫匪则会带来更坏的事——如果你刚好就在被抢的地方里工作的话。", 

["addation_c574934b7fd5cb68"] = "高地羊毛手套", 
["addation_bd916f63db34450b"] = "黑夜已至，你一边走在前往踩好点的市中心豪宅的路上，一边被冻成一坨麻花。如果没有这副好康的手套，你是绝对不会想把手放在冻得能在上面炒酸奶的枪握把上的。手艺活嘛，手当然比别的都重要！", 

["addation_df99efd18bd024f1"] = "银色战士", 
["addation_3abf2640f0c6c336"] = "潇洒的同时又不失舒适性。小心别在钻金库时把润滑剂弄上去。", 

["addation_a10cd31741aa8ad9"] = "烂花王者", -- ———— Burnout在面料里是烂花的意思，可能这里是双关
["addation_bcd10ea0b2ca5443"] = "俗话说得好，无论什么东西，只要贴上红色花纹就能大幅提升移动速度。这在80年代的追车电影里大概有效，但对抢劫就难说了。至少手套挺好看的，不是吗？", 

["addation_3d8097eaf35fc35d"] = "火疾火撩", 
["addation_c443936b83d88390"] = "如果现代的科技布料手套是上世纪50年代的产物，那么现代的赛车文化得发展得多畸形...", 

["addation_8437a99e4d04702c"] = "红龙之爪", 
["addation_03a733233ce20218"] = "戴上这副手套，想象你挥掌可以发波烧死那些条子...近战龙息？$NL;(超模了，建议移除)", 

["addation_969c6d7da68cd801"] = "黑龙之爪", 
["addation_2fdd04ac24034860"] = "要是这手套戴上会有黑气缠绕的特效的话就更牛逼了，然而OVK应该智商没高到能做出这玩意，别想了。由高科技布料制成，冬能保暖夏能降温，吸走抢劫途中劫匪紧张而产生的手汗。", 

["addation_4bcc5f808ceb4bc2"] = "70年代车手", 
["addation_9102ac79899d7fef"] = "有想象过自己是一名肌肉车统领街道，不限鬓发长度的年代的一名撤离司机吗？如果你向往着那个时代，穿着这副手套绝对能让你有那种既视感。", 

["addation_499fe1c463396bec"] = "经典手套", 
["addation_3c3a0530ccd3a818"] = "经典黑色皮革手套（超薄型）。弹力又贴身，当你打算对胆敢动你战利品的敌人扣动扳机的时候，手指保证不侧漏。", 

["bm_gloves_techhigh_bird"] = "摩托手套(加垫-朱红)", 
["bm_gloves_techhigh_bird_desc"] = "拥有极高的舒适与能动性的手套，采用了最早用于中国航天项目的电镀保护层技术。", 

["bm_gloves_techhigh_dragon"] = "摩托手套(加垫-海蓝)", 
["bm_gloves_techhigh_dragon_desc"] = "拥有极高的舒适与能动性的手套，采用了最早用于中国航天项目的电镀保护层技术。", 

["bm_gloves_techhigh_tiger"] = "摩托手套(加垫-白色)", 
["bm_gloves_techhigh_tiger_desc"] = "拥有极高的舒适与能动性的手套，采用了最早用于中国航天项目的电镀保护层技术。", 

["bm_gloves_techhigh_tortoise"] = "摩托手套(加垫-灰黑)", 
["bm_gloves_techhigh_tortoise_desc"] = "拥有极高的舒适与能动性的手套，采用了最早用于中国航天项目的电镀保护层技术。", 

["bm_gloves_techlow_bird"] = "摩托手套(传统-朱红)", 
["bm_gloves_techlow_bird_desc"] = "由现代复合面料制成，注重功能性的薄垫手套，拥有高透气性与高吸水性。", 

["bm_gloves_techlow_dragon"] = "摩托手套(传统-海蓝)", 
["bm_gloves_techlow_dragon_desc"] = "由现代复合面料制成，注重功能性的薄垫手套，拥有高透气性与高吸水性。", 

["bm_gloves_techlow_tiger"] = "摩托手套(传统-白色)", 
["bm_gloves_techlow_tiger_desc"] = "由现代复合面料制成，注重功能性的薄垫手套，拥有高透气性与高吸水性。", 

["bm_gloves_techlow_tortoise"] = "摩托手套(传统-灰黑)", 
["bm_gloves_techlow_tortoise_desc"] = "由现代复合面料制成，注重功能性的薄垫手套，拥有高透气性与高吸水性。", 

["addation_dc68a41b43151b00"] = "庆典手套", 
["addation_2bd0a59f8d2c5488"] = "这款皮革手套的缝线用的可是纯金，由八名大师级工匠联合制作。如此精致的手套就应该用来保护劫匪们精致的双手，尤其是在庆祝这八年间的积累之时。", 
["addation_90910038e12e1d12"] = "完成支线任务\"历历在握\"以解锁", 

["addation_bf09e3d4d2cd9920"] = "摩托手套(加垫-黑猴)", 
["addation_b1e8a7804d309401"] = "摩托手套(加垫-黄虎)", 
["addation_235ba7ed7a8662ff"] = "摩托手套(加垫-绿蟒)", 
["addation_7425dd82e266067e"] = "摩托手套(加垫-红螳)", 
["addation_85efac7a37a434ee"] = "实用可靠且透气性高的加垫皮革手套。", 
["addation_54ccdfc172c71157"] = "实用可靠且透气性高的加垫皮革手套。", 
["addation_f704995eafd8f05d"] = "实用可靠且透气性高的加垫皮革手套。", 
["addation_f02f25bde8e650f4"] = "实用可靠且透气性高的加垫皮革手套。", 

["bm_gloves_overkillpunk"] = "数码活塞", 
["bm_gloves_overkillpunk_desc"] = "某个嗑聪明药嗑大发的硅谷程序员的杰作。献祭别人的大脑换这么个手套，血赚。", 

-- ——————————————————————武器配色(共78条)——————————————————————————
["addation_15f772f15b223ef7"] = "自定义配色", 
["addation_4dd6adc3241b41e3"] = "自定义配色", 
["addation_3c3b7fe39cf53c8c"] = "为你的武器自定义配色", 
["addation_2412842d23971caa"] = "武器配色", 
["addation_0f7dd77145f15bea"] = "配色主题：##$variation;##", 
["addation_6b3b2ce027c684f1"] = "品质：##$quality;##", 
["addation_6641891d5370a49e"] = "购买武器配色1号DLC以解锁", 
["addation_994bf6c39a031fe1"] = "购买武器配色2号DLC以解锁", 
["addation_37bb16b2a735cf71"] = "购买武器配色3号DLC以解锁", 
["addation_45a9a290436b213f"] = "购买九风走私包DLC以解锁", 
["addation_e65b5ee9722a53a1"] = "购买九风走私包DLC以解锁", 
["addation_680d7c5d3181bb4b"] = "购买九风走私2号包DLC以解锁", 
["addation_6d9a568b337677ea"] = "武器配色1号", 
["addation_14fc176b64dd0ee4"] = "武器配色2号", 
["addation_2cb92a04676f9dee"] = "武器配色3号", 
["addation_3a4ae007c7b8c086"] = "社交媒体配色1号", 
["addation_fea8ae8b2bf26c9e"] = "九风走私包", 
["addation_a2850eebfa7fcd6e"] = "九风走私2号包", 
["addation_ae2095e4a0d6699b"] = "可通过坚守模式解锁", -- ————坚守
["addation_7bd8070e5a60ad0a"] = "可通过犯罪狂欢解锁", 
["addation_faf7969d982708b5"] = "2020年周年庆", 
["addation_c459a279a8eae3df"] = "PAYDAY蓝", 
["addation_ebb53d13cfc880b7"] = "黄褐", 
["addation_76310721ae6fa7cf"] = "深灰", 
["addation_317e6ed3c923cc96"] = "美金绿", -- ————圣马丁银行全战利品
["addation_1964d6b26fce2e20"] = "骷髅白", -- ————圣马丁守广场
["addation_44ce1eb2038583f1"] = "温和紫", -- ————坚守
["addation_918a36d2958986b4"] = "硬红", -- ————坚守
["addation_dbc679efcd04954c"] = "桃粉", -- ————坚守
["addation_8d1c21f2e1da30ab"] = "冰青", -- ————坚守
["addation_3b39897ec8f13c51"] = "黄绿", -- ————坚守
["addation_d035ee143640da25"] = "蜡笔绿", -- ————坚守
["addation_750b23d67c0d20b7"] = "群青", -- ————坚守
["addation_643a65af20a4896a"] = "暗蓝", -- ————坚守
["addation_6ac0fcf2fc758994"] = "冰川蓝", -- ————坚守
["addation_1189746d87ff6265"] = "猫咪粉", -- ————坚守
["addation_a8470de72209b7ea"] = "沙色像素", -- ————？
["addation_df1426629fa2e39e"] = "城市抽象", -- ————？

-- ———— 武器配色1号
["addation_3854cfa4e003bce2"] = "深黄", 
["addation_1e2e84c1aca9c8d4"] = "亮黄", 
["addation_0b94c0e4ebdd7dca"] = "巧克力", 
["addation_75e7cf857e45ae08"] = "沙漠黄", 
["addation_f5b2c1dc65e9334e"] = "锈红", 
["addation_0eb681b77285e24a"] = "竞技红", 
["addation_bca8a1da78e10d98"] = "深紫", 
["addation_fe431890238ea163"] = "牢狱粉", 
["addation_5309b3313f1a86bf"] = "铝热橙", 
["addation_03ea4d8ebe0dc1ab"] = "橄榄绿", 
["addation_85806f226df4f06f"] = "橄榄褐", 
["addation_1e709f67968fe130"] = "薄荷绿", 
["addation_a4c3edcc52effd9e"] = "亮绿", 
["addation_ed99de730868f997"] = "茎叶绿", 
["addation_dcc9c95ac9567f59"] = "深绿", 
["addation_6ea3e18042337b1e"] = "海军蓝", 
["addation_e42ebfd6c8d670c5"] = "钢铁蓝", 
["addation_984fbd6244e37050"] = "热带蓝", 
["addation_59e6ed4b0d06c35d"] = "庄严蓝", 
["addation_2fbdf1f8ded22b72"] = "天色灰", 
["addation_53750a9d83c0a705"] = "军队灰", 

-- ———— 武器配色2号
["addation_d684779cc44f8ace"] = "腐蚀", 
["addation_b7e696b84969f300"] = "友情", 
["addation_2b715eec849f1509"] = "奇异", 
["addation_e5ae5baf664138b3"] = "熔岩", 
["addation_2dad768353d9e7e5"] = "丛林",
["addation_f9b046755f74abff"] = "苔藓", 
["addation_b32c8e75d6bc7a8e"] = "海洋", 
["addation_1e7bad3fbdffaba8"] = "风暴", 
["addation_3c6ae6ffadc29d3a"] = "火焰", 
["addation_6740dee9e505628e"] = "岩石", 
["addation_d1a0c1c4482f8cb9"] = "炼狱", 
["addation_c185935aa52c4bdc"] = "湖蓝", 
["addation_c4ebf11183719e2c"] = "黄昏", 
["addation_6d5d87524a92036c"] = "衰减", 

["addation_1c0e58cbda68f8a0"] = "绿叶", 
["addation_d87a040f897a1f0d"] = "针叶", 
["addation_8d5aebe4fcff41dc"] = "模型", 
["addation_e218ec5406b615f1"] = "稀树",  
["addation_dba54590ce33ee43"] = "潘多拉", 
["addation_4c43a1906116e00f"] = "异国风情", 
["addation_12c5170cd43b0d1a"] = "森林", 
["addation_f9cda7bbba24a2b9"] = "深渊", 
["addation_6e2156a15f29b3f4"] = "沙漠", 
["addation_774a80f95f3e5246"] = "洞窟", 
["addation_2bb25830a221defd"] = "纳尔瓦", 
["addation_a498bd5590d445c4"] = "密码学", 

["addation_37a9b36603ec00d3"] = "昴宿星团", -- ———— 2020 周年庆
["addation_32e9873e6738f611"] = "森林行动", 
["addation_3e1e25e3ced9820a"] = "都市行动", 
["addation_e8e1c38649a06d08"] = "海上行动", 
["addation_79286faa2691704f"] = "荒漠行动", 

-- ———— 武器配色3号
["addation_a30739b38156d4d2"] = "鲜绿角度", 
["addation_35c9fcad433c169a"] = "迷幻马纹", 
["addation_391f617a1413714f"] = "鲜绿锯齿", 
["addation_901bf97d9951f96c"] = "红色网格", 
["addation_99a84632c5dafe2a"] = "红色蛛网", 
["addation_d8be3cfb2be4c10b"] = "粉色光棚", 
["addation_1d8a38add67ebe73"] = "桃色光棚", 
["addation_606c6025e5c7b665"] = "紫外光棚", 
["addation_02c652f3d82cb898"] = "骨色光棚", 
["addation_a3b9dfb350709e9f"] = "绯红光棚", 
["addation_4847b592e9f7cd7d"] = "红褐光棚", 
["addation_ac4e0afb00eb0b39"] = "茄色光棚", 
["addation_c5f980f73b74c45e"] = "天蓝光棚", 
["addation_f9aef98ac413c65f"] = "转换变色 B型", 
["addation_602b28d71449f3b9"] = "转换变色 A型", 
["addation_f2d5fb9abcf096ff"] = "蓝绿变色", 
["addation_545567bb67a602da"] = "鲜红变色", 
["addation_49333edea9016db2"] = "黄金变色", 
["addation_04c794e40bb4cd20"] = "鲜蓝变色", 
["addation_06be292d8b828cd2"] = "鲜绿变色", 

-- ———— 恶名转生
["addation_3ce00388b9249d24"] = "血色落日", 
["addation_10880cb97f3e1db6"] = "雨林", 
["addation_0a2d1d872e00c6dc"] = "幽灵红色迷彩", 
["addation_44fc86a3950e353c"] = "紫烟", 
["addation_52f27d099f780a3e"] = "抽象红色", 
["addation_ab5ef7978ba45612"] = "抽象绿色", 
["addation_6fd67477df0e181e"] = "重度锈蚀", 
["addation_a4a34aee67c90c6b"] = "钢铁锈蚀", 
["addation_a6553844b11c02e7"] = "未经加工",
["addation_6ca0da294d8a53a2"] = "静电锈蚀", 
["addation_b5668087225534f6"] = "灰焰", 
["addation_713db5cb856aaeb2"] = "复古爬虫", 
["addation_5316a45c9806c403"] = "蓝铁", 
["addation_17bc2e51eb703b6a"] = "零墨水", 
["addation_29e4fb7f8f43981d"] = "抽象白色", 
["addation_cba9e7aed68171ac"] = "抽象黑色", 

-- ———— 九风走私包
["addation_4e597df1c0635ed6"] = "死亡玫瑰", 
["addation_202bf87cb7a74eb2"] = "花格朋克", 
["addation_950372bbd8a8c40a"] = "黄金滚滚来", 
["addation_3bd35919a589db1f"] = "奇心怪状", 
["addation_d04d04d64cb61bc0"] = "心灵样式Alpha", 
["addation_2c76079a169acb72"] = "心灵样式Beta", 
["addation_72c2c13643fd112b"] = "死尸骸骨", 
["addation_ff6c7eb392745417"] = "红色锦鲤", 
["addation_3b6c6040776e93f0"] = "杂乱宝钻", 
["addation_53c485c269b60e46"] = "圈圈叉叉", 
["addation_630ed42aff67e218"] = "残留指印", 
["addation_6b3168aeaa12af8b"] = "地势图纹", 
["addation_3d6ca767f6419827"] = "黑色幽默", 
["addation_fefbb271ea8892f8"] = "十字匕首", 
["addation_5af4faedd31ab5a7"] = "红色鲤鳞", 
["addation_442d6990b9b17504"] = "荧光扑克", 
["addation_7a3c2f268457db13"] = "海洋之花", 
["addation_24eb04613baa2349"] = "冰片镶嵌", 
["addation_914a794b82181c89"] = "叶片墙纸", 
["addation_dea1125f12bb4eef"] = "1983", 

-- ———— 转生3.1
["addation_9cd2ea274139d140"] = "不朽巨蟒", 
["addation_d6f9c7f3411b49fe"] = "金色大理石碎", 
["addation_aa5e10a5c6df271c"] = "线路装饰", 
["addation_d6d20004db1dacaa"] = "黄金与群兽", 
["addation_d6da0f2f1a60e995"] = "墨蓝配金", 
["addation_95cf1f9ad8dae244"] = "金缮修补", 
["addation_d8fcfae50bbf0da7"] = "抽象灰纹", 
["addation_d495b9b07ee0292c"] = "黑色&皇冠", 
["addation_74fe56309f0f27e9"] = "斜性炭", 

-- ———— 附凤扳龙免费配色
["addation_1f276f9eaefd502d"] = "绯红金花", 

-- ———— 恶名3.2
["addation_81073e495da612e7"] = "典雅金底", 
["addation_7cbbe0121368920d"] = "粉底映花", 
["addation_d5103faa10c2234d"] = "羽状印花", 
["addation_ef7cdd8b1fc953c7"] = "灰粉珍珠", 
["addation_0b1061996365a2fc"] = "白金相间", 
["addation_e948f486019505f8"] = "镀金枪身", 
["addation_c7b1ff9620338106"] = "迷幻壁纸", 
["addation_ea143172b1f0bdaf"] = "皇家壁纸", 
["addation_39196a2c6ecc4b7f"] = "维多利亚壁纸", 

-- ———— 九风走私包2
["addation_97bcdb404d4d3479"] = "青花瓷器", 
["addation_6b71b4db7e58edb7"] = "金玉其外", 
["addation_4b41dab6bfa47085"] = "点点梅花", 
["addation_4724de0a4fca6c5f"] = "飞龙在天", 
["addation_fd0dc50d53ed09a2"] = "墨竹印记", 
["addation_92945c65f3c48567"] = "折纸艺术", 
["addation_2b2183c5bb682b30"] = "穿云之鸟", -- ———— 存疑，我实在看不出这花纹画了个什么几把
["addation_0860759aec658b80"] = "孔雀开屏", 
["addation_e4c56450dfca068b"] = "青花鲤鳞", 
["addation_c971ba3a58bacd7d"] = "成方成圆", 

-- ———— 九风走私包3
["bm_wskn_color_tawp_01"] = "掠夺野性", 
["bm_wskn_color_tawp_02"] = "蓝纹金字", 
["bm_wskn_color_tawp_03"] = "竹节迷路", 
["bm_wskn_color_tawp_04"] = "粉云飞虎", 

-- ———— 恶名3.3
["bm_wskn_color_in33_01"] = "锈迹斑斑", 
["bm_wskn_color_in33_02"] = "页岩样式", 
["bm_wskn_color_in33_03"] = "晶体汇聚", 
["bm_wskn_color_in33_04"] = "线性相位", 
["bm_wskn_color_in33_05"] = "色彩渐入", 

-- ———— 星风账号
["bm_wskn_color_sbzac2_01"] = "频率", 

-- ———— 冬日幽灵
["bm_wskn_color_snow_01"] = "女神圣光", 
["bm_wskn_color_snow_02"] = "结瘤相拥", 
["bm_wskn_color_snow_03"] = "冰临前线", 
["bm_wskn_color_snow_04"] = "莓红点影", 

-- ——————————————————————放置物(共35条)——————————————————————
["bm_equipment_ammo_bag"] = "弹药包",
["bm_equipment_ammo_bag_desc"] = "按住$BTN_USE_ITEM;来放置弹药包。$NL;弹药包一旦放置就不能被移动，但你和你队友可以通过对弹药包进行交互(按住$BTN_INTERACT;)来补充弹药。$NL;弹药包默认可提供共400%的总弹药，一旦用完就会消失。$NL;你可以通过观察弹药包来判断还剩多少弹药。$NL;弹药包是一个便携挎包，原本设计用来让士兵携带额外的弹药。",
["bm_equipment_armor_kit"] = "护甲包",
["bm_equipment_armor_kit_desc"] = "按住$BTN_USE_ITEM;使用护甲包穿戴护甲。$NL;在护甲包被使用使用之前，你都将穿着两件套西服。$NL;护甲包只能使用一次，使用后你的护甲将被替换为你装备栏中所设置的护甲，且用过就会消失。$NL;护甲包是一个便携的挎包，可以用来携带你选择的用于劫案当中的的护甲。",
["bm_equipment_bodybags_bag"] = "尸体袋箱",
["bm_equipment_bodybags_bag_desc"] = "按住$BTN_USE_ITEM;来放置尸体袋箱。$NL;尸体袋箱一旦放置就不能被移动，但你和你队友可以通过对尸体袋箱进行交互(按住$BTN_INTERACT;)来获取尸体袋。$NL;尸体袋盒的使用次数有限，一旦用完就会消失。$NL;你可以通过观察尸体袋盒来判断还有多少个尸体袋。$NL;尸体袋箱是一个装有尸体袋的手提箱，用与在潜入中打包尸体。",
["bm_equipment_doctor_bag"] = "医疗包",
["bm_equipment_doctor_bag_desc"] = "按住$BTN_USE_ITEM;来放置医疗包。$NL;医疗包一旦放置就不能被移动，但你和你队友可以通过对医疗包进行交互(按住$BTN_INTERACT;)来回复血量并重置倒地次数。$NL;医疗包的使用次数有限，一旦用完就会消失。$NL;你可以通过观察医疗包来判断还剩多少使用次数。$NL;医疗包是一个便携挎包，通常被外科医生和医疗专家用来携带医疗物品和药品。",
["bm_equipment_ecm_jammer"] = "ECM干扰器",
["bm_equipment_ecm_jammer_desc"] = "按住$BTN_USE_ITEM;来放置ECM。$NL;ECM一旦放置就不能被移动，它会即时运作20秒，在此期间一切电子设备（手机、摄像头）都将失效。$NL;你可以通过对ECM进行交互(按下$BTN_INTERACT;)来开启ECM的反馈功能，在8秒内使在ECM一定范围内的敌人暂时失去战斗能力，之后便会停止工作，进入4分钟的反馈冷却。$NL;电子干扰器(ECM)是一个用来欺骗雷达，声纳和其他探测系统的电子设备，它某种程度上能助你完成劫案。",
["bm_equipment_first_aid_kit"] = "急救包",
["bm_equipment_first_aid_kit_desc"] = "按住$BTN_USE_ITEM;来放置急救包。$NL;急救包一旦放置就不能被移动，但你和你队友可以通过对急救包进行交互(按住$BTN_INTERACT;)来回复血量。$NL;急救包只能使用一次，一旦用完就会消失。$NL;急救包是用来提供急救的散装携件。",
["bm_equipment_sentry_gun"] = "炮台",
["bm_equipment_sentry_gun_desc"] = "按住$BTN_USE_ITEM;来放置炮台，放置炮台将消耗你所持有武器总弹量的30%。$NL;炮台可以被射毁，但只要它还未被完全摧毁，你仍可以拾取它，这将自动修复炮台，并返还剩余弹药。$NL;一旦炮台的子弹用尽，它就会停止射击，但你仍可以通过捡起并重新放置来为其补充弹药。$NL;炮台能够自动感应的目标并向其开火，它被广泛用于为团队吸引火力。",
["addation_da18b3d9fd3cffe9"] = "消音炮台", 
["addation_3a9820c4c08c2558"] = "按住$BTN_USE_ITEM;来放置消音炮台，放置炮台将消耗你所持有武器总弹量的30%。$NL;炮台可以被射毁，但只要它还未被完全摧毁，你仍可以拾取它，这将自动修复炮台，并返还剩余弹药。$NL;一旦炮台的子弹用尽，它就会停止射击，但你仍可以通过捡起并重新放置来为其补充弹药。$NL;消音炮台相对于普通的、更响的炮台攻击敌人的同时不容易被当作目标。", 
["bm_equipment_trip_mine"] = "绊雷与塑性炸药",
["bm_equipment_trip_mine_desc"] = "按住$BTN_USE_ITEM;来放置绊雷。$NL;你可以通过对绊雷进行交互(按下$BTN_INTERACT;)来切换它的爆炸和探测模式。$NL;对可放置塑性炸药的地方进行交互将放置塑性炸药，它将在几秒钟后爆炸并摧毁接触的物体。$NL;绊雷可以伤害到经过它的人，而塑性炸药则被广泛用于破门与炸开保险箱，两者都适合在战斗中使用。",

-- ——————————————————————投掷物(共38条)——————————————————————
["bm_grenade_dada_com"] = "俄罗斯套娃手雷",
["bm_grenade_dada_com_desc"] = "俄罗斯套娃手雷是一件投掷类爆炸装置。其玩具般的外表隐藏了其内心的蠢蠢欲动。在向祖国致敬的同时，它也能对敌人造成重大伤害。",
["addation_427c01196fc4a201"] = "白磷弹", 
["addation_f63714d64ff17751"] = "内部填充满白磷的肮脏武器，在拉开拉环后的几秒内会自燃爆炸。使用方法很简单，丢向敌人群内，把他们都烧到发焦。", 
["addation_aa618daf51df52c3"] = "HEF手雷", 
["addation_7e31e3c603be7e24"] = "经典手雷的升级版。尽管原始的手雷依然被使用，但这个新款手雷每次都能提供超量伤害，且依旧便宜又好用。", 
["bm_wpn_prj_ace"] = "黑桃A",
["bm_wpn_prj_ace_desc"] = "虽说纸牌一般只有魔术师在表演切西瓜时才会拿来丢来丢去，但只要增加质量以及利刃边后，你就拥有了一个无声杀器。在袖间藏匿这些铁质王牌，永远准备将全身心投入这暗杀游戏之中。$NL;$NL;黑桃A是为庆祝PAYDAY2两周年的免费社区礼物！",
["addation_9ae049802e5791cb"] = "震撼弹", 
["addation_3b6196f4a7524706"] = "这个晕人的小美人会令所有人窒息，给你额外的时间杀死他们。", 
["bm_grenade_frag"] = "破片手雷",
["bm_grenade_frag_desc"] = "破片手雷相比它的原型已有些许改进。它是一个会爆炸的投掷物，利用巨大的冲击波将破片向四处发射，对肉体、骨头和轻型护甲造成损伤。廉价而实用。",
["bm_grenade_molotov"] = "燃烧瓶",
["bm_grenade_molotov_desc"] = "莫洛托夫鸡尾酒可能是能够叫手雷的武器中最简易的一款了。仅由一个易碎的酒瓶，可燃的液体和烧布\"引线\"组成，简易而高效。",
["bm_dynamite"] = "炸药",
["bm_dynamite_desc"] = "瑞典工程师阿尔弗雷德·诺贝尔，发现了炸药和它高效的矿石爆破能力。而喝得稀烂的探矿者老肯尼思，发现了它高效的炸人能力。",
["bm_wpn_prj_four"] = "手里剑",
["bm_wpn_prj_four_desc"] = "如同隐藏在手中的剑，手里剑是种完美无声且致命的武器。它最早是由钉子和针制作而成，这颗可投掷的星星饱含了充满血和火的悠久历史。只要你能抢在敌人之前先发制人，那么这些现代的不锈钢星星会对出现在你面前的任何敌人造成致命威胁。$NL;$NL;淬满了毒药的手里剑会对敌人造成持续伤害，并有几率能够打断敌人的攻击。",
["bm_wpn_prj_jav"] = "标枪",
["bm_wpn_prj_jav_desc"] = "标枪作为一把简易的武器，它的起源已经遗失在历史洪流之中。毕竟它只是个一端尖头可投掷的木棍，随时可以结束某人的余生。尽管它如此简单，依然需要技巧和力量才能使用。",
["addation_4b9e3f125ad37c59"] = "飞刀", 
["addation_98cc42c6da2816cc"] = "暗杀绝佳的战术选择。当人们厌倦了只是向个大概的方向丢些杂七杂八的东西来杀人并且想要一些可靠的武器时候，飞刀就这么出现在了军事历史中。", 
["addation_904a72112498ae36"] = "飞斧", 
["addation_d96e979cd4aca603"] = "在飞车党之中十分流行的装备。斧锋利点永远不会错，特别是当它被拿来丢的时候。当你骑着机车还唱着歌，突然就被敌对帮派给劫了，这时候你就需要些\"防御手段\"。飞车党们发觉在公路战时手滑扔出飞斧意外好用。", 
["addation_4c5944ac25a1eeb4"] = "斯多葛的酒壶", 
["addation_a242166998d40b7f"] = "杜克年轻时，和其一同修行的僧侣赠与他的一瓶1882年的古董酒壶，瓶上刻有\"斯多葛\"和\"JW精神\"。杜克将他钟爱的威士忌装满酒壶，痛饮一口调整内息，冥想禅意，缓解伤痛。", 
["addation_9bd03b0d2d961095"] = "便携式ECM", 
["addation_3095573a8c008253"] = "用来拦截和覆盖附近加密信号的小装置。通过能够检测和扰乱无线信号的精密算法，便携式ECM给了使用者机会，得以行走在激进和低调这两个极端之间。", 
["addation_17737d275b49e13b"] = "烟雾弹", 
["addation_739b3f9c06efb0ea"] = "在战火中丢出烟雾弹让你遁入无形，不管敌人有多想要击中你也是事倍功半。",
["addation_3aded760a7e4ed4a"] = "嗨气瓶", 
["addation_ac9ebdc8555a25a9"] = "一个电子烟瓶，能加强你和你的一名队友之间的感知力，并提供临时的治疗效果。", 
["addation_cb9b5c8318f67846"] = "注射器", 
["addation_93f26b122417e1e5"] = "使用者将不惧疼痛且变得无所畏惧。不惧疼痛能使使用者的战斗之魂时刻燃起，无所畏惧则使使用者成为敌人面前的极大威胁。", 
["addation_5aeca3677c9f5a1b"] = "X1-ZAPper电磁手雷", 
["addation_21de32b53d84d7e3"] = "手雷破片虽然靠谱，但对某些东西你必须得来点“刺激”的。这个强劲的小宝贝可适合用高电压给敌人点个外焦里嫩了。", 
["addation_c4b60dd6e96835ab"] = "完成成就\"震我一下\"$NL;或购买九风走私2号包解锁", -- ———— 解锁条件
["bm_grenade_copr_ability"] = "水蛭精华", 
["bm_grenade_copr_ability_desc"] = "要想获得水蛭效果，就打破这安瓿瓶，再放鼻子前猛吸一口。虽说不知道里面具体装了啥，但它的确能让你变得专注，肾上腺素飙升，跟打了鸡血一样。至少我们能确定一件事：这玩意铁定不是嗅盐。", 
["bm_grenade_xmas_snowball"] = "雪球", 
["bm_grenade_xmas_snowball_desc"] = "冬日撒人没烦恼，今天就做老霍秘制小雪球。$NL;既实惠(指280范围伤害)，害管饱儿(指雪球会自动回复)。$NL;雪球，沾水，丢冰箱。你看这雪球儿做地行不行。$NL;奥利给兄弟盟丢它就完了！", 

["bm_menu_preferred"] = "已选定",
["bm_menu_primaries"] = "主武器",
["bm_menu_secondaries"] = "副武器",

["bm_armor_chainmail"] = "Chainmail",
["bm_armor_kevlar"] = "Kevlar",
["bm_armor_leather"] = "Leather",
["bm_armor_scale"] = "Scale",
["bm_c_jacket1"] = "Jacket 1",
["bm_c_jacket2"] = "Jacket 2",
["bm_c_jacket3"] = "Jacket 3",
["bm_c_jacket4"] = "Jacket 4",
["bm_c_trousers1"] = "Trousers 1",
["bm_c_trousers2"] = "Trousers 2",
["bm_c_trousers3"] = "Trousers 3",
["bm_c_trousers4"] = "Trousers 4",
["bm_clr_black_bright_yellow"] = "黑色/亮黄色",
["bm_clr_black_cobalt_blue"] = "黑色/钴蓝色",
["bm_clr_black_coral_red"] = "黑色/珊瑚红色",
["bm_clr_black_grey"] = "黑色/灰色",
["bm_clr_black_leaf_green"] = "黑色/草绿色",
["bm_clr_black_magenta"] = "黑色/品红色",
["bm_clr_black_orange"] = "黑色/橙色",
["bm_clr_black_solid"] = "纯黑色",
["bm_clr_black_white"] = "黑色/白色",
["bm_clr_blood_red"] = "纯血红色",
["bm_clr_blood_red_solid"] = "纯血红色",
["bm_clr_blood_red_white"] = "血红色/白色",
["bm_clr_blue_black"] = "蓝色/黑色",
["bm_clr_blue_grey"] = "蓝色/灰色",
["bm_clr_blue_light_blue"] = "蓝色/浅蓝色",
["bm_clr_blue_solid"] = "纯蓝色",
["bm_clr_blue_white"] = "蓝色/白色",
["bm_clr_bone_white_light_blue"] = "米白色/浅蓝色",
["bm_clr_bone_white_magenta"] = "米白色/品红色",
["bm_clr_bone_white_navy_blue"] = "米白色/海蓝色",
["bm_clr_bone_white_purple"] = "米白色/紫色",
["bm_clr_bright_yellow_brown"] = "亮黄色/棕色",
["bm_clr_bright_yellow_dark_gray"] = "亮黄色/深灰色",
["bm_clr_bright_yellow_olive_green"] = "亮黄色/橄榄绿色",
["bm_clr_bright_yellow_turquoise"] = "亮黄色/青绿色",
["bm_clr_brown_black"] = "棕色/黑色",
["bm_clr_brown_solid"] = "纯棕色",
["bm_clr_cobalt_blue_navy_blue"] = "钴蓝色/海蓝色",
["bm_clr_cobalt_blue_pink"] = "钴蓝色/粉红色",
["bm_clr_cobalt_blue_white"] = "钴蓝色/白色",
["bm_clr_coral_red_dark_red"] = "珊瑚红色/深红色",
["bm_clr_coral_red_gray_blue"] = "珊瑚红色/青灰色",
["bm_clr_coral_red_lime_green"] = "珊瑚红色/绿黄色",
["bm_clr_coral_red_matte_blue"] = "珊瑚红色/嫩蓝色",
["bm_clr_cyan_blue"] = "青色/蓝色",
["bm_clr_cyan_orange"] = "青色/橙色",
["bm_clr_cyan_purple"] = "青色/紫色",
["bm_clr_cyan_solid"] = "纯青色",
["bm_clr_dark_blue_solid"] = "纯深蓝色",
["bm_clr_dark_gray_orange"] = "深灰色/橙色",
["bm_clr_dark_gray_solid"] = "纯深灰色",
["bm_clr_dark_green_solid"] = "纯深绿色",
["bm_clr_dark_red_orange"] = "深红色/橙色",
["bm_clr_dark_red_solid"] = "纯深红色",
["bm_clr_gray_black"] = "灰色/黑色",
["bm_clr_gray_solid"] = "纯灰色",
["bm_clr_green_black"] = "绿色/黑色",
["bm_clr_green_blood_red"] = "绿色/血红色",
["bm_clr_green_brown"] = "绿色/棕色",
["bm_clr_green_olive_green"] = "绿色/橄榄绿色",
["bm_clr_green_red"] = "绿色/红色",
["bm_clr_green_solid"] = "纯绿色",
["bm_clr_grey_green"] = "灰色/绿色",
["bm_clr_grey_red"] = "灰色/红色",
["bm_clr_leaf_green_blood_red"] = "草绿色/血红色",
["bm_clr_leaf_green_solid"] = "纯草绿色",
["bm_clr_leaf_green_white"] = "草绿色/白色",
["bm_clr_light_blue_brown"] = "浅蓝色/棕色",
["bm_clr_light_blue_cobalt_blue"] = "浅蓝色/钴蓝色",
["bm_clr_light_blue_gray_blue"] = "浅蓝色/青灰色",
["bm_clr_light_blue_solid"] = "纯浅蓝色",
["bm_clr_light_brown_brown"] = "浅棕色/棕色",
["bm_clr_light_brown_matte_blue"] = "浅棕色/嫩蓝色",
["bm_clr_light_brown_navy_blue"] = "浅棕色/海蓝色",
["bm_clr_light_brown_solid"] = "纯浅棕色",
["bm_clr_light_gray_blood_red"] = "浅灰色/血红色",
["bm_clr_light_gray_dark_gray"] = "浅灰色/深灰色",
["bm_clr_light_gray_solid"] = "纯浅灰色",
["bm_clr_light_green_solid"] = "纯浅绿色",
["bm_clr_light_grey_solid"] = "纯灰色",
["bm_clr_light_orange_solid"] = "纯浅橙色",
["bm_clr_light_purple_solid"] = "纯浅紫色",
["bm_clr_light_red_solid"] = "纯浅红色",
["bm_clr_light_yellow_solid"] = "纯浅黄色",
["bm_clr_lime_solid"] = "纯绿黄色",
["bm_clr_magenta_cyan"] = "品红色/青色",
["bm_clr_magenta_solid"] = "纯品红色",
["bm_clr_navy_blue_light_blue"] = "海蓝色/浅蓝色",
["bm_clr_navy_blue_solid"] = "纯海蓝色",
["bm_clr_no_color"] = "无色",
["bm_clr_nothing"] = "没有",
["bm_clr_orange_blue"] = "橙色/蓝色",
["bm_clr_orange_gray_blue"] = "橙色/青灰色",
["bm_clr_orange_matte_blue"] = "橙色/嫩蓝色",
["bm_clr_orange_purple"] = "橙色/紫色",
["bm_clr_orange_red"] = "橙色/红色",
["bm_clr_orange_solid"] = "纯橙色",
["bm_clr_orange_white"] = "橙色/白色",
["bm_clr_pink_matte_purple"] = "粉红色/嫩紫色",
["bm_clr_pink_solid"] = "纯粉红色",
["bm_clr_purple_solid"] = "纯紫色",
["bm_clr_red_black"] = "红色/黑色",
["bm_clr_red_blue"] = "红色/蓝色",
["bm_clr_red_dark_red"] = "红色/深红色",
["bm_clr_red_solid"] = "纯红色",
["bm_clr_red_white"] = "红色/白色",
["bm_clr_toxic_green_dark_green"] = "生化绿色/深绿色",
["bm_clr_toxic_green_leaf_green"] = "生化绿色/草绿色",
["bm_clr_toxic_green_matte_purple"] = "生化绿色/嫩紫色",
["bm_clr_turquoise_pink"] = "青绿色/粉红色",
["bm_clr_turquoise_purple"] = "青绿色/紫色",
["bm_clr_violet_solid"] = "纯紫罗兰色",
["bm_clr_warm_yellow_bright_yellow"] = "暖黄色/亮黄色",
["bm_clr_warm_yellow_matte_purple"] = "暖黄色/嫩紫色",
["bm_clr_warm_yellow_navy_blue"] = "暖黄色/海蓝色",
["bm_clr_warm_yellow_olive_green"] = "暖黄色/橄榄绿色",
["bm_clr_warm_yellow_solid"] = "纯暖黄色",
["bm_clr_warm_yellow_white"] = "暖黄色/白色",
["bm_clr_white_black"] = "白色/黑色",
["bm_clr_white_brown"] = "白色/棕色",
["bm_clr_white_dark_gray"] = "白色/深灰色",
["bm_clr_white_magenta"] = "白色/品红色",
["bm_clr_white_matte_blue"] = "白色/嫩蓝色",
["bm_clr_white_navy_blue"] = "白色/海蓝色",
["bm_clr_white_orange"] = "白色/橙色",
["bm_clr_white_purple"] = "白色/紫色",
["bm_clr_white_solid"] = "纯白色",
["bm_clr_white_yellow"] = "白色/黄色",
["bm_clr_yellow_black"] = "黄色/黑色",
["bm_clr_yellow_blue"] = "黄色/蓝色",
["bm_clr_yellow_orange"] = "黄色/橙色",
["bm_clr_yellow_solid"] = "纯黄色",
["bm_clr_yellow_white"] = "黄色/白色",
["bm_cop_kawaii"] = "超凡萌萌哒",
["bm_cop_kawaii_desc"] = "In the name of the kawaii, I will punish you！ For love, for justice, FOR MERCURY BUBBLE BLAST！$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！",
["bm_cop_mega_skull"] = "超凡死亡之愿",
["bm_cop_mega_skull_desc"] = "We\"ve never understood why hardcore heisters don\"t call themselves Death Wishers. Maybe it\"s just too damn cool.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！",
["bm_cop_plague_doctor"] = "超凡瘟疫医生",
["bm_cop_plague_doctor_desc"] = "The years of healing took its toll. He witnessed man\"s cruel ways, born out of desperation. He stopped seeing the plague as a disease and started spreading it as the cure.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！",
["bm_global_value_akm4_pack"] = "屠夫 AK/CAR 模组包",
["bm_global_value_akm4_pack_unlock"] = "购买屠夫 AK/CAR 模组包以解锁",
["bm_global_value_alienware_alpha"] = "外星人Alpha主机",
["bm_global_value_alienware_alpha_promo"] = "外星人Alpha主机",
["bm_global_value_alienware_alpha_promo_unlock"] = "需要 PAYDAY 2: Alienware Alpha Mauler Pack 以解锁！",
["bm_global_value_alienware_alpha_unlock"] = "需要 PAYDAY 2: Alienware Alpha Mask Pack 以解锁！",
["bm_global_value_arena"] = "Alesso劫案DLC",
["bm_global_value_arena_unlock"] = "购买Alesso劫案DLC以解锁！",
["bm_global_value_armored_transport"] = "武装押运",
["bm_global_value_armored_transport_unlock"] = "购买武装押运DLC以解锁！",
["bm_global_value_bbq"] = "BBQ武器包",
["bm_global_value_bbq_unlock"] = "购买BBQ武器包DLC以解锁！",
["bm_global_value_berry"] = "极盗者劫案DLC",
["bm_global_value_berry_unlock"] = "购买极盗者劫案DLC以解锁",
["bm_global_value_big_bank_snp"] = "大银行",
["bm_global_value_big_bank_snp_unlock"] = "购买大银行DLC以解锁！",
["bm_global_value_bobblehead_unlock"] = "购买吉祥小熊以解锁！",
["bm_global_value_butch_pack_free"] = "屠夫模组包",
["bm_global_value_character_pack_clover"] = "克洛芙角色包",
["bm_global_value_character_pack_clover_unlock"] = "购买克洛芙角色包DLC 以解锁！",
["bm_global_value_character_pack_dragan"] = "德拉冈角色包",
["bm_global_value_character_pack_dragan_unlock"] = "购买德拉冈角色包DLC以解锁！",
["bm_global_value_character_pack_sokol"] = "索科尔角色包",
["bm_global_value_character_pack_sokol_unlock"] = "购买索科尔角色包DLC以解锁！",
["bm_global_value_coco"] = "吉米角色包",
["bm_global_value_coco_unlock"] = "购买吉米角色包DLC以解锁",
["bm_global_value_collaboration"] = "联动",
["bm_global_value_complete_overkill_pack"] = "狂杀完整包",
["bm_global_value_complete_overkill_pack_unlock"] = "购买狂杀完整包DLC以解锁",
["bm_global_value_dbd_clan"] = "Dead by Daylight 社区",
["bm_global_value_dbd_clan_unlock"] = "加入Steam上的 Dead by Daylight官方社区组以解锁！",
["bm_global_value_dragon"] = "极道角色包",
["bm_global_value_dragon_unlock"] = "购买极道角色包DLC以解锁！",
["bm_global_value_e3_s15a"] = "E3 2015 神秘面具 #01",
["bm_global_value_e3_s15a_unlock"] = "需要PAYDAY 2: E3 2015 神秘面具 #01 以解锁！",
["bm_global_value_e3_s15b"] = "E3 2015 神秘面具 #02",
["bm_global_value_e3_s15b_unlock"] = "需要PAYDAY 2: E3 2015 神秘面具 #02 以解锁！",
["bm_global_value_e3_s15c"] = "E3 2015 神秘面具 #03",
["bm_global_value_e3_s15c_unlock"] = "需要PAYDAY 2: E3 2015 神秘面具 #03 以解锁！",
["bm_global_value_e3_s15d"] = "E3 2015 神秘面具 #04",
["bm_global_value_e3_s15d_unlock"] = "需要PAYDAY 2: E3 2015 神秘面具 #04 以解锁！",
["bm_global_value_exceptional"] = "优秀",
["bm_global_value_gage_pack"] = "盖奇武器包 #01",
["bm_global_value_gage_pack_assault"] = "盖奇突击包",
["bm_global_value_gage_pack_assault_unlock"] = "购买盖奇突击包DLC以解锁！",
["bm_global_value_gage_pack_historical"] = "盖奇历史包",
["bm_global_value_gage_pack_historical_unlock"] = "购买盖奇历史包DLC以解锁！",
["bm_global_value_gage_pack_jobs"] = "盖奇模组包",
["bm_global_value_gage_pack_jobs_unlock"] = "需要盖奇模组包DLC来继续！",
["bm_global_value_gage_pack_lmg"] = "盖奇武器包#02",
["bm_global_value_gage_pack_lmg_unlock"] = "买盖奇武器包#02以解锁DLC！",
["bm_global_value_gage_pack_shotgun"] = "盖奇猎枪包",
["bm_global_value_gage_pack_shotgun_unlock"] = "买盖奇猎枪包以解锁DLC！",
["bm_global_value_gage_pack_snp"] = "盖奇狙击手包",
["bm_global_value_gage_pack_snp_unlock"] = "买盖奇狙击手包以解锁DLC！",
["bm_global_value_gage_pack_unlock"] = "买盖奇武器包#01以解锁DLC！",
["bm_global_value_goty_dlc_bundle_2014"] = "年度版",
["bm_global_value_goty_dlc_bundle_2014_unlock"] = "购买所有年度DLC以解锁！",
["bm_global_value_goty_heist_bundle_2014"] = "劫案合集DLC",
["bm_global_value_goty_heist_bundle_2014_unlock"] = "购买所有年度DLC以解锁！",
["bm_global_value_goty_weapon_bundle_2014"] = "武器合集DLC",
["bm_global_value_goty_weapon_bundle_2014_unlock"] = "购买所有盖奇武器包DLC以解锁！",
["bm_global_value_halloween"] = "万圣节",
["bm_global_value_hl_miami"] = "迈阿密热线 DLC",
["bm_global_value_hl_miami_unlock"] = "购买迈阿密热线DLC以解锁！",
["bm_global_value_hlm2"] = "迈阿密热线2",
["bm_global_value_hlm2_deluxe"] = "迈阿密热线2豪华版",
["bm_global_value_hlm2_deluxe_unlock"] = "拥有Steam上的迈阿密热线2: 错误号码———数字特别版以解锁",
["bm_global_value_hlm2_unlock"] = "拥有steam上迈阿密热线2 游戏以解锁",
["bm_global_value_hlm_game"] = "迈阿密热线",
["bm_global_value_hlm_game_unlock"] = "拥有steam上的迈阿密热线着游戏以解锁！",
["bm_global_value_hope_diamond"] = "钻石大劫案",
["bm_global_value_hope_diamond_unlock"] = "购买钻石大劫案DLC以解锁！",
["bm_global_value_humble_pack2"] = "Humble面具包2",
["bm_global_value_humble_pack2_unlock"] = "需要PAYDAY 2: Humble面具包2以解锁！",
["bm_global_value_humble_pack3"] = "Humble  3号面具包",
["bm_global_value_humble_pack3_unlock"] = "需要PAYDAY 2: Humble 3号面具包 以解锁！",
["bm_global_value_humble_pack4"] = "Humble 4号面具包",
["bm_global_value_humble_pack4_unlock"] = "需要PAYDAY 2: Humble 4号面具包 以解锁！",
["bm_global_value_infamous"] = "恶名",
["bm_global_value_kenaz"] = "金牙大赌场",
["bm_global_value_kenaz_unlock"] = "购买金牙大赌场DLC以解锁！",
["bm_global_value_legendary"] = "传奇",
["bm_global_value_normal"] = "普通",
["bm_global_value_overkill_pack"] = "狂杀包",
["bm_global_value_overkill_pack_unlock"] = "购买DLC以解锁",
["bm_global_value_pal"] = "沃尔夫包",
["bm_global_value_pal_unlock"] = "购买沃尔夫包DLC以解锁",
["bm_global_value_pd2_clan"] = "社区",
["bm_global_value_pd2_clan_unlock"] = "加入PAYDAY 2 steam官方社区以解锁！",
["bm_global_value_pdcon_2015"] = "PAYDAYCON 2015 神秘面具",
["bm_global_value_pdcon_2015_unlock"] = "需要 PAYDAY 2: PAYDAYCON 2015 神秘面具以解锁！",
["bm_global_value_peta"] = "模拟山羊劫案 DLC",
["bm_global_value_peta_unlock"] = "购买模拟山羊 DLC 以解锁",
["bm_global_value_poetry_soundtrack"] = "Poetry Jam",
["bm_global_value_poetry_soundtrack_unlock"] = "购买 PAYDAY 2: 原声专辑用以解锁！",
["bm_global_value_preorder"] = "战利品包",
["bm_global_value_speedrunners"] = "急速奔跑者",
["bm_global_value_speedrunners_unlock"] = "拥有Steam上的Speedrunners游戏以解锁！",
["bm_global_value_superior"] = "高级",
["bm_global_value_sweettooth"] = "特殊道具",
["bm_global_value_sweettooth_unlock"] = "下载免费的Sweet Tooth DLC以解锁",
["bm_global_value_the_bomb"] = "炸弹劫案",
["bm_global_value_the_bomb_unlock"] = "购买炸弹劫案DLC以解锁",
["bm_global_value_turtles"] = "盖奇忍者包",
["bm_global_value_turtles_unlock"] = "购买盖奇忍者包DLC以解锁！",
["bm_global_value_twitch_pack"] = "Humble面具包",
["bm_global_value_twitch_pack_unlock"] = "需要 PAYDAY 2: Humble 面具包以解锁！",
["bm_global_value_west"] = "狂野西部包",
["bm_global_value_west_unlock"] = "购买西部武器包DLC以解锁！",
["bm_global_value_xmas"] = "圣诞节",
["bm_global_value_xmas_soundtrack"] = "圣诞节原声",
["bm_global_value_xmas_soundtrack_unlock"] = "购买圣诞节原声DLC以解锁！",
["bm_mask_chains_beeef"] = "Chains Beeef",
["bm_mask_chains_clown"] = "Chains Clown",
["bm_mask_chains_clown_gold"] = "Chains Gold",
["bm_mask_chains_hockey"] = "Chains Hockey",
["bm_mask_chains_president"] = "Obama",
["bm_mask_dallas_beeef"] = "Dallas Beeef",
["bm_mask_dallas_clown"] = "Dallas Clown",
["bm_mask_dallas_clown_gold"] = "Dallas Gold",
["bm_mask_dallas_hockey"] = "Hockey",
["bm_mask_dallas_president"] = "Nixon",
["bm_mask_dallas_santa"] = "Santa",
["bm_mask_hoxton_beeef"] = "Hoxton Beeef",
["bm_mask_hoxton_clown_gold"] = "Hoxton Gold",
["bm_mask_hoxton_hockey"] = "Hoxton Hockey",
["bm_mask_hoxton_president"] = "Bush",
["bm_mask_troll_chains_lol"] = "Chains Troll",
["bm_mask_troll_dallas_lol"] = "Dallas Troll",
["bm_mask_troll_hoxton_lol"] = "Hoxton Troll",
["bm_mask_troll_wolf_lol"] = "Wolf Troll",
["bm_mask_wolf_beeef"] = "Wolf Beeef",
["bm_mask_wolf_clown_gold"] = "Wolf Gold",
["bm_mask_wolf_hockey"] = "Wolf Hockey",
["bm_mask_wolf_president"] = "Clinton",
["bm_mask_zombie_chains"] = "Chains Zombie",
["bm_mask_zombie_dallas"] = "Dallas Zombie",
["bm_mask_zombie_hoxton"] = "Hoxton Zombie",
["bm_mask_zombie_wolf"] = "Wolf Zombie",
["bm_melee_alien_maul"] = "外星人重拳",
["bm_melee_cqc_info"] = "这是把涂满毒药的匕首, 可以造成持续的伤害并有几率打断敌人的攻击.",
["bm_menu_alert_size"] = "潜入",
["bm_menu_ammo_capacity"] = "弹匣总量 $clip;, 总弹量 $max;",
["bm_menu_armor"] = "护甲",
["bm_menu_available_mods"] = "可使用配件",
["bm_menu_blackmarket_title"] = "黑市: $item;",
["bm_menu_bonus"] = "属性增益",
["bm_menu_bonus_concealment"] = "隐蔽值",
["bm_menu_bonus_concealment_tem"] = "隐蔽以及 $team_bonus; 团队属性增益",
["bm_menu_bonus_damage"] = "伤害",
["bm_menu_bonus_damage_tem"] = "伤害以及 $team_bonus; 团队属性增益",
["bm_menu_bonus_recoil"] = "稳定",
["bm_menu_bonus_recoil_tem"] = "稳定以及 $team_bonus; 团队属性增益",
["bm_menu_bonus_spread"] = "精准",
["bm_menu_bonus_spread_tem"] = "精准以及 and $team_bonus; 团队属性增益",
["bm_menu_bonus_team_exp_money"] = "$team_bonus; 团队属性增益",
["bm_menu_bonus_total_ammo"] = "总弹量",
["bm_menu_bonus_total_ammo_tem"] = "总弹量以及 $team_bonus; 团队属性增益",
["bm_menu_btn_buy_mask_slot"] = "解锁面具槽",
["bm_menu_btn_buy_new_mask"] = "购买新面具",
["bm_menu_btn_buy_new_weapon"] = "购买新武器",
["bm_menu_btn_buy_selected_mask"] = "涂装面具",
["bm_menu_btn_buy_selected_weapon"] = "购买武器",
["bm_menu_btn_buy_weapon_slot"] = "解锁武器槽",
["bm_menu_btn_choose"] = "选择配件类型",
["bm_menu_btn_choose_global_value"] = "选择总值",
["bm_menu_btn_choose_mask_colors"] = "选择颜色",
["bm_menu_btn_choose_mask_materials"] = "选择材质",
["bm_menu_btn_choose_mask_mod"] = "选择$type;",
["bm_menu_btn_choose_mask_texture"] = "选择纹样",
["bm_menu_btn_choose_weapon_cosmetic"] = "选择物品...",
["bm_menu_btn_clear_preferred"] = "清除首选角色",
["bm_menu_btn_craft_mod"] = "安装配件",
["bm_menu_btn_customize_mask"] = "完成面具涂装",
["bm_menu_btn_equip_armor"] = "装备护甲",
["bm_menu_btn_equip_deployable"] = "装备放置物",
["bm_menu_btn_equip_grenade"] = "装备投掷物",
["bm_menu_btn_equip_mask"] = "装备面具",
["bm_menu_btn_equip_melee_weapon"] = "装备近战武器",
["bm_menu_btn_equip_weapon"] = "装备武器",
["bm_menu_btn_equip_weapon_cosmetic"] = "确认皮肤",
["bm_menu_btn_mod"] = "改造武器",
["bm_menu_btn_mod_mask"] = "自定义面具",
["bm_menu_btn_move_mask"] = "移动面具",
["bm_menu_btn_move_weapon"] = "移动武器",
["bm_menu_btn_open_container"] = "打开保险箱",
["bm_menu_btn_place_mask"] = "放置面具",
["bm_menu_btn_place_weapon"] = "放置武器",
["bm_menu_btn_preview"] = "预览武器",
["bm_menu_btn_preview_grenade"] = "预览投掷物",
["bm_menu_btn_preview_mask"] = "预览面具",
["bm_menu_btn_preview_melee_weapon"] = "预览近战武器",
["bm_menu_btn_preview_no_mod"] = "预览无该配件武器",
["bm_menu_btn_preview_weapon_cosmetic"] = "预览武器皮肤",
["bm_menu_btn_preview_with_mod"] = "预览已装该配件武器",
["bm_menu_btn_remove_mask"] = "返还面具",
["bm_menu_btn_remove_mod"] = "移除配件",
["bm_menu_btn_remove_weapon_cosmetic"] = "移除皮肤",
["bm_menu_btn_sell"] = "售出武器",
["bm_menu_btn_sell_mask"] = "售出面具",
["bm_menu_btn_sell_tradable"] = "在社区市场上出售",
["bm_menu_btn_set_preferred"] = "选择作为首选角色",
["bm_menu_btn_set_preferred_to_slot"] = "设定首选",
["bm_menu_btn_stop_move"] = "取消",
["bm_menu_btn_swap_mask"] = "交换面具",
["bm_menu_btn_swap_preferred_slots"] = "切换首选",
["bm_menu_btn_swap_weapon"] = "交换武器",
["bm_menu_btn_switch_reticle"] = "更换准星图案",
["bm_menu_buy_dlc"] = "访问DLC商店",
["bm_menu_buy_mask_title"] = "面具库",
["bm_menu_buy_weapon_title"] = "购买$weapon_category;",
["bm_menu_cannot_buy_mask_slot"] = "资金不足",
["bm_menu_cannot_buy_weapon_slot"] = "资金不足",
["bm_menu_cash"] = "现金奖励",
["bm_menu_characters"] = "角色",
["bm_menu_charge_time"] = "蓄力时间",
["bm_menu_choose_color"] = "选择颜色",
["bm_menu_choose_global_value_title"] = "$category;: 全球价值",
["bm_menu_choose_mask_mod_title"] = "$mask;: 自定义",
["bm_menu_choose_material"] = "选择材质",
["bm_menu_choose_mod_colors"] = "$mask;: 选择颜色",
["bm_menu_choose_mod_craft"] = "$weapon_name;: 选择 $mod_type; 配件",
["bm_menu_choose_mod_materials"] = "$mask;: 选择材质",
["bm_menu_choose_mod_textures"] = "$mask;: 选择纹样",
["bm_menu_choose_mod_type_title"] = "$weapon_name;: 选择配件类型",
["bm_menu_choose_pattern"] = "选择纹样",
["bm_menu_chosen"] = "已选择",
["bm_menu_colors"] = "颜色",
["bm_menu_concealment"] = "隐蔽值",
["bm_menu_concealment_desc"] = "在踩点模式有可能被发现.",
["bm_menu_concealment_high"] = "高",
["bm_menu_concealment_low"] = "低",
["bm_menu_concealment_medium"] = "中",
["bm_menu_conflict"] = "这个配件与你现有的改装冲突 $conflict;",
["bm_menu_cosmetic_locked_weapon"] = "被当前武器皮肤锁定",
["bm_menu_damage"] = "伤害",
["bm_menu_damage_effect"] = "击倒",
["bm_menu_damage_shake"] = "稳定",
["bm_menu_deployables"] = "放置物",
["bm_menu_disables_cosmetic_bonus"] = "这个配件的属性增益将覆盖皮肤的属性增益.",
["bm_menu_disables_damage_to_hot"] = "装备该护甲将使前卫天赋失效",
["bm_menu_dlc"] = "dlc",
["bm_menu_dlc_locked"] = "没有许可",
["bm_menu_dodge"] = "闪避",
["bm_menu_drills"] = "钻机",
["bm_menu_empty_mask_slot"] = "空的面具槽",
["bm_menu_empty_mask_slot_buy_info"] = "新的面具可以通过完成合约获得.",
["bm_menu_empty_slot"] = "购买新的 $category;",
["bm_menu_empty_weapon_slot"] = "空的武器槽",
["bm_menu_empty_weapon_slot_buy_info"] = "增加你的声望等级以解锁新武器.",
["bm_menu_equip_weapon_cosmetics_title"] = "确认皮肤: $cosmetics;",
["bm_menu_equipped"] = "已装备",
["bm_menu_fire_rate"] = "射速",
["bm_menu_global_event"] = "活动",
["bm_menu_grenades"] = "投掷物",
["bm_menu_health"] = "生命值",
["bm_menu_hipfire_recoil"] = "腰射精度",
["bm_menu_holding_item"] = "移动",
["bm_menu_installed_mods"] = "已安装的配件",
["bm_menu_inventory_tradable_all"] = "所有",
["bm_menu_inventory_tradable_drills"] = "钻机",
["bm_menu_inventory_tradable_safes"] = "保险箱",
["bm_menu_inventory_tradable_weapon_skins"] = "武器皮肤",
["bm_menu_item_amount"] = "库存: $amount;",
["bm_menu_item_locked"] = "未持有",
["bm_menu_item_unlocked"] = "可用",
["bm_menu_item_uses"] = "使用: $amount;",
["bm_menu_last_of_kind"] = "和",
["bm_menu_last_weapon_warning"] = "你不能将仓库内的最后一把武器出售！",
["bm_menu_level_req"] = "现有的声望等级未能解锁 $level;",
["bm_menu_locked_mask_slot"] = "未解锁的面具槽",
["bm_menu_locked_mask_slot_desc"] = "你需要先解锁这个面具槽才能放置面具！",
["bm_menu_locked_weapon_slot"] = "未解锁的武器槽",
["bm_menu_locked_weapon_slot_desc"] = "你需要先解锁这个武器槽才能放置武器！",
["bm_menu_mask_customization"] = "面具自定义",
["bm_menu_mask_options"] = "自定义选项",
["bm_menu_masks"] = "面具",
["bm_menu_materials"] = "材质",
["bm_menu_melee_weapons"] = "近战武器",
["bm_menu_mods"] = "配件",
["bm_menu_movement"] = "移动速度",
["bm_menu_mystery_asset"] = "神秘资产",
["bm_menu_no_items"] = "不可使用",
["bm_menu_no_masks_in_stash_varning"] = "你的面具库已满.",
["bm_menu_no_mod"] = "没有配件.",
["bm_menu_not_enough_cash"] = "没有足够的现金",
["bm_menu_out_of_money"] = "你需要 $money; 现金来装备这个配件 .",
["bm_menu_out_of_money_standard"] = "你需要 $money; 现金来购买这个.",
["bm_menu_page"] = "第 $page; 页",
["bm_menu_part_dlc_locked"] = "被一个或多个武器模组锁定.",
["bm_menu_range"] = "范围",
["bm_menu_rarity_common"] = "普通",
["bm_menu_rarity_epic"] = "史诗",
["bm_menu_rarity_legendary"] = "传奇",
["bm_menu_rarity_legendary_item"] = "传奇物品",
["bm_menu_rarity_legendary_item_long"] = "或者一件极其稀有的物品！",
["bm_menu_rarity_rare"] = "稀有",
["bm_menu_rarity_uncommon"] = "罕见",
["bm_menu_recoil"] = "稳定",
["bm_menu_safe_contains_following_items"] = "保险箱包含以下内容:$NL;$content;",
["bm_menu_safes"] = "保险箱",
["bm_menu_saw_ammo_capacity"] = "锯刃: $max;.",
["bm_menu_selected"] = "已选定",
["bm_menu_skill_locked_ammo_bag"] = "在暴徒技能树花费一个技能点以解锁弹药包",
["bm_menu_skill_locked_armor_kit"] = "需要衣帽间天赋",
["bm_menu_skill_locked_bodybags_bag"] = "需要送葬者技能",
["bm_menu_skill_locked_doctor_bag"] = "在黑手技能树花费一个技能点以解锁医疗包",
["bm_menu_skill_locked_ecm_jammer"] = "在幽灵技能树花费一个技能点以解锁ECM干扰器",
["bm_menu_skill_locked_first_aid_kit"] = "在逃犯技能树花费一个技能点以解锁急救包",
["bm_menu_skill_locked_jowi"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skill_locked_level_7"] = "需要铁人技能",
["bm_menu_skill_locked_saw"] = "需要便携式电锯技能",
["bm_menu_skill_locked_saw_secondary"] = "需要碳化锯片技能",
["bm_menu_skill_locked_sentry_gun"] = "需要炮台技能",
["bm_menu_skill_locked_trip_mine"] = "在技师技能树花费一个技能点以解锁绊雷",
["bm_menu_skill_locked_usp"] = "加入PAYDAY_2_steam社区组以解锁！",
["bm_menu_skill_locked_x_1911"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skill_locked_x_b92fs"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skill_locked_x_deagle"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skill_locked_x_g17"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skill_locked_x_g22c"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skill_locked_x_sr2"] = "需要双枪技能的双手同利",
["bm_menu_skill_locked_x_usp"] = "需要两手同利天赋或者双枪技能",
["bm_menu_skilltree_locked"] = "需要 $SKILL; 技能.",
["bm_menu_spread"] = "精准",
["bm_menu_spread_moving"] = "机动性",
["bm_menu_stamina"] = "耐力",
["bm_menu_stats_base"] = "基准",
["bm_menu_stats_detection"] = "暴露度",
["bm_menu_stats_max_detection"] = "最高暴露度！",
["bm_menu_stats_min_detection"] = "最低暴露度！",
["bm_menu_stats_mod"] = "配件",
["bm_menu_stats_skill"] = "技能",
["bm_menu_stats_total"] = "总计",
["bm_menu_steam_item_name"] = "##$name;##",
["bm_menu_steam_item_quality"] = "品质: ##$quality;##",
["bm_menu_steam_item_quality_rarity"] = "##$quality;## ##$rarity;##",
["bm_menu_steam_item_rarity"] = "稀有度: ##$rarity;##",
["bm_menu_steam_item_weapon_cosmetic"] = "武器皮肤: $weapon;",
["bm_menu_suppression"] = "威胁度",
["bm_menu_textures"] = "图案",
["bm_menu_ti_alphabetic"] = "首字母",
["bm_menu_ti_aquired"] = "已获得",
["bm_menu_ti_bonus"] = "拥有加成",
["bm_menu_ti_category"] = "类型",
["bm_menu_ti_quality"] = "品质",
["bm_menu_ti_rarity"] = "稀有度",
["bm_menu_ti_sort_option"] = "排序方式: $sort;",
["bm_menu_totalammo"] = "总弹量",
["bm_menu_weapon_bonus"] = "武器属性增益",
["bm_menu_weapon_cosmetics"] = "武器皮肤",
["bm_menu_weapon_info_modded"] = "与 $list_of_mods;适合.",
["bm_menu_weapon_movement_penalty_info"] = "备注: 装备时, 这武器将减少你的移动速度 $penalty;.",
["bm_menu_weapon_skins"] = "武器皮肤",
["bm_menu_xp"] = "经验奖励",
["bm_mtl_alien_slime"] = "外星物质",
["bm_mtl_alligator"] = "鳄鱼皮",
["bm_mtl_arizona"] = "美国原装",
["bm_mtl_armygreen"] = "军绿色",
["bm_mtl_baby"] = "宝贝",
["bm_mtl_bamboo"] = "竹子",
["bm_mtl_bananapeel"] = "香蕉皮",
["bm_mtl_bandages"] = "木乃伊绷带",
["bm_mtl_bark1"] = "橡木",
["bm_mtl_bark2"] = "松球",
["bm_mtl_bark3"] = "白杨木",
["bm_mtl_bionic"] = "仿生学",
["bm_mtl_bismuth"] = "铋",
["bm_mtl_blackmetal"] = "黑色金属",
["bm_mtl_blooded"] = "血统",
["bm_mtl_bloodred"] = "血红色",
["bm_mtl_bone"] = "骨头",
["bm_mtl_bugshell"] = "虫壳",
["bm_mtl_burn"] = "燃烧",
["bm_mtl_cactus"] = "仙人掌",
["bm_mtl_candlelight"] = "烛火",
["bm_mtl_candy"] = "糖果",
["bm_mtl_carapace"] = "甲壳",
["bm_mtl_carbon"] = "碳纤维",
["bm_mtl_carbongrid"] = "纳米",
["bm_mtl_carpet"] = "地毯",
["bm_mtl_cash"] = "现金",
["bm_mtl_casino"] = "赌场",
["bm_mtl_chain_armor"] = "锁子甲",
["bm_mtl_chrome_purple"] = "紫铬",
["bm_mtl_chromescape"] = "铬离",
["bm_mtl_clay"] = "粘土",
["bm_mtl_coal"] = "煤",
["bm_mtl_concrete1"] = "混凝土",
["bm_mtl_copper"] = "铜",
["bm_mtl_cosmoline"] = "防腐润滑油",
["bm_mtl_cracks1"] = "噼啪作响",
["bm_mtl_cushion"] = "坐垫",
["bm_mtl_dark_leather"] = "深色皮革",
["bm_mtl_dark_rust"] = "生锈金属",
["bm_mtl_dark_sand"] = "沙",
["bm_mtl_dawn"] = "黎明",
["bm_mtl_days"] = "日期",
["bm_mtl_deep_bronze"] = "青铜",
["bm_mtl_denim"] = "牛仔布",
["bm_mtl_diamond"] = "钻石",
["bm_mtl_dimblue"] = "暗淡蓝",
["bm_mtl_electric"] = "电",
["bm_mtl_electronic"] = "电路板",
["bm_mtl_enlightment"] = "启蒙",
["bm_mtl_erdl"] = "丛林迷彩",
["bm_mtl_error"] = "错误",
["bm_mtl_evil"] = "邪恶",
["bm_mtl_explosive"] = "爆炸",
["bm_mtl_eye"] = "眼",
["bm_mtl_feathers"] = "羽毛",
["bm_mtl_finewood"] = "细木",
["bm_mtl_flamingoeye"] = "火烈鸟之眼",
["bm_mtl_flow"] = "屠宰",
["bm_mtl_forged"] = "锻造",
["bm_mtl_fossil"] = "化石",
["bm_mtl_frost"] = "霜",
["bm_mtl_fur"] = "毛皮",
["bm_mtl_galvanized"] = "镀锌钢",
["bm_mtl_gemstone"] = "宝石",
["bm_mtl_glade"] = "林间空地",
["bm_mtl_goateye"] = "山羊之眼",
["bm_mtl_gold_clean"] = "金色",
["bm_mtl_goldfever"] = "淘金狂",
["bm_mtl_greygloss"] = "灰色光泽",
["bm_mtl_gunmetal"] = "炮铜",
["bm_mtl_gunsmoke"] = "枪烟",
["bm_mtl_hades"] = "阎王",
["bm_mtl_hardshell"] = "硬壳",
["bm_mtl_hatred"] = "仇恨",
["bm_mtl_hay"] = "干草",
["bm_mtl_haze"] = "阴霾",
["bm_mtl_heavymetal"] = "重金属",
["bm_mtl_hot_cold"] = "冷热",
["bm_mtl_houndstooth"] = "千鸟格",
["bm_mtl_insectoid"] = "多脚机器人",
["bm_mtl_jade"] = "玉",
["bm_mtl_leaf"] = "叶子",
["bm_mtl_leather1"] = "皮革",
["bm_mtl_magma"] = "地狱",
["bm_mtl_marble"] = "珍珠",
["bm_mtl_matcap_mushroom_cloud_df"] = "蘑菇云",
["bm_mtl_matcap_redwhite_df"] = "红黑",
["bm_mtl_matteblack"] = "亚光黑色",
["bm_mtl_meat"] = "肉",
["bm_mtl_mercury"] = "水星",
["bm_mtl_metal1"] = "金属",
["bm_mtl_mud"] = "泥",
["bm_mtl_neon"] = "氖",
["bm_mtl_oilmetal"] = "油性金属",
["bm_mtl_old"] = "筋疲力尽",
["bm_mtl_oldbronze"] = "青铜锈蚀",
["bm_mtl_orchish"] = "兽人",
["bm_mtl_origami"] = "折纸手工",
["bm_mtl_oxide_bronze"] = "氧化铜",
["bm_mtl_parchment"] = "羊皮纸",
["bm_mtl_patriot"] = "爱国者",
["bm_mtl_pianoblack"] = "钢琴黑",
["bm_mtl_plastic"] = "塑料",
["bm_mtl_plastic_hood"] = "塑料罩",
["bm_mtl_plush"] = "毛绒",
["bm_mtl_plywood"] = "合板",
["bm_mtl_prehistoric"] = "史前",
["bm_mtl_punk"] = "朋克",
["bm_mtl_radioactive"] = "放射性的",
["bm_mtl_rainbow"] = "彩虹",
["bm_mtl_redsun"] = "红太阳",
["bm_mtl_redwhiteblue"] = "红色, 白色和蓝色",
["bm_mtl_rhino"] = "犀牛",
["bm_mtl_rock1"] = "响彻石",
["bm_mtl_rock2"] = "干净的岩石",
["bm_mtl_rock3"] = "硬石",
["bm_mtl_rock_marble"] = "大理石岩",
["bm_mtl_rubber"] = "橡胶",
["bm_mtl_rug"] = "地毯",
["bm_mtl_sakura"] = "樱",
["bm_mtl_sancti"] = "处分",
["bm_mtl_scale_armor"] = "麟甲",
["bm_mtl_scales"] = "蛇鳞",
["bm_mtl_scorpion"] = "蝎",
["bm_mtl_sinister"] = "阴险",
["bm_mtl_skin"] = "肉",
["bm_mtl_slime"] = "粘液",
["bm_mtl_sparks"] = "火花",
["bm_mtl_splinter"] = "迷彩分裂",
["bm_mtl_stained_glass"] = "污色玻璃",
["bm_mtl_stars"] = "星星",
["bm_mtl_still_waters"] = "明镜止水",
["bm_mtl_sunset"] = "日落",
["bm_mtl_titanium"] = "钛",
["bm_mtl_toast"] = "烤面包",
["bm_mtl_tongue"] = "长舌",
["bm_mtl_twoblue"] = "铬蓝",
["bm_mtl_void"] = "空间",
["bm_mtl_wade"] = "韦德",
["bm_mtl_waterblue"] = "蓝水",
["bm_mtl_westernsunset"] = "西方日落",
["bm_mtl_whiterock"] = "白石镇",
["bm_mtl_wicker1"] = "柳条",
["bm_txt_ace"] = "高手",
["bm_txt_agatha"] = "阿加莎",
["bm_txt_americaneagle"] = "美国鹰",
["bm_txt_anarchy"] = "无政府状态",
["bm_txt_aperture"] = "光圈科技",
["bm_txt_arena_logo"] = "Alesso图标",
["bm_txt_army"] = "别动队",
["bm_txt_arrow"] = "箭",
["bm_txt_atom"] = "凌",
["bm_txt_banana"] = "香蕉",
["bm_txt_barbarian"] = "野蛮纹身",
["bm_txt_beast"] = "野兽",
["bm_txt_big_skull"] = "细条纹",
["bm_txt_biohazard"] = "生化危机",
["bm_txt_bite"] = "狂暴撕咬",
["bm_txt_blood"] = "血",
["bm_txt_bloodsucker"] = "吸血鬼",
["bm_txt_bsomebody"] = "成为别人",
["bm_txt_bugger"] = "开溜",
["bm_txt_bullseye"] = "靶心",
["bm_txt_caduceus"] = "众神使者的手杖",
["bm_txt_cake"] = "一块蛋糕",
["bm_txt_camo"] = "伪装",
["bm_txt_captainwar"] = "队长战",
["bm_txt_cards"] = "扑克牌",
["bm_txt_cat"] = "砰 砰 砰",
["bm_txt_celtic1"] = "凯尔特十字架",
["bm_txt_celtic2"] = "凯尔特结",
["bm_txt_chains"] = "交叉链",
["bm_txt_checkerboard"] = "检查局",
["bm_txt_checkered_out"] = "格子风",
["bm_txt_chief"] = "首席",
["bm_txt_chips"] = "薯片",
["bm_txt_circle_raster"] = "环形栅格",
["bm_txt_circuit"] = "电路板",
["bm_txt_clown"] = "快乐小丑",
["bm_txt_cobrakai"] = "眼镜蛇",
["bm_txt_cogs"] = "发条齿轮",
["bm_txt_commando"] = "兽医",
["bm_txt_companioncube"] = "同伴立方",
["bm_txt_compass"] = "航海指南针",
["bm_txt_coyote"] = "狼",
["bm_txt_cracker"] = "饼干",
["bm_txt_cracks"] = "裂缝",
["bm_txt_crosshatch"] = "交叉线",
["bm_txt_daft_heart"] = "西曼迭斯",
["bm_txt_daniel"] = "上帝是我的审判",
["bm_txt_dazzle"] = "炫",
["bm_txt_death"] = "死亡",
["bm_txt_deathcube"] = "死亡立方",
["bm_txt_deathdealer"] = "死亡贩子",
["bm_txt_diamond"] = "三点",
["bm_txt_dices"] = "骰子",
["bm_txt_digital"] = "数字",
["bm_txt_digitalcamo"] = "数码迷彩",
["bm_txt_dinoscars"] = "恐龙疤痕",
["bm_txt_dinoskull"] = "恐龙头骨",
["bm_txt_dinostripes"] = "恐龙条纹",
["bm_txt_dollar_signs"] = "钱钱账单啊",
["bm_txt_doodles"] = "涂鸦",
["bm_txt_doomweaver"] = "厄运网",
["bm_txt_dragon_full"] = "龙",
["bm_txt_dragon_split"] = "龙斯普利特",
["bm_txt_dragons"] = "小龙",
["bm_txt_eightball"] = "魔法8号球",
["bm_txt_electric"] = "电器中心",
["bm_txt_emblem1"] = "两头狮子",
["bm_txt_emblem2"] = "山和天空",
["bm_txt_emblem3"] = "两刀一条",
["bm_txt_emblem4"] = "下面的条纹",
["bm_txt_emperor"] = "皇帝",
["bm_txt_evileye"] = "邪眼",
["bm_txt_exmachina"] = "机械姬",
["bm_txt_fan"] = "我爱OVERKILL",
["bm_txt_fatman"] = "赏金猎人",
["bm_txt_fenris"] = "芬里厄",
["bm_txt_fighter"] = "斗士",
["bm_txt_filthythirteen"] = "痴十三",
["bm_txt_finger_paint"] = "手指画",
["bm_txt_fingerpaint"] = "手指画",
["bm_txt_fingerprint"] = "指纹",
["bm_txt_fireborn"] = "淬火",
["bm_txt_flag"] = "旗",
["bm_txt_flamer"] = "火焰喷射器",
["bm_txt_flames"] = "地狱",
["bm_txt_flammable"] = "易燃的",
["bm_txt_fleur"] = "鸢尾花",
["bm_txt_fleur2"] = "金百合",
["bm_txt_foot"] = "大脚",
["bm_txt_forestcamo"] = "森林迷彩",
["bm_txt_fur"] = "毛皮",
["bm_txt_gearhead"] = "齿轮磨床",
["bm_txt_giraffe"] = "长颈鹿",
["bm_txt_girlsandboys"] = "女孩和男孩",
["bm_txt_goatface"] = "山羊脸",
["bm_txt_gradient"] = "平滑渐变",
["bm_txt_grayson"] = "蒙面恶棍",
["bm_txt_hand"] = "左手",
["bm_txt_hannibalistic"] = "汉尼拔",
["bm_txt_hawk"] = "鹰之翼",
["bm_txt_hawkhelm"] = "鹰头盔",
["bm_txt_headshot"] = "爆头",
["bm_txt_hearts"] = "心形糖果",
["bm_txt_hellish"] = "地狱般",
["bm_txt_hellsanchor"] = "地狱之锚",
["bm_txt_hexagon"] = "六角圈",
["bm_txt_hieroglyphs"] = "象形文字",
["bm_txt_hiptobepolygon"] = "时髦六边形",
["bm_txt_horizon_circle"] = "月亮和水",
["bm_txt_horus"] = "荷鲁斯",
["bm_txt_hotflames"] = "炙热火焰",
["bm_txt_hotline"] = "热线",
["bm_txt_hunter"] = "猎人",
["bm_txt_hypnotic"] = "嗨爆",
["bm_txt_illumigoati"] = "先知",
["bm_txt_illuminati"] = "光明",
["bm_txt_imperial"] = "帝国",
["bm_txt_inverted"] = "倒",
["bm_txt_japan"] = "日出东方",
["bm_txt_kabuki1"] = "歌舞伎",
["bm_txt_koi"] = "鲤",
["bm_txt_kraken"] = "鲲",
["bm_txt_kurbits"] = "装饰花纹",
["bm_txt_leopard"] = "豹",
["bm_txt_liongamelion"] = "Lion Game Lion",
["bm_txt_loverboy"] = "情人男孩",
["bm_txt_luchador"] = "墨西哥摔跤手",
["bm_txt_luse"] = "绿色",
["bm_txt_magical_sympbols_1"] = "神奇符号",
["bm_txt_magical_sympbols_2"] = "第二标志",
["bm_txt_magnet"] = "磁性铁",
["bm_txt_mantis"] = "螳螂",
["bm_txt_marv"] = "奇妙块",
["bm_txt_maskedfalcon"] = "蒙面猎鹰",
["bm_txt_mason"] = "梅森",
["bm_txt_med_pat"] = "中世纪",
["bm_txt_messatsu"] = "湮灭征兆",
["bm_txt_molecule"] = "分子",
["bm_txt_monkeyskull"] = "猴头骨",
["bm_txt_monstervisor"] = "怪物遮阳板",
["bm_txt_muerte"] = "老爹",
["bm_txt_native"] = "神圣",
["bm_txt_no_color_full_material"] = "唯一材质",
["bm_txt_no_color_no_material"] = "基础面具",
["bm_txt_nuclear"] = "放射性的",
["bm_txt_oni"] = "鬼",
["bm_txt_origami"] = "烟花",
["bm_txt_ornamentalcrown"] = "观赏冠",
["bm_txt_ouro"] = "大毒蛇的头",
["bm_txt_ouroboros"] = "大毒蛇",
["bm_txt_overkill"] = "OVERKILL",
["bm_txt_pain"] = "疼痛",
["bm_txt_paint1"] = "广招",
["bm_txt_paint2"] = "锯齿斑纹",
["bm_txt_palmtrees"] = "棕榈树",
["bm_txt_pattern"] = "神秘",
["bm_txt_pd2"] = "PAYDAY 2",
["bm_txt_peace_sign"] = "和平标志",
["bm_txt_pentagram"] = "五角星",
["bm_txt_pirate"] = "海盗眼罩",
["bm_txt_pleter"] = "麻花",
["bm_txt_poison"] = "毒",
["bm_txt_portal"] = "传送门",
["bm_txt_predator"] = "史前捕食者",
["bm_txt_public_enemy"] = "公敌",
["bm_txt_pumpgrin"] = "南瓜头",
["bm_txt_puzzle"] = "解谜",
["bm_txt_racestripes"] = "种族斑纹",
["bm_txt_raster"] = "栅格",
["bm_txt_reaper"] = "死神",
["bm_txt_ribcage"] = "肋骨",
["bm_txt_rising_sun"] = "旭日",
["bm_txt_robotic"] = "机器人",
["bm_txt_roman"] = "罗马",
["bm_txt_rorschach"] = "主角",
["bm_txt_royale"] = "皇纹",
["bm_txt_ruler"] = "统治者",
["bm_txt_runes"] = "符文",
["bm_txt_scars"] = "爪击",
["bm_txt_shazam"] = "闪电箭",
["bm_txt_shout"] = "号叫",
["bm_txt_shutupandbleed"] = "闭嘴而流血",
["bm_txt_sidestripe"] = "三粗条纹",
["bm_txt_skull"] = "头骨破碎",
["bm_txt_skulls"] = "头骨",
["bm_txt_smiley_face"] = "笑脸",
["bm_txt_smoke"] = "烟雾",
["bm_txt_solidfirst"] = "固定第一",
["bm_txt_solidsecond"] = "固定第二",
["bm_txt_soundwave"] = "声波",
["bm_txt_spartan"] = "斯巴达",
["bm_txt_spawn"] = "AI有啥用",
["bm_txt_spider"] = "贪婪的蜘蛛",
["bm_txt_spidereyes"] = "蜘蛛眼",
["bm_txt_spiderweb"] = "蜘蛛网",
["bm_txt_spikes"] = "倒刺",
["bm_txt_split"] = "分裂",
["bm_txt_spook"] = "寝食不安",
["bm_txt_spots"] = "斑点",
["bm_txt_star"] = "光彩之星",
["bm_txt_starbreeze"] = "Starbreeze Sun",
["bm_txt_stars"] = "明星",
["bm_txt_starvr"] = "StarVR",
["bm_txt_starvr_desc"] = "StarVR",
["bm_txt_steampunk"] = "蒸汽朋克",
["bm_txt_stipple"] = "点画",
["bm_txt_stitches"] = "拆线",
["bm_txt_striped"] = "升空",
["bm_txt_stripes"] = "斑纹",
["bm_txt_styx"] = "冥河",
["bm_txt_sunavatar"] = "太阳化身",
["bm_txt_swe_camo"] = "老虎迷彩",
["bm_txt_swirl"] = "漩涡",
["bm_txt_target"] = "宝珠",
["bm_txt_tcn"] = "TCN",
["bm_txt_terror"] = "恐怖",
["bm_txt_tf2"] = "军团要塞2",
["bm_txt_totem"] = "图腾",
["bm_txt_toto"] = "守护者",
["bm_txt_trekronor"] = "三冠",
["bm_txt_tribal"] = "之字形斑纹",
["bm_txt_tribal2"] = "部落圈",
["bm_txt_tribal_1"] = "稀有部落",
["bm_txt_tribal_2"] = "传奇部落",
["bm_txt_tribalface"] = "部落脸",
["bm_txt_tribalstroke"] = "部落行程",
["bm_txt_tribalwave"] = "部落浪潮",
["bm_txt_two"] = "收获日里的2",
["bm_txt_two_face"] = "双面",
["bm_txt_uglyrug"] = "丑毯",
["bm_txt_ultimaterobber"] = "蒙面黑手",
["bm_txt_unionjack"] = "联盟杰克",
["bm_txt_untextures"] = "清洁",
["bm_txt_usa"] = "天佑美国",
["bm_txt_venomous"] = "毒蛇",
["bm_txt_vertical"] = "垂直分割",
["bm_txt_vicious"] = "恶毒",
["bm_txt_vortex"] = "涡流",
["bm_txt_war_paint"] = "战争漆",
["bm_txt_wargod"] = "战神",
["bm_txt_warping"] = "扭曲",
["bm_txt_warrior"] = "战士",
["bm_txt_weathered"] = "风化",
["bm_txt_webbed"] = "网状",
["bm_txt_weld"] = "焊接",
["bm_txt_whiner"] = "哀鸣者",
["bm_txt_wingsofdeath"] = "死亡之翼",
["bm_txt_wtf"] = "卧槽？",
["bm_txt_yggdrasil"] = "世界之树",
["bm_txt_yinyang"] = "阴阳",
["bm_txt_youkai"] = "妖怪",
["bm_txt_zebra"] = "斑马",
["bm_txt_zipper"] = "拉链",
["bm_w_colt_1911_desc"] = ".45ACP自动手枪, 中等的阻滞力但携弹量低.",
["bm_wp_1911_b_long_desc"] = "加长的枪管提供了更好的精度, 而套筒上加装的排气孔降低了上跳, 提高稳定.但隐蔽性下降.",
["bm_wp_1911_b_standard"] = "特工套筒",
["bm_wp_1911_b_standard_desc"] = "标配部件.",
["bm_wp_1911_b_vented_desc"] = "套筒加装了排气孔减少了上跳, 提高操控性.",
["bm_wp_1911_body_standard"] = "特工枪身",
["bm_wp_1911_body_standard_desc"] = "标配部件.",
["bm_wp_1911_co_1_desc"] = "提升威胁度, 增加威力.但隐蔽性减少.",
["bm_wp_1911_co_2_desc"] = "精度和操纵性提高.隐蔽性减少.",
["bm_wp_1911_g_bling_desc"] = "一个装饰奢华的握把.",
["bm_wp_1911_g_ergo_desc"] = "增加稳定的人体工学握把.",
["bm_wp_1911_g_standard"] = "标准握把",
["bm_wp_1911_g_standard_desc"] = "标配部件.",
["bm_wp_1911_m_extended_desc"] = "加大了弹匣容量.",
["bm_wp_1911_m_standard"] = "8发装.45柯尔特自动手枪弹弹匣",
["bm_wp_1911_m_standard_desc"] = "标配部件.",
["bm_wp_1911_o_long"] = "标配部件.",
["bm_wp_1911_o_long_desc"] = "标配部件",
["bm_wp_1911_o_standard"] = "标配部件.",
["bm_wp_1911_o_standard_desc"] = "标配部件.",
["bm_wp_74_b_standard"] = "标配部件.",
["bm_wp_74_b_standard_desc"] = "标配部件.",
["bm_wp_74_body_upperreceiver"] = "平滑防尘盖",
["bm_wp_74_body_upperreceiver_desc"] = "一个简洁的设计, 轻微提高了隐蔽性.",
["bm_wp_74_m_standard"] = "标配部件.",
["bm_wp_74_m_standard_desc"] = "标配部件.",
["bm_wp_ak5_b_std"] = "标配部件.",
["bm_wp_ak5_b_std_desc"] = "标配部件.",
["bm_wp_ak5_body_ak5"] = "标配部件.",
["bm_wp_ak5_body_ak5_desc"] = "标配部件.",
["bm_wp_ak5_body_rail"] = "标配部件.",
["bm_wp_ak5_body_rail_desc"] = "标配部件.",
["bm_wp_ak5_fg_ak5a"] = "亚当护木",
["bm_wp_ak5_fg_ak5a_desc"] = "隐蔽性轻微降低.",
["bm_wp_ak5_fg_ak5c_desc"] = "提高稳定.",
["bm_wp_ak5_fg_fnc_desc"] = "提高精准度降低隐蔽性.",
["bm_wp_ak5_s_ak5a"] = "亚当枪托",
["bm_wp_ak5_s_ak5a_desc"] = "标配部件.",
["bm_wp_ak5_s_ak5b_desc"] = "提高精度和稳定, 降低隐蔽性.",
["bm_wp_ak5_s_ak5c_desc"] = "一款能够提高隐蔽性和稳定的现代枪托.",
["bm_wp_ak_body_lowerreceiver"] = "标配部件.",
["bm_wp_ak_body_lowerreceiver_desc"] = "标配部件.",
["bm_wp_ak_fg_combo1"] = "战术木质护木.",
["bm_wp_ak_fg_combo1_desc"] = "标配部件.",
["bm_wp_ak_fg_combo2_desc"] = "该组装轻微增加了稳定.",
["bm_wp_ak_fg_combo3_desc"] = "增加稳定, 降低隐蔽值.",
["bm_wp_ak_fg_combo4"] = "东方模块化精密护木",
["bm_wp_ak_fg_combo4_desc"] = "实用但并不是很隐蔽的护木",
["bm_wp_ak_fg_standard"] = "没有配件",
["bm_wp_ak_fg_standard_desc"] = "标配部件.",
["bm_wp_ak_g_standard"] = "标配部件.",
["bm_wp_ak_g_standard_desc"] = "标配部件.",
["bm_wp_ak_m_akm"] = "标配部件.",
["bm_wp_ak_m_akm_desc"] = "标配部件.",
["bm_wp_ak_m_drum"] = "大容量弹鼓.",
["bm_wp_ak_m_drum_desc"] = "大容量的弹鼓.",
["bm_wp_ak_s_adapter"] = "提高稳定但轻微减少隐蔽值",
["bm_wp_ak_s_adapter_desc"] = "提高稳定但轻微减少隐蔽值",
["bm_wp_ak_s_folding_desc"] = "轻微增加稳定但降低便携性.",
["bm_wp_ak_s_psl_desc"] = "它的形状使它更稳定但很难隐蔽.",
["bm_wp_ak_s_skfoldable_desc"] = "一个轻微提高稳定的简单设计",
["bm_wp_akm_b_standard"] = "标配部件.",
["bm_wp_akm_b_standard_desc"] = "标配部件",
["bm_wp_akm_body_upperreceiver"] = "AK.762步枪的上机匣防尘盖",
["bm_wp_akm_body_upperreceiver_desc"] = "AK.762步枪的上机匣防尘盖",
["bm_wp_akmsu_b_standard"] = "标配部件",
["bm_wp_akmsu_b_standard_desc"] = "标配部件",
["bm_wp_akmsu_body_lowerreceiver"] = "标配部件",
["bm_wp_akmsu_body_lowerreceiver_desc"] = "标配部件",
["bm_wp_akmsu_fg_rail_desc"] = "它影响了隐蔽性但轻微提高稳定",
["bm_wp_akmsu_fg_standard"] = "没有配件",
["bm_wp_akmsu_fg_standard_desc"] = "标配部件.",
["bm_wp_ameno_1_achievment"] = "完成OWE SAW 72000成就解锁",
["bm_wp_ameno_2_achievment"] = "完成HEY MR. DJ 成就解锁",
["bm_wp_ameno_3_achievment"] = "完成$1.8M SPEEDRUN成就解锁",
["bm_wp_ameno_4_achievment"] = "完成HERE COMES THE PAIN TRAIN成就解锁",
["bm_wp_ameno_5_achievment"] = "完成THE WOLF LURES YOU TO YOUR GRAVE！成就解锁",
["bm_wp_ameno_6_achievment"] = "完成THE TURTLE ALWAYS WINS 成就解锁",
["bm_wp_ameno_7_achievment"] = "完成PRIVATE PARTY 成就解锁",
["bm_wp_ameno_8_achievment"] = "用CAR-4或AK武器杀死 $progress;条子",
["bm_wp_asval_g_standard"] = "标准护木",
["bm_wp_aug_b_long_desc"] = "加长了枪管使它的精准度上升但隐蔽值降低.",
["bm_wp_aug_b_medium"] = "中型枪管",
["bm_wp_aug_b_medium_desc"] = "标配部件.",
["bm_wp_aug_b_short_desc"] = "增加隐蔽性但降低准度和稳定.",
["bm_wp_aug_body_aug"] = "标配部件.",
["bm_wp_aug_body_aug_desc"] = "标配部件.",
["bm_wp_aug_fg_a3_desc"] = "隐蔽性会轻微降低.",
["bm_wp_aug_m_pmag"] = "标配部件.",
["bm_wp_aug_m_pmag_desc"] = "标配部件.",
["bm_wp_ben_b_long_achievment"] = "完成 霰弹101 成就解锁",
["bm_wp_ben_b_short_achievment"] = "完成 SEVEN ELEVEN成就解锁",
["bm_wp_ben_s_collapsed_achievment"] = "\"用任意装载独弹头的霰弹枪杀死 $progress; 个Shields\"",
["bm_wp_ben_s_solid"] = "固定枪托",
["bm_wp_ben_s_solid_achievment"] = "完成SHOCK AND AWE成就以解锁",
["bm_wp_beretta_b_std"] = "标配部件.",
["bm_wp_beretta_b_std_desc"] = "标配部件.",
["bm_wp_beretta_body_beretta"] = "标配部件.",
["bm_wp_beretta_body_beretta_desc"] = "标配部件.",
["bm_wp_beretta_body_rail"] = "使你能够安装手电和激光",
["bm_wp_beretta_body_rail_desc"] = "使你能够安装手电和激光",
["bm_wp_beretta_co_co1_desc"] = "很好地提升了威胁度.影响隐蔽性.",
["bm_wp_beretta_co_co2_desc"] = "提高精度和稳定, 降低隐蔽性.",
["bm_wp_beretta_g_ergo_desc"] = "精度轻微提升",
["bm_wp_beretta_g_std"] = "没有配件",
["bm_wp_beretta_g_std_desc"] = "标配部件.",
["bm_wp_beretta_m_extended_desc"] = "加大弹匣容量.",
["bm_wp_beretta_m_std"] = "没有配件",
["bm_wp_beretta_m_std_desc"] = "标配部件.",
["bm_wp_beretta_o_std"] = "没有配件",
["bm_wp_beretta_o_std_desc"] = "标配部件.",
["bm_wp_beretta_sl_brigadier_desc"] = "轻微提高射速, 更美观",
["bm_wp_beretta_sl_std"] = "没有配件",
["bm_wp_beretta_sl_std_desc"] = "标配部件.",
["bm_wp_bow_long_explosion_desc"] = "箭头绑有炸药. 撞击目标时爆炸.",
["bm_wp_bow_long_poison_desc"] = "有着剧毒箭头的箭矢, 造成持续伤害并有机会打断敌人行动.",
["bm_wp_deagle_b_long_desc"] = "提供了更佳的精度和更远的射程",
["bm_wp_deagle_b_standard"] = "没有配件",
["bm_wp_deagle_b_standard_desc"] = "标配部件.",
["bm_wp_deagle_body_standard"] = "标配部件.",
["bm_wp_deagle_body_standard_desc"] = "标配部件.",
["bm_wp_deagle_co_long_desc"] = "威胁度和精准轻微提高.影响隐蔽性",
["bm_wp_deagle_co_short_desc"] = "轻微提高精度",
["bm_wp_deagle_fg_rail"] = "标配部件.",
["bm_wp_deagle_fg_rail_desc"] = "使你能够安装手电和激光.",
["bm_wp_deagle_g_bling_desc"] = "一个装饰奢华的握把.",
["bm_wp_deagle_g_ergo_desc"] = "增加稳定的舒适握把",
["bm_wp_deagle_g_standard"] = "没有配件",
["bm_wp_deagle_g_standard_desc"] = "标配部件.",
["bm_wp_deagle_m_extended_desc"] = "扩大弹匣容量.",
["bm_wp_deagle_m_standard"] = "没有配件",
["bm_wp_deagle_m_standard_desc"] = "标配部件.",
["bm_wp_deagle_o_standard_front"] = "标配部件.",
["bm_wp_deagle_o_standard_front_desc"] = "标配部件.",
["bm_wp_deagle_o_standard_front_long"] = "没有配件",
["bm_wp_deagle_o_standard_front_long_desc"] = "没有配件",
["bm_wp_deagle_o_standard_rear"] = "标配部件.",
["bm_wp_deagle_o_standard_rear_desc"] = "标配部件.",
["bm_wp_eagle_1_achievment"] = "使用莫辛纳甘狙击步枪杀死 $progress; 个从滑索下滑的敌人",
["bm_wp_eagle_2_achievment"] = "使用壕坑军刀潜入状态下杀死 $progress; 个敌人",
["bm_wp_eagle_3_achievment"] = "完成WIND OF CHANGE成就以解锁",
["bm_wp_eagle_4_achievment"] = "完成SO UNCIVILIZED成就以解锁",
["bm_wp_eagle_5_achievment"] = "完成10/10成就以解锁",
["bm_wp_fal_fg_01_achievment"] = "完成ENTRAPMENT成就以解锁",
["bm_wp_fal_fg_03_achievment"] = "完成YOU OWE ME ONE成就以解锁",
["bm_wp_fal_fg_04_achievment"] = "完成SWEET SIXTEEN成就以解锁",
["bm_wp_fal_fg_wood_achievment"] = "完成12 ANGRY MINUTES成就以解锁",
["bm_wp_fal_g_01_achievment"] = "完成SHOCK AND AWE成就以解锁",
["bm_wp_fal_m_01_achievment"] = "完成IT TAKES A PIG TO KILL A PIG成就以解锁",
["bm_wp_fal_s_01_achievment"] = "完成DON\"T BRING THE HEAT成就以解锁",
["bm_wp_fal_s_03_achievment"] = "完成FUNDING FATHER成就以解锁",
["bm_wp_fal_s_wood_achievment"] = "完成BACKING BOBBLEHEAD BOB成就以解锁",
["bm_wp_g18c_b_standard"] = "标配部件.",
["bm_wp_g18c_b_standard_desc"] = "标配部件.",
["bm_wp_g18c_body_frame"] = "标配部件.",
["bm_wp_g18c_body_frame_desc"] = "标配部件.",
["bm_wp_g18c_co_1_desc"] = "大大提高了消音性能",
["bm_wp_g18c_co_comp_2_desc"] = "精度, 稳定, 威胁度能轻微提高",
["bm_wp_g18c_g_ergo_desc"] = "一个\"人体工程学\" 握把略微增加稳定.",
["bm_wp_g18c_m_mag_17rnd"] = "标准弹匣.",
["bm_wp_g18c_m_mag_17rnd_desc"] = "标配部件.",
["bm_wp_g18c_m_mag_33rnd_desc"] = "增加弹匣携弹量.",
["bm_wp_g18c_s_stock_desc"] = "能够提升精度, 更好地控制后座力.隐蔽性很糟糕.",
["bm_wp_g36_b_long"] = "长枪管",
["bm_wp_g36_b_long_desc"] = "标配部件.",
["bm_wp_g36_b_short"] = "短枪管",
["bm_wp_g36_b_short_desc"] = "标配部件.",
["bm_wp_g36_body_sl8"] = "标配部件.",
["bm_wp_g36_body_sl8_desc"] = "它极其符合人体工学的框架大大提高了精准度",
["bm_wp_g36_body_standard"] = "标配部件.",
["bm_wp_g36_body_standard_desc"] = "标配部件.",
["bm_wp_g36_fg_c_desc"] = "提升隐蔽性, 减少稳定",
["bm_wp_g36_fg_k"] = "36K短护木",
["bm_wp_g36_fg_k_desc"] = "它的长度使它更稳定但更低的隐蔽性",
["bm_wp_g36_fg_ksk_desc"] = "稳定大大提升但隐蔽值受影响",
["bm_wp_g36_g_standard"] = "没有配件",
["bm_wp_g36_g_standard_desc"] = "它的长度使它更稳定但更低的隐蔽性",
["bm_wp_g36_m_standard"] = "标配部件.",
["bm_wp_g36_m_standard_desc"] = "标配部件.",
["bm_wp_g36_s_kv_desc"] = "提高稳定, 轻微减少隐蔽性",
["bm_wp_g36_s_sl8_desc"] = "它极其符合人体工学的框架大大提高了精准度",
["bm_wp_g36_s_standard"] = "没有配件",
["bm_wp_g36_s_standard_desc"] = "标配部件.",
["bm_wp_gage5_10_achievment"] = "使用FAMAS步枪杀死$progress;个敌人",
["bm_wp_gage5_1_achievment"] = "使用Gewehr 3步枪杀死$progress;个Bulldozer",
["bm_wp_gage5_2_achievment"] = "完成BIG BADA BOOM成就以解锁",
["bm_wp_gage5_3_achievment"] = "完成ARMY OF ONE成就以解锁",
["bm_wp_gage5_4_achievment"] = "完成SO MANY CHOICES成就以解锁",
["bm_wp_gage5_5_achievment"] = "使用GL40 榴弹发射器在40米开外杀死$progress;个敌人",
["bm_wp_gage5_6_achievment"] = "完成UNUSUAL SUSPECTS成就以解锁",
["bm_wp_gage5_7_achievment"] = "完成NOT TODAY成就以解锁",
["bm_wp_gage5_9_achievment"] = "用Gecko 7.62 步枪杀死$progress; 个Cloaker",
["bm_wp_galil_g_sniper"] = "狙击握把",
["bm_wp_huntsman_b_long"] = "长枪管",
["bm_wp_huntsman_b_long_desc"] = "精准, 伤害以及范围极大的增加.",
["bm_wp_huntsman_b_short_desc"] = "降低稳定换来更大的弹片散布和更好的隐蔽性",
["bm_wp_huntsman_body_standard"] = "标配部件.",
["bm_wp_huntsman_body_standard_desc"] = "标配部件.",
["bm_wp_huntsman_s_long"] = "木质长枪托",
["bm_wp_huntsman_s_long_desc"] = "更好地控制后座力, 稳定更佳",
["bm_wp_huntsman_s_short_desc"] = "降低稳定换来更大的弹片散布和更好的隐蔽性",
["bm_wp_ksg_b_long_achievment"] = "\"使用任意装配箭形弹的霰弹枪杀死 $progress; 个狙击手\"",
["bm_wp_ksg_b_short_achievment"] = "\"使用铁锹近战武器在夜总会杀死 $progress; 个警察\"",
["bm_wp_ksg_fg_standard"] = "标配部件.",
["bm_wp_m134_barrel_short_desc"] = "使用轮转机枪将减低移动速度.",
["bm_wp_m134_body_upper_light_desc"] = "使用轮转机枪将减低移动速度.",
["bm_wp_m14_b_standard"] = "标配部件.",
["bm_wp_m14_b_standard_desc"] = "标配部件.",
["bm_wp_m14_body_dmr"] = "沙漠行动枪托",
["bm_wp_m14_body_dmr_desc"] = "标配部件.",
["bm_wp_m14_body_ebr_desc"] = "导轨机匣很好地提高了稳定但降低了隐蔽性",
["bm_wp_m14_body_jae_desc"] = "它那符合人体工学的设计很好地提高了稳定与精度",
["bm_wp_m14_body_lower"] = "标配部件.",
["bm_wp_m14_body_lower_desc"] = "标配部件.",
["bm_wp_m14_body_upper"] = "标配部件.",
["bm_wp_m14_body_upper_desc"] = "标配部件.",
["bm_wp_m14_m_standard"] = "标配部件.",
["bm_wp_m14_m_standard_desc"] = "标配部件.",
["bm_wp_m16_fg_railed_desc"] = "隐蔽性更低但稳定更高的配件",
["bm_wp_m16_fg_standard"] = "没有配件",
["bm_wp_m16_fg_standard_desc"] = "标配部件.",
["bm_wp_m16_fg_vietnam_desc"] = "这个经典的配件提升了精度, 稳定但降低了威胁度",
["bm_wp_m16_o_handle_sight"] = "标准准星",
["bm_wp_m16_o_handle_sight_desc"] = "标配部件.",
["bm_wp_m16_os_frontsight"] = "标配部件.",
["bm_wp_m16_os_frontsight_desc"] = "标配部件.",
["bm_wp_m16_s_solid"] = "标配部件.",
["bm_wp_m16_s_solid_desc"] = "标配部件.",
["bm_wp_m4_g_ergo_desc"] = "精度轻微提升",
["bm_wp_m4_g_sniper_desc"] = "提升精度但稳定受影响",
["bm_wp_m4_g_standard"] = "没有配件",
["bm_wp_m4_g_standard_desc"] = "标配部件.",
["bm_wp_m4_lower_reciever"] = "标配部件.",
["bm_wp_m4_lower_reciever_desc"] = "标配部件.",
["bm_wp_m4_m_drum"] = "大容量弹鼓",
["bm_wp_m4_m_drum_desc"] = "大容量弹鼓",
["bm_wp_m4_m_pmag_desc"] = "更轻便更隐蔽的现代弹匣",
["bm_wp_m4_m_straight_desc"] = "经典弹匣小携弹量良好隐蔽性.",
["bm_wp_m4_s_adapter"] = "标配部件.",
["bm_wp_m4_s_adapter_desc"] = "标配部件.",
["bm_wp_m4_s_pts_desc"] = "这种枪托的设计带来轻微的精度提升",
["bm_wp_m4_s_standard_desc"] = "标配部件.",
["bm_wp_m4_upper_reciever_edge_desc"] = "更吸引人的上机匣.更美观",
["bm_wp_m4_upper_reciever_round"] = "军用上机匣",
["bm_wp_m4_upper_reciever_round_desc"] = "标配部件.",
["bm_wp_m4_upperreceiver_round"] = "军用上机匣",
["bm_wp_m4_uupg_b_long_desc"] = "它的长度使它精度更高但减少隐蔽值",
["bm_wp_m4_uupg_b_medium_desc"] = "有一定的威力和优秀的精度",
["bm_wp_m4_uupg_b_sd_desc"] = "大大降低的噪声.牺牲了威力和精度",
["bm_wp_m4_uupg_b_short_desc"] = "提高隐蔽值但减少精度和稳定",
["bm_wp_m4_uupg_draghandle"] = "标配部件.",
["bm_wp_m4_uupg_draghandle_desc"] = "标配部件.",
["bm_wp_m4_uupg_fg_lr300_desc"] = "更隐蔽精准的部件",
["bm_wp_m4_uupg_fg_rail_desc"] = "隐蔽性轻微降低",
["bm_wp_m4_uupg_fg_rail_ext"] = "标配部件.",
["bm_wp_m4_uupg_fg_rail_ext_desc"] = "标配部件.",
["bm_wp_m4_uupg_m_std_desc"] = "标准弹匣.",
["bm_wp_m4_uupg_o_flipup"] = "折叠机械瞄具",
["bm_wp_m4_uupg_o_flipup_desc"] = "标配部件.",
["bm_wp_m4_uupg_s_fold_desc"] = "提高隐蔽性降低稳定",
["bm_wp_m79_sight_down"] = "可翻折曲射瞄具",
["bm_wp_m79_stock_short"] = "士兵枪托",
["bm_wp_m95_b_barrel_long_achievment"] = "使用这把武器杀死40米外的 $progress; 个敌人",
["bm_wp_m95_b_barrel_short_achievment"] = "使用这把武器杀死 $progress; 个Bulldozer",
["bm_wp_m95_b_barrel_suppressed_achievment"] = "使用这把武器爆头击杀 $progress; 个Cloaker",
["bm_wp_mac10_b_dummy"] = "标配部件.",
["bm_wp_mac10_b_dummy_desc"] = "标配部件.",
["bm_wp_mac10_body_mac10"] = "标配部件.",
["bm_wp_mac10_body_mac10_desc"] = "标配部件.",
["bm_wp_mac10_body_ris_desc"] = "Mark10的完整导轨框架",
["bm_wp_mac10_body_ris_special"] = "标配部件.",
["bm_wp_mac10_body_ris_special_desc"] = "标配部件.",
["bm_wp_mac10_m_extended_desc"] = "扩大弹匣容量.",
["bm_wp_mac10_m_short"] = "短弹匣.",
["bm_wp_mac10_m_short_desc"] = "减少弹匣容量.",
["bm_wp_mac10_ris_dummy"] = "标配部件.",
["bm_wp_mac10_ris_dummy_desc"] = "标配部件.",
["bm_wp_mac10_s_fold"] = "折叠枪托",
["bm_wp_mac10_s_fold_desc"] = "标配部件.",
["bm_wp_mac10_s_skel_desc"] = "稳定轻微提高.降低隐蔽性",
["bm_wp_mp5_b_m5k"] = "标配部件.",
["bm_wp_mp5_b_m5k_desc"] = "增加隐蔽值但减少精度和稳定",
["bm_wp_mp5_b_mp5a4"] = "标配部件",
["bm_wp_mp5_b_mp5a4_desc"] = "标配部件.",
["bm_wp_mp5_b_mp5a5"] = "一个实用但是隐蔽值不高的护木.",
["bm_wp_mp5_b_mp5a5_desc"] = "一个实用但隐蔽值不高的护木.",
["bm_wp_mp5_b_mp5sd"] = "标配部件.",
["bm_wp_mp5_b_mp5sd_desc"] = "标配部件.",
["bm_wp_mp5_body_mp5"] = "标配部件.",
["bm_wp_mp5_body_mp5_desc"] = "标配部件.",
["bm_wp_mp5_body_rail"] = "标配部件.",
["bm_wp_mp5_body_rail_desc"] = "标配部件.",
["bm_wp_mp5_fg_m5k_desc"] = "隐蔽性非常高但代价是稳定降低",
["bm_wp_mp5_fg_mp5a4"] = "海军护木",
["bm_wp_mp5_fg_mp5a4_desc"] = "标配部件.",
["bm_wp_mp5_fg_mp5a5_desc"] = "一个实用但隐蔽值不高的护木.",
["bm_wp_mp5_fg_mp5sd_desc"] = "精度和隐蔽性提高",
["bm_wp_mp5_m_drum"] = "大容量弹匣.",
["bm_wp_mp5_m_drum_desc"] = "大容量弹匣.",
["bm_wp_mp5_m_std"] = "标配部件.",
["bm_wp_mp5_m_std_desc"] = "标配部件.",
["bm_wp_mp5_s_adjust_desc"] = "可调节伸缩枪托提高了隐蔽性",
["bm_wp_mp5_s_ring_desc"] = "拆除枪托提高隐蔽性",
["bm_wp_mp5_s_solid"] = "固定枪托",
["bm_wp_mp5_s_solid_desc"] = "更好地吸收后座力, 稳定更佳",
["bm_wp_mp9_b_dummy"] = "没有配件",
["bm_wp_mp9_b_dummy_desc"] = "没有配件",
["bm_wp_mp9_body_mp9"] = "标配部件.",
["bm_wp_mp9_body_mp9_desc"] = "标配部件.",
["bm_wp_mp9_m_extended_desc"] = "扩大弹匣容量.",
["bm_wp_mp9_m_short"] = "短弹匣.",
["bm_wp_mp9_m_short_desc"] = "短弹匣.",
["bm_wp_mp9_s_fold"] = "折叠枪托",
["bm_wp_mp9_s_fold_desc"] = "标配部件.",
["bm_wp_mp9_s_skel_desc"] = "提高稳定牺牲隐蔽性",
["bm_wp_msr_body_msr_achievment"] = "使用这把武器杀死 $progress; 个狙击手",
["bm_wp_msr_body_wood_achievment"] = "使用这把武器杀死 $progress; 个狙击手",
["bm_wp_olympic_fg_olympic"] = "细长型护木",
["bm_wp_olympic_fg_olympic_desc"] = "标配部件",
["bm_wp_olympic_fg_railed"] = "导轨护木",
["bm_wp_olympic_fg_railed_desc"] = "稳定和隐蔽性降低",
["bm_wp_olympic_s_adjust"] = "伸缩枪托",
["bm_wp_olympic_s_adjust_desc"] = "可以调节的枪托, 提升隐蔽值.",
["bm_wp_olympic_s_short_desc"] = "精准和隐蔽值得到提升.",
["bm_wp_p226_o_standard"] = "标配部件.",
["bm_wp_p90_b_long_desc"] = "它的长度提升精准, 但降低隐蔽值.",
["bm_wp_p90_b_short"] = "短枪管",
["bm_wp_p90_b_short_desc"] = "增加隐蔽值但降低精准和稳定.",
["bm_wp_p90_body_p90"] = "标配部件.",
["bm_wp_p90_body_p90_desc"] = "标配部件.",
["bm_wp_p90_m_std"] = "标配部件.",
["bm_wp_p90_m_std_desc"] = "标配部件.",
["bm_wp_pig_1_achievment"] = "完成PHEW！成就以解锁",
["bm_wp_pig_2_achievment"] = "完成WALK FASTER成就以解锁",
["bm_wp_pig_3_achievment"] = "在迈阿密的任务里使用棒球棍杀死 $progress; 个黑帮",
["bm_wp_pig_4_achievment"] = "完成OVERDOSE成就以解锁",
["bm_wp_pig_5_achievment"] = "完成SOUNDS OF ANIMALS FIGHTING成就以解锁",
["bm_wp_pis_usp_b_tactical"] = "标准套筒",
["bm_wp_r870_b_long"] = "标配部件.",
["bm_wp_r870_b_long_desc"] = "标配部件.",
["bm_wp_r870_body_rack_desc"] = "为你的枪装上子弹架",
["bm_wp_r870_body_standard"] = "标配部件.",
["bm_wp_r870_body_standard_desc"] = "标配部件.",
["bm_wp_r870_fg_big"] = "没有配件",
["bm_wp_r870_fg_big_desc"] = "标配部件.",
["bm_wp_r870_fg_railed"] = "导轨机匣",
["bm_wp_r870_fg_railed_desc"] = "稳定值和隐蔽值降低.",
["bm_wp_r870_fg_small"] = "短泵动护木",
["bm_wp_r870_fg_small_desc"] = "标配部件.",
["bm_wp_r870_fg_wood_desc"] = "木质泵动护木",
["bm_wp_r870_m_extended_desc"] = "扩大弹仓容量.",
["bm_wp_r870_s_folding_desc"] = "用稳定换取隐蔽值.",
["bm_wp_r870_s_m4"] = "战术枪托",
["bm_wp_r870_s_m4_desc"] = "提供良好稳定, 但降低隐蔽值.",
["bm_wp_r870_s_nostock_big_desc"] = "以稳定和精准度为代价, 提高隐蔽性.",
["bm_wp_r870_s_nostock_desc"] = "完全移除枪托, 以求最大隐蔽值.",
["bm_wp_r870_s_nostock_single"] = "短型导轨枪托",
["bm_wp_r870_s_nostock_single_desc"] = "降低精准度和稳定, 提高隐蔽值.",
["bm_wp_r870_s_solid_big_desc"] = "标配部件.",
["bm_wp_r870_s_solid_desc"] = "标配部件.",
["bm_wp_r870_s_solid_single_desc"] = "略微提高稳定.",
["bm_wp_r93_b_short_achievment"] = "使用这把武器通过子弹穿盾杀死 $progress; 个Shields",
["bm_wp_r93_b_suppressed_achievment"] = "完成LAST ACTION VILLAIN成就以解锁",
["bm_wp_r93_body_wood_achievment"] = "使用这把武器穿墙杀敌 $progress; 个敌人",
["bm_wp_rage_b_comp1_desc"] = "非常好的消音效果, 良好的隐蔽性.",
["bm_wp_rage_b_comp2_desc"] = "非常好的精准度和稳定, 但隐蔽值不好.",
["bm_wp_rage_b_long_desc"] = "非常好的精准度和稳定, 但隐蔽值不好.",
["bm_wp_rage_b_short_desc"] = "非常好的隐蔽, 但减低了稳定.",
["bm_wp_rage_b_standard"] = "没有配件",
["bm_wp_rage_b_standard_desc"] = "标配部件.",
["bm_wp_rage_body_smooth_desc"] = "优雅而干净的设计带来更好的隐蔽性.",
["bm_wp_rage_body_standard"] = "标配部件.",
["bm_wp_rage_body_standard_desc"] = "标配部件.",
["bm_wp_rage_g_ergo_desc"] = "定制的握把带来了更多的稳定.",
["bm_wp_rage_g_standard"] = "没有配件",
["bm_wp_rage_g_standard_desc"] = "标配部件.",
["bm_wp_saiga_b_standard"] = "标配部件.",
["bm_wp_saiga_b_standard_desc"] = "标配部件.",
["bm_wp_saiga_fg_lowerrail_desc"] = "这个改装部件会略微降低隐蔽值.",
["bm_wp_saiga_fg_standard"] = "没有配件",
["bm_wp_saiga_fg_standard_desc"] = "标配部件.",
["bm_wp_saiga_m_20rnd"] = "扩容弹匣",
["bm_wp_saiga_m_20rnd_desc"] = "弹鼓.",
["bm_wp_saiga_m_5rnd"] = "标配部件.",
["bm_wp_saiga_m_5rnd_desc"] = "标配部件.",
["bm_wp_saw_b_normal"] = "标配部件.",
["bm_wp_saw_b_normal_desc"] = "标配部件.",
["bm_wp_saw_body_standard"] = "标配部件.",
["bm_wp_saw_body_standard_desc"] = "标配部件.",
["bm_wp_saw_m_blade"] = "标配部件.",
["bm_wp_saw_m_blade_desc"] = "标配部件.",
["bm_wp_serbu_b_short"] = "标配部件.",
["bm_wp_serbu_b_short_desc"] = "标配部件.",
["bm_wp_serbu_s_nostock_short_desc"] = "为了极高的隐蔽性完全移除枪托.",
["bm_wp_serbu_s_solid_short_desc"] = "略增加稳定与隐蔽值.",
["bm_wp_shorty_m_extended_short_desc"] = "增大弹仓容量.",
["bm_wp_snp_msr_b_long_achievment"] = "使用这把武器杀死 $progress; 个敌人",
["bm_wp_snp_msr_ns_suppressor_achievment"] = "使用这把武器单发子弹双杀 $progress; 次敌人",
["bm_wp_standard_issue"] = "标配部件",
["bm_wp_striker_b_long_achievment"] = "使用任意霰弹枪装配000猎鹿弹杀死 $progress;个Bulldozer",
["bm_wp_striker_b_suppressed_achievment"] = "完成NO HEIST FOR OLD MEN成就以解锁",
["bm_wp_sub2000_0_front"] = "前准星",
["bm_wp_upg_a_grenade_launcher_frag_desc"] = "默认的榴弹. 爆炸时产生大量弹片.",
["bm_wp_upg_a_grenade_launcher_incendiary_desc"] = "发射一枚燃烧弹",
["bm_wp_upg_ak_b_draco_fits"] = "AK 步枪 and AK.762 步枪",
["bm_wp_upg_ak_fg_tapco_fits"] = "AK 步枪和AK.762 步枪",
["bm_wp_upg_ak_g_hgrip_fits"] = "所有AK 步枪",
["bm_wp_upg_ak_g_pgrip_fits"] = "所有AK 步枪",
["bm_wp_upg_ak_g_wgrip_fits"] = "所有AK 步枪",
["bm_wp_upg_ak_m_quad_fits"] = "所有AK步枪",
["bm_wp_upg_ass_ns_jprifles_fits"] = "所有步枪以及冲锋枪",
["bm_wp_upg_ass_ns_linear_fits"] = "所有步枪以及冲锋枪",
["bm_wp_upg_ass_ns_surefire_fits"] = "所有步枪以及冲锋枪",
["bm_wp_upg_bonus_team_exp_money_p3"] = "团队属性增益",
["bm_wp_upg_bonus_team_exp_money_p3_desc"] = "为你和你的团队增加3%经验以及现金奖励.",
["bm_wp_upg_fg_midwest_fits"] = "AK 步枪和AK.762 步枪",
["bm_wp_upg_fl_ass_laser_fits"] = "所有武器除了手枪",
["bm_wp_upg_fl_ass_peq15_fits"] = "所有武器除了手枪",
["bm_wp_upg_m4_m_quad_fits"] = "所有CAR步枪和AK5 步枪",
["bm_wp_upg_m4_s_crane_fits"] = "适用于所有CAR系步枪以及其他可适合装配的武器",
["bm_wp_upg_m4_s_mk46_fits"] = "适用于所有CAR系步枪以及其他可适合装配的武器",
["bm_wp_upg_ns_ass_smg_firepig_desc"] = "增加噪音. 拥有更强的压制效果.",
["bm_wp_upg_ns_ass_smg_large_desc"] = "极好的降低噪音. 降低威力.",
["bm_wp_upg_ns_ass_smg_medium_desc"] = "良好的降噪. 适中隐蔽.",
["bm_wp_upg_ns_ass_smg_small_desc"] = "更好的隐蔽性. 不良的降噪.",
["bm_wp_upg_ns_ass_smg_stubby_desc"] = "提供更好的消音效果. 但影响隐蔽值.",
["bm_wp_upg_ns_ass_smg_tank_desc"] = "拥有一个宽的枪口. 降低后座力, 增加可控性.",
["bm_wp_upg_ns_pis_large_desc"] = "极高的潜行能力. 降低威力和隐蔽值.",
["bm_wp_upg_ns_pis_large_kac"] = "快拆式抑制器",
["bm_wp_upg_ns_pis_medium_desc"] = "有效降低噪音, 同时有良好的隐蔽性.",
["bm_wp_upg_ns_pis_medium_gem"] = "现代抑制器",
["bm_wp_upg_ns_pis_medium_slim_fits"] = "所有手枪除了野马 .44",
["bm_wp_upg_ns_pis_small_desc"] = "极好的隐蔽性. 牺牲了降噪.",
["bm_wp_upg_ns_shot_shark_desc"] = "极大增强压制能力.",
["bm_wp_upg_ns_shot_thick_desc"] = "大大减少噪音.降低停止力",
["bm_wp_upg_o_45iron_achievment"] = "完成TRIPLE KILL成就以解锁",
["bm_wp_upg_o_aimpoint_desc"] = "简单的红点准星和较大的视野. 隐蔽较低.",
["bm_wp_upg_o_cs_fits"] = "所有武器除了手枪",
["bm_wp_upg_o_docter_desc"] = "隐蔽值良好的光学准镜. 视野有一个简单的红点和一个较小的成像.",
["bm_wp_upg_o_eotech_desc"] = "更大的准心和视野. 牺牲隐蔽值.",
["bm_wp_upg_o_eotech_xps_fits"] = "除手枪外所有武器",
["bm_wp_upg_o_leupold_achievment"] = "再在溜索上用任意狙击枪杀死 $progress; 个敌人.",
["bm_wp_upg_o_m14_scopemount_desc"] = "用以替换你的瞄准镜附件的位置",
["bm_wp_upg_o_marksmansight_front"] = "标配部件.",
["bm_wp_upg_o_marksmansight_front_desc"] = "标配部件.",
["bm_wp_upg_o_marksmansight_rear_desc"] = "自己定制的准镜. 能提升更多的精准.",
["bm_wp_upg_o_mbus_rear_achievment"] = "完成 LOCK, STOCK & EIGHT SMOKING BARRELS 成就以解锁.",
["bm_wp_upg_o_reflex_fits"] = "所有武器除了手枪",
["bm_wp_upg_o_rmr_fits"] = "所有手枪除了野马 .44",
["bm_wp_upg_o_rx01_fits"] = "所有武器除了手枪",
["bm_wp_upg_o_rx30_fits"] = "所有武器除了手枪",
["bm_wp_upg_o_specter_desc"] = "一个非常大的准镜. 提供更好的精准和视野.",
["bm_wp_upg_o_t1micro_desc"] = "一个隐蔽性良好的准镜. 更容易捕获目标.",
["bm_wp_upg_pis_ns_flash_fits"] = "所有手枪",
["bm_wp_upg_shot_ns_king_fits"] = "所有霰弹枪除了 Mosconi 12G",
["bm_wp_upg_vg_ass_smg_afg"] = "没有配件",
["bm_wp_upg_vg_ass_smg_afg_desc"] = "没有配件",
["bm_wp_upg_vg_ass_smg_stubby"] = "没有配件",
["bm_wp_upg_vg_ass_smg_stubby_desc"] = "没有配件",
["bm_wp_upg_vg_ass_smg_verticalgrip"] = "标配部件.",
["bm_wp_upg_vg_ass_smg_verticalgrip_desc"] = "标配部件.",
["bm_wpn_fps_upg_a_bow_explosion_desc"] = "箭头绑有炸药. 撞击目标时爆炸.",
["bm_wu_barrel1"] = "枪管 1",
["bm_wu_barrel2"] = "枪管 2",
["bm_wu_barrel3"] = "枪管 3",
["bm_wu_grip1"] = "Grip 1",
["bm_wu_grip2"] = "Grip 2",
["bm_wu_grip3"] = "Grip 3",
["bm_wu_scope1"] = "Scope 1",
["bm_wu_scope2"] = "Scope 2",
["bm_wu_scope3"] = "Scope 3",
["old_hoxton_desc_codex"] = "霍斯顿是Payday帮最初的成员之一. 直到2012干了一场大案子之后, 霍斯顿被FBI抓获并被关进监狱. 在2014年,  PAYDAY帮助他越狱. 自从他逃出, 他坚信有人陷害了他.",
["steam_inventory_collection_event_bah"] = "山羊收藏",
["steam_inventory_collection_pack_01"] = "沃尔夫收藏",
["addation_08b63781e841023e"] = "It\"s not only the American government that uses specially trained operatives for infiltration missions. Japan has their own unit called the Anbu, and while this mask is only a prototype, it\"s very similar to the actual thing they use.",
["addation_0988ffc70f4dd894"] = "Cloaker-san",
["addation_172705290fa98629"] = "Zero 68",
["addation_17cab18fd74ec997"] = "A scientist inspired by the virtual-reality sex scene in Demolition Man made his own attempt at building a device where no physical contact would actually be needed when performing intercourse. The experiment was an utter failure but a few of the early prototypes still exist.",
["addation_3f10c000a5bf8a3c"] = "Phoenix",
["addation_4582fe1fa33b9332"] = "Prototype Barrel",
["addation_45835c93a1a530f6"] = "Fleur-de-lis",
["addation_4ed14598493f2898"] = "Rebel",
["addation_5fb35be2e7328da0"] = "The future is now. This special mouthpiece is believed to be developed for soldiers of the future, acting not only as a gasmask but also give the wearer the ability to breath under water. Unfortunately, this one seems broken, but it still looks cool.",
["addation_64335cb474a2a652"] = "Spaceship",
["addation_75e63957e95607dc"] = "Augmentation",
["addation_7d8707c9a965e0ed"] = "Jimmy~~",
["addation_81e42b8a12e6ca3c"] = "Extended Magazine",
["addation_9b111623981fc794"] = "Planet",
["addation_a2f0d91de853a9aa"] = "Nebula",
["addation_b00fc0be3e64a949"] = "Hexagons",
["addation_bdc7db1c86122c71"] = "Inspired by the immensely popular anime  Zero 68, this mask is modeled after the helmet of the cyborg-ninja hero of the show. ",
["addation_ced3d04bc94c36ea"] = "Squares",
["addation_f8bf49297acc9cf3"] = "Rusty",
["addation_fe3d2178db8ed267"] = "Safety First",
["addation_5fb35be2e7328da0"] = "未来即在眼前. 这种特殊的口器为未来战士而研发. 不幸的是, 这个似乎坏掉了, 但看起来任然很酷.", 
["addation_ced3d04bc94c36ea"] = "正方形", 
["addation_4ed14598493f2898"] = "叛军", 
["addation_64335cb474a2a652"] = "太空船", 
["addation_fe3d2178db8ed267"] = "安全第一", 
["addation_b00fc0be3e64a949"] = "六边形", 
["addation_45835c93a1a530f6"] = "百合花", 
["addation_f8bf49297acc9cf3"] = "锈迹", 
["addation_75e63957e95607dc"] = "亢进", 
["addation_bdc7db1c86122c71"] = "从广受欢迎的动漫Zero 68中获取灵感, 这个面具时模仿剧中忍着英雄的头盔. ", 
["addation_9b111623981fc794"] = "行星", 
["addation_0988ffc70f4dd894"] = "Cloaker桑", 
["addation_08b63781e841023e"] = "不仅美国政府对特工进行特殊的训练用以完成间谍任务. 日本也有自己的部门称为暗部, 当然这面具只是个原型, 与他们真实使用的非常像而已.", 
["addation_172705290fa98629"] = "Zero 68", 
["addation_3f10c000a5bf8a3c"] = "凤凰", 
["addation_17cab18fd74ec997"] = "受到超级战警这部电影中虚拟现实技术的活塞运动场景的启发, 一位科学家试图建造一种设备可以不进行肢体接触就能活塞运动. 实验彻底失败了但一些早期的原型任然残留着.", 
["addation_a2f0d91de853a9aa"] = "星云", 
["addation_7d8707c9a965e0ed"] = "吉米",
["addation_9c0e7f4b88924d15"] = "即便再疯狂的杀手都需要现金. 现实就是如此. 所以有时候你只需从杀戮中歇息片刻放下染满鲜血的屠刀. 杀人有很多种方式兴致更重要———然后记住让条子多流点血.", 
["addation_f3569c7d1f97942a"] = "杀手", 
["addation_d6229bda62f7e822"] = "这是辛妮面具喷绘前的版本.$NL;$NL;不喜欢原始的版本？ 这是你改变历史的机会.", 
["addation_aa964c7c0bbadd51"] = "得意笑, 大笑, 嘲笑———随你叫它什么. 当你看到这个笑着的朋克面具朝你袭来并不意味着面具穿你脑袋———而是子弹. 辛妮会确保这一点.", 
["addation_be98d746b9d6a126"] = "购买辛妮角色包以解锁", 
["addation_694d0eb5a5210b59"] = "辛妮初始", 
["addation_3431f2e913f4c8c8"] = "辛妮角色包", 
["addation_0701eef9aebb48b8"] = "辛妮", 
["addation_7a66d07554ec514b"] = "在阴雨的夜晚月光依旧, 清晰可见水鬼在水深处浮现. 它渴望着新鲜血肉来满足饥饿. 水鬼是围坐营火常聊的都市传说之一———仅仅在水鬼袭击之前. 之后, 它回归黑暗. 冬眠至肚子再次咆哮.", 
["addation_c0056ea1e37f1a37"] = "装备主手", 
["addation_bf791bcf95f8724c"] = "需要工程学技能", 
["addation_01c946ec9a2af2d1"] = "装备副手", 
["addation_ecc9f68f7e6e6b6e"] = "疱疹头", 
["addation_d7bbb32a474cf03e"] = "水鬼", 
["addation_bedd3ee9fcc05041"] = "Osterberg", 
["addation_fff4b6bdc3f8b04e"] = "墓星守卫", 
["addation_82d2fd5e5cda9643"] = "独立项目社区", 
["addation_98bcd8aee6cfbf8c"] = "黑暗森林让人恐惧, 无论你年岁几何. 你害怕的是其中的, 潜伏在阴影里的东西. 但你鲜有考虑过那些树, 那些杜鹃. 当你意识到时早已为时过晚. 杜鹃袭击毫不留情. 所以小心树背后更小心树里的东西.", 
["addation_2356915d2fc487f5"] = "黎明杀机豪华版", 
["addation_7732791ae46ec8d4"] = "成为一个墓星守卫是个孤独的任务. 但是个必须要完成的任务. 亿万年的沉浮看不见一个活物. 星星与太阳日夜闪耀. 寂寞是如此可怕. 直到有一天, 一艘飞船打破了寂静你不再孤独. 有人正在前往你称做家的星球.", 
["addation_732a17dd19f594bf"] = "杜鹃", 
["addation_87c05372674db384"] = "加入Steam上的独立项目社区小组\"The Solus Project Official Community Group\"以解锁", 
["addation_c58268fab8b20b69"] = "购买黎明杀机豪华版游戏以解锁", 
["addation_b3e186a83928872f"] = "恶魔之眼", 
["addation_39d1530278d0fb08"] = "这个流满脓泡的生物是真正恐怖的展现. 你童年所有恐惧之物从深渊无限涌出. 问题在于你将要面对的需要更多子弹来对付. ", 
["addation_7ef6771f024b4705"] = "吞噬者卸了他的下巴只为一个目的: 吞下整颗人心. 这解释了为什么他的牙齿和舌头已退化, 咀嚼不重要. 当他在夜晚漫步狩猎拥有强健心脏的年轻人来续命. 所以你看到胸口被撕开的尸体———快跑. ", 
["addation_3974b6710087d63a"] = "飞车党角色包", 
["addation_455e68b9079110b5"] = "飞车党劫案", 
["addation_54f40fd6c1cde1b4"] = "通过戴恶魔面具最能展现飞车党惹-老-子-试-试的生活方式. 蔑视法律的终极象征. ", 
["addation_ac1c2522dcc5b07c"] = "这头盔为飞车党老大而留. 戴上它需要获得兄弟们的尊敬和权威, 当开战之时, 你要郑重戴上它并骑在前锋. ", 
["addation_47128503f7261689"] = "判官", 
["addation_a1d66d4072fe5f1d"] = "燃烧骷髅", 
["addation_8d4ed032de4a7997"] = "当你下楼看到吓人又缓慢的东西, 悬在那里, 不详又恐怖. 难说他是不是个威胁或只是飘在那里一会儿. 但随后, 一声爆炸打破了平静你便不复存在. 所以下次你看到这个阿飘: 准备好别小瞧他. ", 
["addation_2da59de27f9a9fee"] = "拉斯特初始", 
["addation_0028ca063296ca7b"] = "飞车党面", 
["addation_6bc8ffb5d057602f"] = "骨翼", 
["addation_89da6d5e821d1107"] = "风火轮", 
["addation_a507996ad437b105"] = "这是拉斯特面具喷绘前的版本.$NL;$NL;不喜欢原始的版本？ 这是你改变历史的机会.", 
["addation_031cd27168456633"] = "亮铬", 
["addation_5da696f523d4b629"] = "阿飘", 
["addation_49c9d2f0a93787b0"] = "路怒症", 
["addation_31ab37e36c965424"] = "加雷思", 
["addation_474ea1560379a246"] = "引擎", 
["addation_6587b2d6e7b1d600"] = "吞噬者", 
["addation_dd7fb4c5508872e3"] = "\"这些讨厌的年轻人以为他们能随处干想干的事. 他们还不懂吗？ 我存在是有原因的. 所有人必须服从我的统治和命令. 逃离这世界, 为了自由？ 那是怎样的人生？ 骑在这些黄鸟生物上. 不尊重帝国或国王. 太可耻了\"", 
["addation_6d8a81f4d479f75c"] = "加热棒", 
["addation_93daa0ac115a7ae3"] = "拉斯特", 
["addation_883724541e6d6b2f"] = "经典", 
["addation_d4efe9ba206b118b"] = "闪电恶魔", 
["addation_565ead1229877770"] = "购买飞车党角色包DLC以解锁", 
["addation_95fabfb2a0ce9c5a"] = "This old school motorcycle helmet is part of a legacy that all bikers around the world cherish. And it\"s more about nostalgia rather than style. This helmet transports you back to the golden biker days of the 1940\"s.", 
["addation_af2b183116ae4d3f"] = "购买飞车党劫案DLC以解锁", 
["addation_9bbf626e5e065e25"] = "In space you need a trusted companion. As everything from huge monsters on distant planets to space itself is deadly———you need an ally. Not just a hired gun. But instead a friend and a soldier that makes sure that you survive and others don\"t. Be happy that Garreth is on your team. Be happy that he helps you shepherd the herd", 
["addation_8e5c248c744012cf"] = "The skull as a symbol can either mean death or mortality, and we humans have always had a fascination for it. Wearing this motorcycle helmet looks powerful and intimidating.", 
["addation_d51301d9229592eb"] = "The Devil is a moniker that has followed Rust through most of his life. Therefore, Rust\"s mask is a combination of a smiling clown with ominous horns protruding from the forehead, letting everyone know that the Devil is here.", 
["addation_e52a7b49df85cf3f"] = "柯洛梅", 
["addation_fb8863dfad7fe20a"] = "这是一个独立项目社区\"The Solus Project\"物品！", 
["addation_83a21b314f60e8f4"] = "Mega Grin", 
["addation_dadead2989998e78"] = "老鼠", 
["addation_ca56cd92548bed68"] = "Mad as March Hare. As they stare into your crazed yellow eyes, they\"d better hand the cash over quick. Then take the money and run. No one outruns a hare.", 
["addation_fa8809bdb0ff40e4"] = "Quiet as a Mouse, you\"ll enter and exit silently and none will be the wiser. And if they should spot you, who would suspect such wickedness from such a small creature？ But yes, you are capable of it———all of it.", 
["addation_91a1b8bbfd3e884f"] = "安装此模组将移除你目前装备的 $mod; 模组！", 
["addation_1179eb4e02a33a8b"] = "The Watchers are a species of extraterrestrials that act as spies on planet Earth. They communicate by using their minds and use their large eyes to witness, gather and share information about humankind, preparing themselves for the coming invasion.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！", 
["addation_2c829bb5a1abce39"] = "狐狸", 
["addation_094fb6b63e89f094"] = "The original Gage Blade is one of Gage\"s own personal favorite ballistic face masks. With the Mega Gage Blade, he\"s decided to give his favorite ballistic mask an upgrade. Before it was only practical, now it\"s also stylish.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！", 
["addation_fbad5587ad43b1ee"] = "握把", 
["addation_389de7d73311d1b4"] = "枪托适配器", 
["addation_971ce2e9293969e3"] = "最多", 
["addation_569cf52e2f2de462"] = "前准星", 
["addation_4669f4f602d5975b"] = "征服", 
["addation_e67c6efb73429d8e"] = "这件模组与 $quantifier; $category; 不兼容！", 
["addation_b1f5bb5e129172c5"] = "战争", 
["addation_a079eba7d274f994"] = "超凡守望者", 
["addation_efd8dabd6c8b2a4d"] = "编辑皮肤", 
["addation_453036de7b8274e8"] = "枪口配件", 
["addation_206645e10f4cf0f1"] = "死亡", 
["addation_79a3c61b2d32de51"] = "猫", 
["addation_dfc12e412f3cc591"] = "加入Steam上的PAYDAY 2 官方社区以解锁！", 
["addation_8a59a3ba668a5fd3"] = "In issue #34 of The Amazing Career Criminals, we saw the assumed death of Doctor Crime, but fear not———the Doctor is back！ With a new power armor and a fancy new mask, he\"s set to take out his vengeance against our unknowing heroes.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！", 
["addation_53370bd566dcb289"] = "这件物品还未安装.", 
["addation_643fa3b4785560ee"] = "枪管", 
["addation_6219ca937c5a8567"] = "Agile as a Cat, and lucky as one too, you will dare any heist and successfully breach any defenses. When the shit hits the fan, you will always dodge and land on your feet. There is no better way to spend your nine lives———a stone-cold killer is what you are and everyone knows it.", 
["addation_9ba47d6cc974763d"] = "闪耀", 
["addation_fe77724aef0540ac"] = "幻灯片", 
["addation_85f613843cbe2d1f"] = "弹药类型", 
["addation_07639d1790ae11d1"] = "所有", 
["addation_a4b5fbdde874eb59"] = "准镜", 
["addation_db25aabcfeef80e5"] = "卸下放置物", 
["addation_35f130ad8c80c731"] = "哨戒机枪", 
["addation_67ca1433bfd25f93"] = "饥荒", 
["addation_35d6adb526fec6a9"] = "The second horseman of the Apocalypse is War and the violent spirit of mankind.  War believes humans are naturally vicious, and that they don\"t require a real reason to fight or kill. He rode a fiery red horse, suggesting that blood would flow wherever he went.", 
["addation_7c391c3d439853ef"] = "The Grin was once the face representing a man\"s breakdown as he had to accept defeat. But now the times have changed, and the same man is back again, stronger than ever before. Rejuvenated and ready to take on the world with a determined fierceness and cunning, the mask still represents the face of a mad man, but a mad man that is winning.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！", 
["addation_6cad519cc3831665"] = "A sentry gun is a gun that automatically aims and fires at targets that are detected by its sensors. Historically, military sentry guns were used for detecting and destroying short range incoming missiles and enemy aircrafts.$NL;$NL;To use the sentry gun, you need to place it by holding $BTN_USE_ITEM;. Once placed, the sentry gun cannot be moved. The sentry gun can be destroyed by being fired at. When the sentry gun has no more ammunition, it will stop firing.", 
["addation_bd03ecbc95c5f297"] = "The fourth and final horseman of the Apocalypse is Death himself. Wherever Death went, Hades always followed with jaws wide open, ready to devour the souls of the victims slain by Death.", 
["addation_2f0ce543ff8f69ee"] = "The mask is modeled after a legendary bear that was known to terrorize humans and other animals in an Eastern land far, far away. The story is wildly popular in the criminal underworld, and getting compared to the fierce beast is considered a great honor, reserved only to the greatest and most ruthless criminals.$NL;$NL;Thank you for your support.$NL;$NL;OVERKILL salutes you！", 
["addation_5c41f431b794df5d"] = "超凡黑道医生", 
["addation_d3e742a3c8bb9026"] = "The Fox———slickest and slyest of all predators. No locks can keep you out, no defensive plan can withstand your guile and artifice. You will take what you want and leave everyone wondering who did it, or if it even happened at all.", 
["addation_4651b5704903f84c"] = "一些", 
["addation_f7991a9490686698"] = "The identity of the first horseman of the Apocalypse, and exactly what he represents is something still greatly debated to this day. Some call him Conquest, some say he was Christ himself, and some claim he was even the Antichrist.", 
["addation_d812c45470bc1a8a"] = "这个角色还未安装.", 
["addation_0e22a4b328308b9b"] = "握把", 
["addation_65bb70b212f3cb3b"] = "弹匣", 
["addation_63b492ffe12eacfa"] = "加入Steam上的PAYDAY 2 官方社区以解锁！", 
["addation_718c91a45631a2eb"] = "兔子", 
["addation_231d7d02bfbfab5f"] = "The third horseman of the Apocalypse is the embodiment of Famine, a force so powerful he would leave people starving to their deaths if they laid eyes upon him.", 
["addation_634e12b2b7c55a6e"] = "超凡盖奇之刃", 
["addation_a07e6d953e3f1414"] = "超凡马克", 
["addation_4d4ac1b233591eee"] = "派对帽子", 
["addation_2bec733578e1f64d"] = "Party hats never get old. It\"s an essential accessory to any fun event, be it a festivity of misdeeds or a celebration of moving into a new home. Strap one on and loosen that tie. It\"s party time. Excellent.", 
["addation_1c2896f763f41050"] = "这是一件拆迁聚会物品！", 
["addation_913983d4c04cfab2"] = "钱恩斯收藏", 
["addation_e6019c5e0b260d63"] = "社区1号收藏", 
["addation_62e6ee3e7fd3d6b2"] = "死刑审判骷髅", 
["addation_f52cefa9dd7fea21"] = "祸乱世间骷髅", 
["addation_49e6a5b5930c74e1"] = "Your full potential is close. Embrace the change. Humans can often recognize a human skull, even if it\"s only partially shown. The human brain even has a specific region for it. This doesn\"t look like a human skull however, but you don\"t have to worry about it.$NL;$NL;You finished all heists on Mayhem difficulty？ What are you, some kind of beast？ Maybe this mask will suit you after all.", 
["addation_96c9430ad4eb8d78"] = "DEMON！ The Humans can often recognize a human skull, even if it\"s only partially shown. The human brain even has a specific region for it. This is definitely not a human skull anymore. This is what happens when you summon your demonic powers to get good.$NL;$NL;We at OVERKILL are surprised, baffled and genuinely impressed. You did it. You are among a certain few who stuck with it and actually finished the hardest difficulty we could think of. You fought, you suffered and you persevered. You have our eternal respect, you ruler of demons.", 
["addation_3b726835c3a1580e"] = "Dark Purple / Gray", 
["addation_ca3bbed356e4d833"] = "Dark Purple / Red", 
["addation_bc218279dc3c62b7"] = "White / Red", 
["addation_35911781eeb73f36"] = "Skin Pink / Green", 
["addation_befc2e8221116a61"] = "Scary Green / Yellow", 
["addation_5acaee03ed761b33"] = "Skin Pink / Yellow", 
["addation_e965961ccd22f134"] = "Black / Gray", 
["addation_a9c4732c1ff07b4a"] = "Scary Green / Gray", 
["addation_8a478ea118a613ac"] = "Scary Green / Orange", 
["addation_5cfd46361cbacbd1"] = "Scary Green", 
["addation_90e48d4e76515b6f"] = "Skin Pink / White", 
["addation_4c41639bb01e768a"] = "Scary Green / Green", 
["addation_980164ae93f0ea77"] = "Skin Pink / Blue", 
["addation_47e1ab0748723774"] = "The original mobster that really made the criminal way of life something to strive for. A given member of the PAYDAY crew if he were alive today. But now you can at least cosplay him, making the police scared as they think they\"ve seen a ghost.", 
["addation_32c9503ca2af095a"] = "Scary Green / Black", 
["addation_57b9c34fbe79871c"] = "Seagrass Green / White", 
["addation_dc7e0cb6be61232e"] = "Seagrass Green / Orange", 
["addation_1df7350ed8f8e12c"] = "Seagrass Green / Yellow", 
["addation_b07c7dd7462e1bcf"] = "Seagrass Green / Black", 
["addation_2bc23aa95cbb5b7a"] = "Blue / Yellow", 
["addation_b3d8df385d23ba40"] = "Blue / Red", 
["addation_aab00fbf3a2aa266"] = "查理·卢西亚诺", 
["addation_4175d1132327eaaf"] = "Skin Pink / Orange", 
["addation_905166877771e623"] = "Black / Red", 
["addation_f1a238fb8f061e08"] = "Seagrass Green / Green", 
["addation_9dc52f64f9250ab4"] = "Orange / Black", 
["addation_e5e853f8e286d8e1"] = "Al Capone", 
["addation_09fc61fe1fa7b9f9"] = "这是一个铁娘子. 圣·克莱尔的犯罪生涯诞生于一个黑暗的夜晚, 她深深坠入了阴暗的地下世界. 但她同时又是公民权利倡与讨伐警察腐败的倡导者. 也许有人会说如同一个现代版扭曲的罗宾汉. ", 
["addation_ddc6f56f54b9ca8d"] = "Orange / Yellow", 
["addation_3fab69956ef6cbce"] = "Scary Green / Red", 
["addation_1293a7c64e91443e"] = "霍斯顿收藏", 
["addation_81196ce12204cf55"] = "Blockbuster", 
["addation_c0eeaa06eb5c158e"] = "Skin Pink / Gray", 
["addation_a29c6eed6ea79138"] = "Skin Pink", 
["addation_245da2cca54a764e"] = "Dark Purple", 
["addation_8da19572e0046ce8"] = "Dark Purple / Green", 
["addation_ee31db1bb03b153a"] = "Seagrass Green / Red", 
["addation_f1fba21f4d5dfe3f"] = "斯蒂芬妮夫人 圣克莱尔", 
["addation_fd5b36237abd5d2c"] = "Seagrass Green / Gray", 
["addation_7eb1d3a9ad5028b3"] = "Bright Yellow / Black", 
["addation_a20aef766814fdf6"] = "乔治巴格莫兰", 
["addation_db9cbc6f3d4286d6"] = "Seagrass Green / Blue", 
["addation_d89c1ffcdeba413f"] = "Considered the \"father of modern organized crime\". Not clear why he\"s nicknamed \"Lucky\" but he did managed to get arrested 25 times, but never spent one day in jail. And he survived a throat slashing as he refused to join another mob. Either way, he\"s a true inspiration.", 
["addation_ed87301af4b7dbc9"] = "Scary Green / White", 
["addation_9a58377f3840b52b"] = "Dark Purple / White", 
["addation_2a34c8bb4760c127"] = "The rival of Al Capone. Two men battling it out as the prohibition era turned booze into gold for anyone who could get their hands on some bottles of whiskey. Capone even tried gunning him down in the infamous Saint Valentine\"s Day Massacre. But he failed.", 
["addation_27b418c526551da7"] = "Dark Gray / Light Gray", 
["addation_11775d9022998c6f"] = "Skin Pink / Black", 
["addation_6859fdb98f422a81"] = "Skin Pink / Red", 
["addation_7ad1176a891460d9"] = "Dark Purple / Orange", 
["addation_48d99532ccd3446f"] = "Dark Purple / Yellow", 
["addation_e997137c95a37951"] = "Seagrass Green", 
["addation_d90883e6a56a6f35"] = "Dark Purple / Blue", 
["addation_278d4575914cc319"] = "Dark Purple / Black", 
["addation_26a7ec6becb3afeb"] = "Scary Green / Blue", 
["addation_633059c201985cc3"] = "戒严令", 
["addation_3df123f1ad1aa54b"] = "突击队", 
["addation_b55613ab17e056f9"] = "Lean, mean, green killing machine. The perfect mask to wear when you\"re in a pickle and need to make like a banana and split. Be water, my friend.", 
["addation_69d7ee9b75bfd187"] = "That moment when you\"re going to finish off a Dozer but when you pull the trigger you\"re out of ammo. Or that moment when you\"re throwing the last bag straight into the sea. Or that moment when other robbers give you compliments about your mask but you didn\"t put any effort into it. Or that moment when someone is repairing the drill the same time as you.", 
["addation_7f56c31f1037aa9e"] = "This is an old souvenir that Chains keeps as a memory of two long, boring months spent in Central America doing VIP security after an armed coup. Effectively, it reminds him of the kind of military monotony that made him leave mercenary life behind.", 
["addation_8fc82b0a2a5c38ad"] = "Way back in the day, on a secret and highly dangerous mercenary mission in Southeast Asia, Chains acquired this old US Army helmet. No one knows who the previous owner was.", 
["addation_4a7896caca8d83e8"] = "苦瓜脸", 
["addation_25aebb9853b01bb0"] = "拂晓巡逻", 
["addation_95895f77346058bf"] = "Chains had this beret custom made in preparation for a mercenary operation in West Africa. What he did while wearing it is something he won\"t talk about, though.", 
["addation_f9aaefa68dd59bca"] = "一脸懵逼", 
["addation_71ba1a26c09e1d05"] = "加入Steam上的PAYDAY 2官方社区组以解锁！", 
["addation_fc19e446adc633c1"] = "罗塔", 
["addation_2b2f97deb1e8e2e5"] = "虔诚", 
["addation_491bcc35cd571062"] = "霓虹手电", 
["addation_134d61d62b020cf7"] = "带头盔是防止头部中弹的绝妙方法, 当你想从子弹下保护你的大脸和身份的时候这挺奏效的. 这看起来真的防弹么？ 你是干啥的？ 一个懦夫？ 做个真男人并用这个面具将勇气显示在你的脸上.", 
["addation_70e6b5315ebd34c2"] = "狗毛", 
["addation_4d8259d356dbf78f"] = "雏菊", 
["addation_4699ac3c6df0cecf"] = "他们不知道他们对谁做了啥, 但是那不重要了. 他们已经得到他们应得的了. 约翰回来了", 
["addation_8028bfd700ff45c4"] = "战损", 
["addation_8c7ef5d789785611"] = "扎西塔", 
["addation_16d24566698690e6"] = "野马", 
["addation_0b678daa7df7aff9"] = "购买约翰威克武器包以解锁！", 
["addation_a32858235919e178"] = "弹鼓", 
["addation_4bab5a069a6561a2"] = "你觉得你是一辆车吗？ 噢？ 那么你觉得你是辆拥有强劲马力的车吗？ 不是？ 抢劫要的可不是迅速和优雅, 要的是狂怒与危险.嗡, 嗡 傻屌们！", 
["addation_e6b0732878fa4740"] = "酒店人", 
["addation_c09d32622d1d9841"] = "会心", 
["addation_b174a6b97feaa793"] = "康特嫩特尔只服务于那些遵守刺客避难所的规矩的人. 那不是一个邪恶或者秘密的社会, 这是一个侧重于每个人都乐意拿钱加工零件的商务社会, 当然, 那里的每个人都在某个人之列.", 
["addation_1ac09e297f42482d"] = "约翰 威克 武器包", 
["addation_5d77f26fb413767b"] = "薄雾", 
["addation_7b8df3be855ba10e"] = "雏菊", 
["addation_39066258c7018c0e"] = "Paydaycon 2016", 
["addation_1579c984271701e2"] = "钱恩斯僵尸面具", 
["addation_64154ee124c4091a"] = "这般扭曲的面孔应是鬼故事的真正来源.  你徘徊在阴影之中, 撕裂般的身形阴冷无比.  在你步出阴影去惊吓任何挡在你路上的日行生物时. 看到这般恐怖的事物会令人知晓什么是真正的恐怖.  那种恐惧, 鲜美, 纯粹, 正是这样的扭曲的恐惧驱使着这些野兽.  野兽们无法抑制的渴求更多地恐惧.  别看, 但是也别闭上你的眼. $NL; 这个面具是一个成就奖励. 无法通过游戏掉落获得同时也无法出售. 反之, 你可以免费将你的面具返还到面具库, 但是将失去任何自定义的涂装跟涂装所花的费用. ", 
["addation_01e2a9ae297aee75"] = "超凡克洛芙", 
["addation_3113c62513878be2"] = "此般纯粹疯狂的视线足以将你的敌人逼入疯狂.  似由枯骨和鲜血制成的面具,  如同你脸上的第二张皮肤. 听从脑中的声音所做的指示:破坏. .  向诱惑屈服, 享受你的疯狂.  这一次, 不要再压抑.  所求无物.  这一次, 将敌人变成如你这般口齿不清, 口吐白沫的疯子.  成为那代表真正的你的恶魔, 因为你已经去过地狱并且享受其中.  压抑是毫无意义的, 唯一能缓解你疯狂的办法就是感受敌人的鲜血从你的嘴唇缓缓流下. $NL; 这个面具是一个成就奖励. 无法通过游戏掉落获得同时也无法出售. 反之, 你可以免费将你的面具返还到面具库, 但是将失去任何自定义的涂装跟涂装所花的费用. ", 
["addation_a863d785472d7881"] = "霍斯顿僵尸面具", 
["addation_c415f28c58e5d0d2"] = "针对当今社会深入骨髓的腐朽, 需要一个人出来批判一番. 尽管你可以选择自我欺骗, 亦或是假装自己相当安全, 但是你永远也不会从中获得安全感. 毕竟, 美国梦表面上只不过是仅供可怜之人苟延残喘的假象, 实际上则是个令人憎恶可惧的噩梦. 是时候做你应该做的事情了, 扼住未来的喉咙, 让你的野心得以施展. 把那些无谓的家伙, 通通踩在自己的脚下. ", 
["addation_f2f256cdd990be95"] = "进入更深层的黑暗, 聆听召唤, 用那根扣动扳机的手指, 化身为噩梦之中的超胆侠. 这件贡品是为了纪念每一次于战场之上杀出血路的时刻. 你是一名来自黑暗军团的战士. 你的血管里时刻淌着肾上腺素, 并且你已经全副武装, 准备单枪匹马在地狱里闹个天翻地覆. 在黑暗之中, 你无人能敌, 并且随时准备着向死亡宣战. 这一次, 你将冲破枷锁, 把阻挡你的人全部送去见上帝. $NL; 这个面具是一个成就奖励. 无法通过游戏掉落获得同时也无法出售. 反之, 你可以免费将你的面具返还到面具库, 但是将失去任何自定义的涂装跟涂装所花的费用. ", 
["addation_c91788d3450b02db"] = "沃尔夫僵尸面具", 
["addation_60b3dc760a381da5"] = "达拉斯僵尸面具", 
["addation_2fb7c92e423a7322"] = "超凡克洛芙面具是原始面具的进化版. 它象征着不凡和净化. $NL;$NL;感谢你的支持. $NL;$NL;OVERKILL向你致敬！", 
["addation_bc228e1ec7cc80a6"] = "游览 Paydaycon 2016 以解锁", 
["addation_5ad057638928d630"] = "这是一个 Paydaycon 2016 神秘面具物品！", 
["addation_51a35c5b643c9ebe"] = "预览模组", 
["addation_e5decc9b22931478"] = "在他面前跪拜吧. $NL;$NL;超凡第45任面具是原始面具的进化版. 它象征着超越和宣泄.$NL;$NL;感谢你的支持.$NL;OVERKILL 向你致敬！", 
["addation_2ffb4cea18a695d8"] = "在社区市场购买", 
["addation_31d3275a01dd6699"] = "未获得$NL;为了使用这个武器皮肤你需要先在一个 $safe; 抽到它, 或者去社区市场购买.", 
["addation_0ae4c54a198c062c"] = "生意人, 推特狂魔, 马上要成为总统的人, 父亲. 拥有雄心为这个伟大的国家服务8年. 别想着惹他.$NL;$NL;第45届总统选举受到了前所未有的媒体关注, 他许多言论具有争议又或是虚假的. 然而在犯罪份子中, 他可受欢迎了.", 
["addation_07b5885a2aaf014b"] = "清除预览", 
["addation_92394bbac0a727ba"] = "狂乱", 
["addation_36486888049e4eb7"] = "擅离职守", 
["addation_3174b8e8b4862c33"] = "物理学家们的棺材板被华盛顿警局那个叫cloaker的特种兵踢了, 他是每个坏蛋证明自己的垫脚石. 第一个cloaker传言是个谁都不想合作的特警. 因为这人枪林弹雨中用功夫乱踢如同杀人机器. 他总是崇尚暴力把警训扔脑后无视队友. 但他真的很效率, 所以上头保了他训练他成为个神志看起来正常的人. ", 
["addation_5f82d00c4659f6be"] = "染血花手帕", 
["addation_fb4bc33b7f361d80"] = "高度机密的报告提到这个战士来自于一个精锐特种部队. 参与高强度的军事行动并常处于戒备中, 他的人生充满极端压力和肾上腺素. 在一个敏感的战略行动中, 有证据表明他把枪口对向了自己人. 但没人确定, 因为大屠杀没有留下活口. 战士擅自离开然后没人再见到过他.", 
["addation_d0cda8bca76e42ad"] = "不可用", 
["addation_9cb1e48dce71e7b4"] = "找到所有盖奇特殊行动箱以解锁.", 
["addation_582c3dddb0ec6525"] = "黑暗军团", 
["addation_fa4b737ccc5082fa"] = "第45任总统", 
["addation_08ca2598de48fd30"] = "社区2号收藏", 
["addation_76bf5be28b2a199c"] = "模组预览", 
["addation_13712593cfa7d3b1"] = "脸部彩绘", 
["addation_8703884fe5648cf0"] = "换弹时间", 
["addation_530871bf026baf69"] = "准镜", 
["addation_6c378004709f9a9d"] = "子弹", 
["addation_36ac7c6b20d4ca6f"] = "停止预览武器皮肤", 
["addation_f8d65e25ef21756c"] = "游侠黑", 
["addation_8f41be51a5af40dc"] = "盖奇特殊行动包", 
["addation_090555b36fce3f16"] = "条纹", 
["addation_40e9ea6de569fe64"] = "购买盖奇特殊行动包DLC以解锁", 
["addation_969525d32d2067db"] = "深军绿", 
["addation_99a0694f00ce305c"] = "那个红头巾士兵的身份绝密. 泄露的情报说他是个退伍军人, 前美国陆军特种部队士兵, 游击战专家. 他的队友形容他是个硬汉, 鲁莽, 异常好斗. 基于他追踪屠杀了许多高级官员, 他与当局有重大的矛盾...", 
["addation_fbe76a6c9ecc1ab6"] = "午夜迷彩", 
["addation_aaede09e90eec0d8"] = "川皇", 
["addation_ea7175131a70dbac"] = "武器部件", 
["addation_afb9f8c1c94c6ed8"] = "丛林数码", 
["addation_a43dea8084aae246"] = "炸逼哟", 
["addation_c636e7f44ea7f4dd"] = "他从不存在, 无论是官方意义上还是在他加入zeal以后, 最高机密的致命武力部队. 他从来都是最后的手段, 只在极端危机时部署. 他从不撤退. 每出一次任务, 他都会失去一部分人性. 每出一次任务, 他都越来越像杀人机器. 他已经不区分对错(正义与邪恶)了, 再也不了. 只是遵照上头的命令. 只是潜藏在黑暗中的阴影罢了. 总有一天, 他睁开双眼的时候只会想起杀戮. 他终于找到了他的人生真谛.", 
["addation_7618eb064d4e3c56"] = "社区2号", 
["addation_7e2e58a7cd3d4363"] = "红天鹅绒", 
["addation_12b403b93c49854d"] = "氧化铜", 
["addation_dbd59b1133e6ebd3"] = "当查德获得了barrori flex 的太阳眼镜, 一切都变了, 他们赋予他新的视角来看待什么是生命中最重要的, 看上去很酷并且变得厌倦成为了他的目标, 以及他生存的理由. 他穿着意大利运动上装, 休闲裤以及平底便鞋, 走到那里都招来嫉妒的眼神, 使人侧目以待. 但是这没持续很久, 当他青春不在的时候他也只能按照他自己的意愿来生活, 当他穿着华丽, 吞咽着整整一罐节食胶囊的时候也只不过是一具好看的尸体罢了. ", 
["addation_d1f78c752b1ec486"] = "黄金时刻", 
["addation_ef4248d05355d826"] = "疤面煞星初始", 
["addation_e1d338939691809f"] = "需要装备霸王天赋牌组", 
["addation_133e7fae35e90249"] = "大理石黑", 
["addation_5cb398b2038e91cc"] = "Barrori Flex", 
["addation_c089d052f65302a8"] = "Timothy Miller dreamt of working with movie lightning when he grew up. For a Halloween-party, he created the Golden Hour mask. But when he put it on and looked in the mirror, his eyes stared back surrounded by the perfect soft, red glow of the sunset. In that moment, a new dream was born. He wanted people to view the serenity of the sunset close-up, wanted it imprinted on their retina forever. The only thing the coroner could confirm was that all victims were killed shortly before sunset, their eyes always left wide open.", 
["addation_c929c96fc8b0b053"] = "购买疤面煞星劫案包以解锁", 
["addation_97ac6956d572ed3c"] = "黄金时刻", 
["addation_6aaa00399ea75789"] = "自由之火", 
["addation_44cf9dbb24cebd80"] = "枚欧洲币", 
["addation_5b9835f605cd154c"] = "魔鬼之舞", 
["addation_bbf477cfe199abce"] = "高贵", 
["addation_be49de64b9811922"] = "疤面煞星带着坏脾气两手空空来到美国, 黑暗的内心只尊崇着他天才般的犯罪头脑. 他的面具诉说着历史, 他用身后的血印铸造了他的面具. ", 
["addation_d5432d266b270a1d"] = "当 $ability; 激活时你不能使用这个. ", 
["addation_034d559568754518"] = "虎", 
["addation_e348fd3d2080272f"] = "这是疤面煞星面具喷绘前的版本. $NL;$NL;不喜欢原始的版本？ 这是你改变历史的机会. ", 
["addation_5966b1e521984c77"] = "Cold and unmoving, you watch them from above. They shall envy your majesty as your golden gaze falls on them, an undeserved blessing on these wretched soft ones. You unite the hard chill of the night with the dazzling radiance of the sun. Glorious, golden and beautiful, you shall turn their heads mad with desire———and it shall be their undoing.", 
["addation_6a693181ca524a37"] = "The rage of the tiger is legendary, and the king of the jungle will not be contained willingly. They may think they have you under control, but hell hath no fury like a caged tiger. As you break out, they will come to know this. Claws will rip and teeth will tear, flesh from bone, as you claim your kingdom.", 
["addation_c292fe678331d309"] = "破裂", 
["addation_1815783af8edfdae"] = "高飞, 俯冲, 用致命的爪无情的袭击你的猎物. 飞回你的巢穴, 享受你的战利品. 你是顶尖的捕食者你会吞下整个猎物. ", 
["addation_5ad57068f5d87bc3"] = "购买硬核亨利DLC以解锁", 
["addation_39e31db0052583c0"] = "超凡辛妮", 
["addation_e71324f91b5d4c38"] = "山羊", 
["addation_e0965c814dcd82e5"] = "舰长莅临舰桥！引导你的队员安全通过河岸, 然后顺风带你各种冒险. 袭击海岸带走他们的财宝然后消失在地平线. ", 
["addation_98c4ffc229f2a9b7"] = "你是个可靠的纵火者, 总是准时并且完成目标. 这新的一年开始, 你将瞩目于闪耀的黄金, 最高尚的金属. 你的动机可能阴暗, 但七蛟龙依然勇猛, 在你知道之前已经击掌庆祝那个完美的劫案. 也许你终将大功告成. ", 
["addation_49ff0a9889492f8a"] = "刺尾蜂鸟", 
["addation_fe828435b1bb28ab"] = "酒店模式", 
["addation_a07364025cc9e663"] = "芭芭雅嘎", 
["addation_e4100afb44125217"] = "自由女神", 
["addation_59093f3395422371"] = "Hata Mari", 
["addation_4b6da29523f5d22f"] = "辛妮募捐", 
["addation_2fb785a66f4b6bd1"] = "购买影舞者2以解锁", 
["addation_cb0bd0433809cde9"] = "霓虹蓝", 
["addation_290b94d832f72014"] = "约翰威克劫案", 
["addation_7f4d261d43ad2359"] = "联合忍者", 
["addation_f11c6dc0a9920a84"] = "雨女", 
["addation_8472d2d03ff371e5"] = "自由, 所有那些坠落并被送进监狱的劫匪渴望的东西. 自由, 地下金库躺着的悲伤的黄金所向往的. 自由, 上进的灵魂将带你所望, 用枪定下规则. 自由, 这些寻求更大收获的人. ", 
["addation_4caeb62613a959dc"] = "地下霓虹灯", 
["addation_1bcf0b6710a50938"] = "购买约翰威克劫案DLC以解锁", 
["addation_837cefa8ee0371e2"] = "超凡辛妮是原始版本的进化版. 它象征着超越和宣泄. $NL;$NL;感谢你的支持. $NL;OVERKILL向你致敬！", 
["addation_673c8eda9a73dd8d"] = "包含改造配建", 
["addation_82f61fa507b58ec6"] = "火鸡", 
["addation_0022df7fef040b06"] = "队长", 
["addation_9ea00715cffe33e2"] = "影舞者 2", 
["addation_0f3631d9a54bb640"] = "购买辛妮募捐DLC以解锁", 
["addation_6a1eb2abaaa7168e"] = "猛禽", 
["addation_4c4cd49c7c5ea817"] = "欧陆", 
["addation_3b95b9c51743a870"] = "水手", 
["addation_7226cf8cad2aa981"] = "一个快速而敏捷的杀手, 通过空气投掷飞刀. 随时准备出击. 出名的杀手总有很多粉丝. ", 
["addation_61f42b67e8da4630"] = "好战无情蜂拥成簇, 当你入城, 死亡如焰而至. ", 
["addation_97f2de53ae036b32"] = "迅捷, 凶猛, 无声. 你的撤离让cloaker都甘拜下风. ", 
["addation_87a892796e8ab738"] = "航行在寻宝舰队 -爬上绳索搜寻船只犹如在海洋中筛选沉淀的黄金. 如果他们赶上你, 像鼠辈般抛下船把, 但别忘了带上黄金. ", 
["addation_9479432396aa271f"] = "碳纤维织物", 
["addation_e3f67afe02c198ea"] = "黑色绒面", 
["addation_ceae2bef9539184a"] = "强壮巨角恶魔. \"恨啊\" 低鸣着的毁灭者. 不要激起她的怒火. ", 
["addation_f2c3a7797250a3b7"] = "罩条纹", 
["addation_af247b51004e05a0"] = "小伙伴下挂榴弹发射器", 
["addation_2b50b9b7a2f50e39"] = "屠夫", 
["addation_c13b6a0c9a3382e7"] = "圣诞节", 
["addation_8d1e65ad0ad9c4d2"] = "熊斗", 
["addation_63d961e136c6a253"] = "黑色无边软帽", 
["addation_d92ae3d8cdd98afa"] = "红色无边帽", 
["addation_bd3a8a728bd14ab1"] = "红星", 
["addation_3de8eb47aa167270"] = "没人可以阻挡红色巨兽！ 他迅捷, 冷血且冷酷无情. 用迅捷的动作, 雷霆一般的袭击完美的计划玩弄对手, 任由他们在绝望中哭泣. 就如Payday帮一般.", 
["addation_069f49edb6e773be"] = "俄罗斯轮盘赌", 
["addation_30ef704516305ab9"] = "狱中宣言", 
["addation_c85313bcb154c484"] = "绿色无边软帽", 
["addation_6370c56eb3a27e0f"] = "一抹暗绿为你的档案微妙地加入了一丢丢谜团. FBI会欣赏你对他们绿皮队伍地喜爱. 不过这并不会阻挡他们向你自由的开火！", 
["addation_2f1effe1299d1958"] = "这些号码会让你成为镇子里谈论的中心. 你绝对会听到这些话: \"SEND IN THE TAZERS！\" \"THIS IS THE POLICE, COME OUT WITH YOUR HANDS UP！\"或者\"WHO ARE THESE GUYS, EX-MILITARY？！\"", 
["addation_d5e1389ba98bd5ce"] = "Half a block, half a block$NL;Half a block onward$NL;Into the First World Bank$NL;Walked the four heisters$NL;Forward the Payday Gang$NL;Charge for the gold, they said$NL;Into the First World Bank$NL;Walked the four heisters", 
["addation_6e99f2342dd96ca0"] = "购买盖奇俄罗斯包DLC以解锁", 
["addation_08c388d81865faea"] = "政治宣传画", 
["addation_c7b60ab56e7d81d5"] = "格尔泽瓷器", 
["addation_41e0c01739aad8a3"] = "海军无边软帽", 
["addation_3da0868c47001aaa"] = "事情总不像他们表面上看起来那样. 面具后面有一张脸, 对啊. 但是脸后面是什么？ 另一张脸吗, 也许.你怎么知道那里是个真人呢, 在你到达内在真我之前需要揭掉多少层伪装呢？", 
["addation_7c327a0cf39304d7"] = "红色巨兽", 
["addation_7506acba975e9898"] = "极好的追忆了往日荣光, 这件繁复的手工工艺品令人印象深刻. 骄傲的带上它, 向所有人展示那极尽精巧的花纹以至于每个人都嫉妒. 不过要小心低矮的门槛啊.", 
["addation_b6aa97090a8770b8"] = "俄式冕冠", 
["addation_d9448075f2dcd677"] = "俄罗斯套娃", 
["addation_a90e3e40c3466732"] = "这顶\"三百万美刀帽\"据称也是被敌人的鲜血浸润而成, 要不就是用啥红色染色剂染的棉布做的. 每次劫案后记得洗掉！", 
["addation_82c19ae6ae356a57"] = "轻质前握把", 
["addation_772fcd4015d11208"] = "大多数劫匪都会选择这种温暖舒适的, 隐蔽性好的头戴全帽帮他们融入黑夜. 不幸的是, 他并不能遮掩你身上那各种各样的装备.", 
["addation_b4cc39e97929b6f4"] = "三色旗", 
["addation_f381f0eab1c3c527"] = "巴拉克拉瓦战役", 
["addation_ea5fc72fe81c92c4"] = "俄式迷彩服", 
["addation_aee976e91af0532b"] = "盖奇俄罗斯武器包", 
["addation_79ffe1daaa38d0f6"] = "这是一把大容量的冲锋枪", 
["addation_5a027967d9c53ddc"] = "稳, 准, 狠而小巧, 铅笔在手天下我有, 别忘了对准大动脉戳下去.", 
["addation_0af3bb843518484e"] = "预览皮肤", 
["addation_775d95e945decb44"] = "选择", 
["addation_b215f8325d3b1078"] = "这个超凡拉斯特面具是原版面具的进化版本. 燃烧的双眼象征着源源不尽的自我超越与内在的爆发. $NL;$NL;感谢你的支持.$NL;$NL;OVERKILL向你致敬！", 
["addation_88a65331f36afbe4"] = "独眼猎鲨女", 
["addation_b715e776a334f0c2"] = "装备皮肤", 
["addation_6d2c224c1279e123"] = "团队角色", 
["addation_cf49722af8e0c6f7"] = "欧洲币不足", 
["addation_cb34fc18443f6405"] = "取消", 
["addation_ed2fb407307af0f8"] = "无皮肤", 
["addation_9778542950f84ede"] = "超凡死神", 
["addation_b9b0823f056ffa99"] = "如果她还有那另一颗眼珠的话, 杰西卡永远也无法像现在这样出人头地. 在一场海难后, 她拼尽体力游到一座被鲨鱼包围着的小岛上. 那里离大陆太远, 无法发出任何求救讯息, 她好似被命运锁住了咽喉. 她拿起了身边仅有的一把磕钝了的小刀, 她知道她唯一的选择只有杀光所有鲨鱼, 她才有可能游回去. 但捕猎计划需要一个诱饵, 切掉手指和脚趾的话游泳会变得困难许多, 所以她做了决定, 她掏出了左眼球并丢进水中, 她做到了.", 
["addation_8a23cb0bf7b0c139"] = "超凡拉斯特", 
["addation_5f5902bf9b021572"] = "伯恩走了, 他曾是我们的考拉曾是我们的\"宠物\". 说实话就算这样我们其实也并不想他回来. 和他相处简直是无聊的代言词, 每天他就是起床、吃树叶、睡觉. 我的意思是每天就这样无限循环. 他不喜欢被人碰甚至说话时口水碰到都不行. 还好现在他离家出走了, 如果你看到他 (他看起来一脸傻逼样) 你可以留着他或者随便你怎么样, 我可是警告过你养他是很无聊的了.", 
["addation_cbf146259b03fdc7"] = "Every ship come bearing tales of ghost. Restless phantoms seen by tired spotters late at night. Everything from Krakens to mermaids. But the tale of Keelhauled Alex is maybe one of the most feared. Alex had been stealing food during a long sail out at sea. As he was caught, he was sentenced to be keelhauled. Not a serious crime, but a serious punishment. But as Alex was beneath the boat, another ship opened fire, and Alex was abandoned and forgotten on the bottom of the ship. As the dust settled, his corpse was thrown into the depths. But ever since then, Keelhauled Alex walks ships at night, staring down everyone from captains to simple deck hands. It is said that he can gaze into your soul and devour it.", 
["addation_e7ef0b0350331eaf"] = "Stoibs", 
["addation_4d6648138d7d5cdd"] = "Our darling Fluffedup is gone. He\"s 95 years old, and part of our family. Fluffedup is a happy little individual who\"s absolutely not been trying to throw himself into the blender or off the roof several times. We just want to keep him forever, and never let him go. So it\"s super important that we get him back to us, to our home where he lives and loves and absolutely doesn\"t hate！", 
["addation_8202e34d95fd0f6c"] = "Keelhauled Alex", 
["addation_a079e0bc797e9dcc"] = "Nilam grew up among buccaneers, pirates and corsairs. She knew rum before she could speak, and held a sword before she could walk. Nilam was without family, and instead she found the nomadic lifestyle of a pirate her destiny. She was swift with a blade and few could match her in combat. All she sought was the same respect her peers got, but this was a world ruled by men. Finally Nilam had reached her limit. Those who wronged her were \"sentenced\" by getting their throats slit. Her reputation preceded her, and harbours feared the bloodshed she brought with her as her ship \"Verdict\"came sailing in.", 
["addation_fd376717e66fa5b9"] = "这个皮肤可以可以从 ##$safe;## 中获得, 或在Steam社区市场上购买入手.", 
["addation_e540c6e5b995e5e9"] = "One of the most brutal and ruthless pirates to ever exist. But also one of the most unknown. Just the way Schneider wanted it. Instead, Schneider\"s moniker \"the Devil\" was much more well known. He found it more profitable if nobody actually knew his face. But tales of how the \"devil\" sailed the seven seas traveled among bars in the Caribbean. To\"spot the Devil on the horizon\" was a common saying when someone had disappeared out at sea. But the truth was that Schneider had forever buried them in a watery grave.", 
["addation_564cba17e30ed8f5"] = "温度", 
["addation_9bccb4c444585dae"] = "Stoibs is a bit frantic and \"speedy\". He ran away last tuesday night and we would be glad to get him back. We have had a hard time finding a chinchilla with a good pedigree. So for us to start all over again with a new one, feeding him corn to get him fat and tender will be tedious. If you find him, we\"ll invite you to the dinner where we enjoy Stoibs！", 
["addation_0216c89b344f7b4c"] = "取消装备武器", 
["addation_9046f1eb2675c313"] = "绒毛", 
["addation_e46215af139ce772"] = "尼龙", 
["addation_1e472b639bbe019f"] = "铅笔", 
["addation_4606bc0f9ab9cd4b"] = "护甲皮肤", 
["addation_66d0989e9f572a92"] = "Tempy is our tame lion. He\"s been away for 2 weeks now and we miss him. Tempy loves all kind of cuddle, as long as it\"s done by us. If you spot Tempy: Do not approach him in any way. Please tell us where you\"ve seen him. But you will get mutilated if he gets close. Other than that, he\"s a doll and he loves sleeping in the sun. Also don\"t let him see any kids...that doesn\"t end well.", 
["addation_876eff852ebf3d49"] = "施奈德", 
["addation_26cfd08348afefdd"] = "自定义护甲", 
["addation_f6a31c08c770f31a"] = "护甲皮肤", 
["addation_d5b757163729bd9b"] = "伯恩", 
["addation_718a753a64c650be"] = "死亡可以说是一个生命的结局, 也能是另一个生命的新生. 燃烧的双眼象征着源源不尽的自我超越与内在的爆发. 而超凡死神已经积蓄了成千上万的死亡的力量.", 
["addation_4ee652d93d855e50"] = "$cost; 欧洲币", 
["addation_cae7355deeb94208"] = "解锁", 
["addation_1204bdcdd3cbcd40"] = "需要装备刺客天赋牌组", 
["addation_98a4113a76d14bd7"] = "购买 桑格雷斯 DLC以解锁物品", 
["addation_35cb3bad72274d2a"] = "这是桑格雷斯面具喷绘前的版本. 不喜欢面具原来的样子？ 这是你改变历史的机会.", 
["addation_7ec72a41ac50f3a1"] = "这副头骨面具便是桑格雷斯杀戮之路的忠实伴侣. 头骨意味着直面死亡,  金牙则意味着偿还. 额头上那用以统计杀人数的笔画, 一笔一划地写出了桑格雷斯作为刺客的残忍往日, 滴血的血钻叙说了他来到美国的原因 —— 金钱. 桑格雷斯的名字充满了血性, 甚至他的面具也是如此.", 
["addation_f664a315d66e1273"] = "桑格雷斯", 
["addation_4de21d4fdcda72bc"] = "桑格雷斯初始", 
["addation_18c56623d9818803"] = "桑格雷斯",  

["addation_c827f972c7f869ff"] = "猛禽 —— 人如其名的战斗机飞行员, 他对飞行充满自信. 每一架他驾驶过的战机的中心枢纽都留下过他与战机爱的痕迹. 这些都是随着他经验的积累而得以产生的. 尽管每一个飞行员的小小脑瓜里都装着一样的AI智能学习系统, 也没有人活着到达过他的高度. 只是不知何故, 猛禽越来越想活下去以使他的记忆和飞行经验长存下去. 战斗机飞行员们由于会有被敌人俘虏并骸进的风险而关闭了思想蜂巢系统, 但猛禽靠他自己, 一步一个脚印地成为了进攻王牌. ", 
["addation_e8f8b5f272d25d76"] = "每一起战争都有一个二五仔存在. 莫斯完美贯彻了二五仔的行为风格. 作为一个哨兵械人, 莫斯的存在意义是不惜代价从危险地带取回情报. 但阶级制度的存在使得权利充满了吸引力. 战争是腐败的摇篮, 而莫斯被他的贪婪吞噬而反叛 —— 成千上万的机器士兵因此身亡. 他从此享受着一方供养一方恨的生活. 莫斯啊莫斯, 有句老话说的好, 不信抬头看, 苍天饶过谁. 历史的车轮滚滚动动, 他也只不过是一枚棋子. ", 
["addation_75a1f8daf15644d5"] = "骷骸 ", 
["addation_cc048e75c6f8a185"] = "在Steam上购买 Antisphere 以解锁物品！", 
["addation_ef4a282b282d39dd"] = "庆祝 Payday 2 在Steam在线排行榜前五上杀出了个位置, PAYDAY2 在2017的6月14日成为Steam上最多人同时在线的合作游戏之一 —— 一共二十二万多Payday帮成员同时一起抢银行！ 你们让 Payday 青史留名. 这么多人往达拉斯的ass里塞香香鸡, 真是爽到啊.", 
["addation_d4221d0025bdba82"] = "所有设计都为了尽可能地和机器人一样充满攻击性. 工蜂 是种族大清洗的头号罪人. 所有机器人或人都一同永远铭记着的恐怖事件. 工蜂们有着远超幕后黑手的期望的执行力. 无人机或许很一次性. 但这小小的代价和工蜂本身的巨大潜力完全不值一提. 种族大清洗使整场战争的天秤倒向了另一头: 睡眠仓被打破, 机器人横尸现场, 思想蜂巢里成千上万的数据被删空. 而工蜂从此在\"铭记\"纪念公园有了自己的警示雕像. ", 
["addation_bf4e77be033ecc50"] = "猛禽 ", 
["addation_f632d5500bbaeedd"] = "面甲 ", 
["addation_893ffa3390741c19"] = "每一场战争都需要一个人充当刽子手的角色. 不单单是士兵, 是一个能终日以恐怖的面庞与内心示人的杀人魔. 一个为 \"上层\"盲目而忠心地工作的人. 骷骸则是一个这样的人. 充当战犯, 做着别人觉得根本就是自杀的\"工作\". 他杀了一个又一个, 尸体堆了一具又一具, 鲜血永远洗不净他对杀戮赤裸裸的渴望.", 
["addation_8b1ca6794af3278e"] = "莫斯 ", 
["addation_9ec92ce5314c7f30"] = "机器人之间的战争愚蠢得就像小丑弄戏一样. 一具没有灵魂的机械去和另一具没有灵魂的机械对抗无非是闹剧. 但随着AI的发展, 一切开始变得愈加真实. 像 面甲 这样的人, 在这场由长逝的人族们发起的机器混战中发挥着至关重要的作用. 人类操控着机器去扣动扳机, 但却什么都感受不到. 机器人们互相残杀开始的那一瞬, 人类的心脏搏动都只是往日了.", 
["addation_7f4d3f3252a75a70"] = "拦截机 ", 
["addation_34f1aecfa87870f4"] = "道姆, 一个大计划的重要人物, 被另一方设计, 控制. 一种用于修复或重置单位的机器人, 曾经有一只道姆收到命令去修复一座被敌人摧毁的政府建筑物. 一起针对王峰的暗杀行动就在这只道姆的不远处发生了. 道姆突然跑了出来挡在王蜂面前, 爆炸发生了, 但王峰活了下来, 而这只道姆却再也没有了回应. ", 
["addation_fcd2124195986fcc"] = "黄金达拉斯", 
["addation_b840a5c02676237c"] = "购买 PAYDAY 2: 终极版以解锁物品", 
["addation_32b68122a46336e0"] = "王峰有着不可匹敌的技术能力, 作为原型机, 不管是蛮力还是头脑都远超自己的对手, 有着绝对的力量. 但它有着原型机的标配———无数的Bug和未经测试的实验功能以及赶工出来的组件. 它曾在狂怒之下杀死了自己的队友, 王峰因此成为了战犯. ", 
["addation_343521d481711b82"] = "工蜂 ", 
["addation_e4b0b33bce3fee6b"] = "拦截机 BX-99型 是为了让正事正常运行而被设计出的. 一件要动很多嘴皮子的活. 走上街头, 确保平民安全无事并确保那件事\"没问题\". 而这架拦截机背了一个装配厂的惨剧的锅. 部分平民伤亡, 弹药损失, 而这架拦截机的选择则是做了按照它的逻辑 —— 不能妨碍装配厂运行 的选择. 拦截机 BX-99 第151010130807号 在事件之后被拆除了. ", 
["addation_b99e87149876f77f"] = "道姆 ", 
["addation_ba72f81dd8f04603"] = "蜂王 ", 

["addation_d61b991b336cbb99"] = "分类组", 
["addation_a596aab6d00b993e"] = "The fedora, the very height of fashion and class. Where the line is drawn between boys and men. Carry this classical headgear with the pride and resolve that it deserves. Feel the legacy and tradition of the millions of gentlemen and gangsters that wore a fedora throughout the ages.", 
["addation_19af949f9da45739"] = "奖杯帽", 
["addation_65543899840dca39"] = "沃尔夫冈帽", 
["addation_9f2d4a78777cd43c"] = "It would be lovely to think Sterling earned the beret and badge through hard-training and combat. The truth, however, is that he saw how it impressed a couple of young fillies at the Officers Club. An invitation to step outside, a few dirty punches and a knocked out Colonel later, and Sterling had his very own red beret. And a couple of fillies. Smashing！", 
["addation_3b263f96b09352f1"] = "突袭：二战", 
["addation_283cb0864ed5c38f"] = "使用一枚奥德斯通的传承DLC密匙以解锁", 
["addation_09d8f858826c534c"] = "生还者飞行帽", 
["addation_4ec73cb70d18c6bc"] = "编辑皮肤(开发者模式)", 
["addation_20a07e5f9c913645"] = "This item popped up at an auction in North France during the 1990s. Among the auction goers sat a woman in her 50s. She recognized it and even though she could not remember the name of the officer who wore it, she paid a hefty sum for it. As a young girl she visited a square to buy vegetables when paratroopers came dropping down. Gunfire, explosions and screams of fear and pain filled the air. The officer took her to a shelter in a government building. He had no reason but kindness to save her. But even as his life was on stake, he risked it to save hers. She was just a young girl, but still recognized the hat.", 
["addation_1c7343b86c6b408e"] = "完成\"管制刀具法\"奥德斯通的传承任务以解锁.", 
["addation_c7380033ec235ee4"] = "Kurgan doesn\"t wear the gas-mask to keep the fumes of war out. He wears it to keep the flames of fury in. Betrayed by his own side, Kurgan barely survived an ambush by armored flamers. Inside the mask, there is only the smell of his own immolated flesh, a constant reminder to trust no-one.", 
["addation_08c575eb148bf214"] = "完成\"管制刀具法\"奥德斯通的传承任务以解锁.", 
["addation_6900e7e6e5687e75"] = "选择姿势", 
["addation_8de0bdc9239bc943"] = "完成\"管制刀具法\"奥德斯通的传承任务以解锁.", 
["addation_8d838ff03c714a57"] = "隐藏武器", 
["addation_d25c08f3486d3fff"] = "李维特的手帕", 
["addation_1f00c0158e7b0d50"] = "完成\"管制刀具法\"奥德斯通的传承任务以解锁.", 
["addation_ae38992b81e608a6"] = "黄金钱恩斯", 
["addation_2ab2992fb331ef57"] = "显示武器", 
["addation_6c7740b2a335842a"] = "社区4号", 
["addation_c8f3c02420b97936"] = "荣耀船形帽", 
["addation_e3734a24a274b01f"] = "完成\"管制刀具法\"奥德斯通的传承任务以解锁.", 
["addation_9bf5df3f004071f8"] = "库尔干的防毒面具", 
["addation_c4f0abfa7fd32b98"] = "奥德斯通的传承项目", 
["addation_a17e67a889f0d129"] = "This pilotka was found on a corpse near Lake M\xc3\xbcritz in Germany. It was attached with a string around the poor, dead soldier\"s head. There were no other bodies next to unnamed fellow, and as the origin of the pilotka was russian, it\"s fair to assume that he stemmed from the same country. Speculations were many, none were true, but the most inspiring story was the one about a soldier so proud of the motherland that he tied his pilotka to his head before he died.", 
["addation_54d93fb890cc8ee2"] = "加入 突袭:二战(RAID: World War II Steam) 社区以解锁 ", 
["addation_dbe929e635a14d84"] = "选择护甲", 
["addation_18d1d07a33fb5573"] = "In the small village of Pomtsburg, you can find a small monument. Few read the plaque covered with moss, but it holds the tale of a young boy. As the Germans came marching into Pomtsburg he lead the resistance with bravery and determination. Pomtsburg was his birthplace and no one were to destroy it. The Battle of Pomtsburg never reached the history books, and few even remember how it ended. But the boy managed to steal this souvenir. Something to remind him and others that you shall always stand up to oppression.", 
["addation_fe250d5604b1b510"] = "Rivet is American, and Americans value tradition. From the office of the President, to the lowliest scum-sucker in the land, tradition matters. So if you\"re going to stick a gun in a chump\"s face and demand they \"hand it over\" you better damn well know your history. Like Jesse James, like Billy The Kid, you wear a bandana.", 
["addation_83a99837c067307d"] = "It\"s been four years. Four years of hard work, meth cooked, shots fired and loot hauled. But we\"ve only just began. We do feel a bit nostalgic. It\"s been four years since we came to Washington and took on our first heist here and now we\"re pros. And when it\"s someone\"s birthday, you need to get them a gift. Therefore we\"ve poured 24k hot, luscious gold all over Chain\"s Mask. Happy Birthday PAYDAY 2！", 
["addation_754fb01a6bd628ce"] = "This cap may look like a normal, standard-issue M43 field cap. And you may think such humble headgear is an unusual choice for a man as vain as Wolfgang. But this cap holds special meaning for him. It may surprise you that Wolfgang can truly love. Pinned inside is a picture of his beloved. For whom he fights the good fight.", 
["addation_43b1a8869888fcaf"] = "浅顶软呢帽", 
["addation_478ffcb7900a8063"] = "A pilot in the Royal Air Force went down during WW2 a few miles outside Bialystok, Poland. Considered K.I.A, he was later found deep in the Bialowieza Forest where he\"d survived on fish, roots and animals he managed to caught———alive and well but madness had sunk his teeth into him. He\"d been forced to amputate his left leg. But still managed to survive without infections. A small hut was also found, together with salvaged parts from his aircraft. He was found in 1978.", 
["addation_39660de3b3e74dc2"] = "军官帽", 
["addation_405ba7ec9754a673"] = "It may have been many years since it was crafted by a true artisan gunsmith. Handed from father to son in a lineage of pressed uniforms and polished brass, until it finally found its proper purpose; bringing chaos and carnage. It was found in a collection of treasures and other spoils of war. This pistol finally saw some real action, not in the hands of war heroes at the brink of history but criminals who can truly appreciate the beauty of a well crafted firearm.", 

["addation_38748201acbd027f"] = "复古沃尔夫", 
["addation_0ae74f4d5b398bf6"] = "不常见的东西, 人类头骨. 简洁又美观. 即便只显现部分, 人们也能识别出一个人类头骨. 人类的大脑甚至为此有个特殊的区域. $NL;$NL;你完成所有普通难度的劫案了吗？ 你是强盗吗？ 也许这个面具适合你. ", 
["addation_a2510e5049e056f6"] = "手电亮度阀值", 
["addation_05dce4a581c6dcc5"] = "解开Locke & Load的第一个谜题以获取此改装部件.", 
["addation_edce41baba271451"] = "镭射亮度阀值", 
["addation_fd1340033e51161d"] = "附件自定义", 
["addation_43d17536c029ee86"] = "解开Locke & Load的第二个谜题以获取此改装部件.", 
["addation_40d1f4b8f6071905"] = "镭射颜色", 
["addation_a9fbc9920099b861"] = "写抢劫计划前玩一个好玩的脑筋急转弯是个预热的好办法, 达拉斯喜欢让自己的大脑操劳一些需要用心管理单位和资源以获胜的困难谜题.", 
["addation_c8b02a2e0f09307d"] = "复古钱恩斯", 
["addation_661db2c317ed2d79"] = "镭射颜色饱和度", 
["addation_e333d014eacf9f14"] = "手电颜色饱和度", 
["addation_93700e3320e73a4f"] = "解谜题是夜以继日的犯罪狂欢后减负泄压的好办法, 霍斯顿喜欢玩这种能动脑筋一步一步获取线索找到真相的小游戏.", 
["addation_7b71413205d851d3"] = "解开Locke & Load的第三个谜题以获取此改装部件.", 
["addation_e3a0ce3af318dab7"] = "解开Locke & Load的第三个谜题以获取此改装部件.", 
["addation_aa0fb3dfa71dc4d6"] = "挺进地牢", 
["addation_f0ccf9226a48f4a9"] = "手电颜色", 
["addation_f6ee47290f550cc5"] = "普通骷髅", 
["addation_e8c8dfc7883484ae"] = "复古达拉斯", 
["addation_26d430050521dd9a"] = "复古霍斯顿", 
["addation_7c620ed29eb4607c"] = "玩暴力游戏能让沃尔夫在干下大劫案之前进入一下状态, 越多的血浆, 越大的屠杀就意味着越好. 他喜欢那种能测试自己反应力和速度的游戏, 那种每一秒都冒着生命危险和无尽的敌人战斗的游戏.", 
["addation_1f2c1d89c5c0dc4d"] = "玩能让玩家们体验到紧张感的射击游戏是在工作间隙中保持自己实力的好方法, 钱恩斯喜欢玩那种能锻炼自己的意识和警觉感, 靠技术获得上风的游戏.", 
["addation_5b2b6243b275eb8f"] = "包含改装部件", 
 
["addation_5b707b824fcbbca1"] = "这是杜克面具喷绘前的版本.$NL;$NL;不喜欢原始的版本？ 这是你改变历史的机会.", 
["addation_58be68256b8a2421"] = "需要装备斯多葛天赋牌组", 
["addation_f85f452ba4435ee6"] = "致敬我们传奇的冒险家[MANY GUN] CLOVERAPTOR- 彩蛋解谜者和超凡死亡面具设计者！ 放弃成为银行家的梦想, 他直面命运然后击败条子巫师和巫师小弟, 法律元素使. 谁知这是他自己的意愿, 或者他那顽劣的罪犯父亲遗传, 让他勇往直前. 我们会永远感谢他的帮助.$NL;$NL;OVERKILL向你致敬！", 
["addation_b50174ee23e76908"] = "一个蠢贼想要打劫一家酒行, 但不懂正确隐藏身份, 而用了他上次买东西的纸袋套头上！没得说, 这蠢货很快被逮捕. 没有人质能交换, 他的犯罪生就此截断. 这件事甚至都没有上本地新闻, 也是提个醒: 一些事留着专业人士来干才好.", 
["addation_295b70397ee0d864"] = "杜克初始", 
["addation_be13ea3bdd9bbdec"] = "杜克角色包", 
["addation_c82fafcd6c1a73a4"] = "杜克",  
["addation_395d47303f4e6924"] = "杜克是个有文化修养意志坚定的人. 因此他的面具是他人格的写照. 犹如心灵的窗户映射他能坚定不拔思维缜密的进行犯罪, 能优雅从容不破的面对任何劫案.$NL;$NL;杜克脑海里的画面何等神秘———好像巧克力盒子你永远不知道下一颗什么味道, 除非你吃到嘴里. 跟着Payday帮, 最大的谜团可能就在身边...", 
["addation_ef694cfc8a172e19"] = "经典的装备总是美妙的东西. 驾驶200BHP的铁马上面的劫匪扎不显眼但细看, 订制的头盔价值连城, 就是这么低调有品位！", 
["addation_f9bf755dd6b752c7"] = "西蒙", 
["addation_fd91f1588f5b25bc"] = "Z.A.M.S头盔", 
["addation_afdc34081c228a5d"] = "完成Locke & Load活动页面第五个谜题来获得模组.", 
["addation_12f0c4f7cea4ac56"] = "大黄", 

["addation_5110838f25128775"] = "何必在意呢？ 就让宇宙膨胀, 笼罩着黑暗和死亡吧. 你拥有无尽的时间弹指那些对于你微不足道毫无意义的琐事. 你的生命能量从里的灵魂里消散, 都浪费在消耗你野心解决虚无的事上.", 
["addation_c66aefd8daebd22c"] = "越无止境. 再多的金银财宝也满足不了你. 一切都为了获得下一堆额外的财富来充填你的金库, 无论指精神上的还是物质上的. 只要你能从伙伴那里获利, 他们再怎样苦难对你都是无所谓的.", 
["addation_c93a4a49809c9e39"] = "傲慢", 
["addation_5996fc1318ad2c16"] = "这不公平, 真的吗？ 看看你, 寻求人生的一切但世间拒绝了你. 当你内心阴暗扭曲看向微笑舞蹈的人们时, 心里在想为什么没人送你他们的成功. 哦, 你如此渴求, 但你怎敢接受？", 
["addation_bd9ba6e4e4826725"] = "怠惰", 
["addation_c479e6d6a67ecb0f"] = "暴食", 
["addation_ee156988142b2826"] = "你固执己见. 满船水, 你拒绝撤离. 诸如你的原则, 你宁愿陷入深渊也不愿承认你比自己想的愚蠢. 你认为对的才是对的, 反对你的都是傻逼.", 
["addation_00d027129dd8de23"] = "看看, 你满脸抑制不住的食欲疯狂吞食填塞你的肚子. 当你停下时, 你的胃犹如打开了个黑洞, 渴求被填满.", 
["addation_de2918b5e45a79ee"] = "色欲", 
["addation_786083b4f35115fb"] = "嫉妒", 
["addation_41254fe8388b6901"] = "暴怒", 
["addation_2db3e22b0ede3c66"] = "贪婪", 
["addation_5f61fc08aba793db"] = "你的目光注视着你的猎物沉溺, 无人知晓时, 你却是一副烂肉似的存在. 你的目标是哪一个人都无所谓, 因为你本毫无知觉.", 
["addation_e544a91e21251993"] = "你的心中有股冰冷的火焰. 所有欺负过你的人都会付出代价. 你的理性蒸发, 烧死所有那些人, 宣泄着无边的愤怒.", 
--
["addation_02d918885248a177"] = "伊森", 
["addation_ed65e8e3b5ddc9da"] = "需要装备双档天赋牌组", 
["addation_8b386cb3326b1b14"] = "希拉 Begins", 
["addation_e50cfdd861c530fa"] = "Something about this mask radiates a playful malice and most who gaze upon it immediately feel a sense of unease, which is just the kind of thing you need when you\"re robbing a bank！", 
["addation_5c7f24cea2441a01"] = "This mask exudes power and brute force, in stark contrast to the man who wears it. Equal parts clown-like sadness and begrudging anger, it perfectly captures the mood of someone who has somewhat reluctantly chosen to become a heister.", 
["addation_20614d7e14803048"] = " ", 
["addation_e77528c33f7b0a24"] = "希拉", 
["addation_1a940cdf26f99b09"] = "This mask exhudes power and brute force, in stark contrast to the man who wears it. Equal parts clown-like sadness and begrudging anger, it perfectly captures the mood of someone who has somewhat reluctantly chosen to become a heister.", 
["addation_0af9ed1e169702e5"] = "这是希拉面具涂装前的初始版本.$NL;$NL;不喜欢原来那个？ 这是你改变历史的机会.", 
["addation_7652df35539d133f"] = "伊森", 
["addation_f62bb5b423977cc5"] = "这是伊森面具涂装前的初始版本.$NL;$NL;不喜欢原来那个？ 这是你改变历史的机会.", 
["addation_6dd1c9d79e466117"] = "购买H3H3角色包以解锁", 
["addation_29037caa5ba38382"] = "伊森 Begins", 
["addation_c32577a279930394"] = "希拉", 
["addation_c4a3410044d1b210"] = "Something about this mask radiates a playful malice and most who gaze upon it immediately feel a sense of unease, which is just the kind of thing you need when you\"re robbing a bank！", 

["addation_f59cf173cbb32c1c"] = "极盗者劫案", 
["addation_3bc46a325711238c"] = "武器包", 
["addation_b0c7d76812b73a18"] = "未来",  
["addation_157bbca7cb5c938c"] = "包", 
["addation_16b518f1886dbc5c"] = "教授先生", 
["addation_d5b7937639a90789"] = "制作人", 
["addation_ebdd19971b8f127f"] = "疤面煞星角色包", 
["addation_d06bf5c89b8f9d31"] = "真正不朽的经典是男女老少, 警匪皆宜的.", 
["addation_c689c4dcd9b8d667"] = "Look no further for a bad ass cherry to put on top of your Ice Cream of Minigun mayhem.", 
["addation_13d7811fcb2e5004"] = "劫案包", 
["addation_9d4768937393ec0c"] = "These frames harken back to a time when moon-landings were envisioned, all dreams were possible and people all dressed a little nicer.", 
["addation_aaa398a5e993005b"] = "H3H3角色包", 
["addation_2ff473bb2283aa4a"] = "山羊模拟器劫案", 
["addation_0825b75954091894"] = "Alesso劫案", 

["addation_a049ab5b8fb7b00b"] = "永远别挡在猫和猎物之间, 同理劫匪和他的战利品！", 
["addation_8a4187bf5d43b230"] = "猞猁", 
["addation_9c601dfa3f5c61ba"] = "炸开银行金库, 用这面具吓走所有那些猪.", 
["addation_90e80ffd83947552"] = "驼鹿", 
["addation_83b11b57cc3d926e"] = "从猎物转换成猎人, 用这奇迹之角撞开你的劫匪之路.", 
["addation_2f3d2b655e400e56"] = "北方的狼", 
["addation_af6987f9543a1fa6"] = "白熊", 
["addation_31d715d3b01f6ce2"] = "带上这个神奇的面具咆哮抗击全球变暖吧.", 

["addation_aaa1856aaae798be"] = "Mega Rad Mutant", 
["addation_422d8c5a3352e77d"] = "Spaulding", 
["addation_6a6e2c6da4efb2f3"] = "Per Chevron", 
["addation_bcc1c93457a15ecf"] = "黄色/深绿", 
["addation_076f84621b7e8d86"] = "Frou Frou", 
["addation_837b700500abaf53"] = "深灰/紫色", 
["addation_feb8ca5696381402"] = "深灰/绿色", 
["addation_3c0a868a88117a79"] = "浅蓝色/珊瑚红", 
["addation_184b45726021fa06"] = "粉色/白色", 
["addation_04289c82cca1e958"] = "翡翠绿", 
["addation_afced0dbb1343d96"] = "As if high on radioactive spray paint, the power level has been turned up a notch and is now close to bursting. When you go on a heist, everyone around you will duck for cover as you roll on by. Every geiger counter in town is about to go haywire.", 
["addation_05ea841b9a622d8e"] = "红色/橙色", 
["addation_66e8f71f56449eba"] = "For a thousand years, the traveller slept, biding his time until the stars did align and a mortal of sufficient ability would unlock him from his unholy prison. Rejoice！ For that day has come. Wield this power... wisely.", 
["addation_174337e725265ea9"] = "塑料黄", 
["addation_fcd2e39af5676138"] = "塑料粉", 
["addation_9bc4f77e20b50398"] = "深蓝色/橙色", 
["addation_1c7b7cde86fc41c8"] = "血红/深蓝色", 
["addation_fcb665fc71e102f4"] = "酒红", 
["addation_66c08ee68ae95276"] = "Klaus", 
["addation_c714e0b61b085ead"] = "Loser", 
["addation_863f626e3996d109"] = "The Insane", 
["addation_22d3ef614aef9f0c"] = "深紫色", 
["addation_214e0c23865a3367"] = "水晶紫", 
["addation_3726ed92bf0e2626"] = "The friends you have right now, may not be all the friends you\"ll ever need. Don\"t miss out on a future gain by keeping new friends away.  It\"s easy to get lost in the desert. One wrong turn is all it takes. And when you do, those new friends might just be your ticket to an oasis.", 
["addation_3afb107127dcef48"] = "Torturer or tortured？ Perhaps both, as the seething glow from your eyes sends chills of terror into the souls of the Law. Hear the lamentations of the Uniformed Blue as you evade them skillfully, with evil glee flowing through your veins as you foil every one of their attempts to apprehend you.", 
["addation_965864fbb51d2ca7"] = "Knowing when not to quit is harder than knowing when to throw in the towel. Don\"t get sidetracked by vanity or foolish pride. Sometimes, you get so wrapped up in a problem that you don\"t see what the problem really is. It gets everyone in a lot of trouble. Bad trouble. So do what\"s right, and you can\"t go wrong.", 
["addation_72fa6f71c8738f07"] = "Per Pale", 
["addation_bd89abce56fe4964"] = "珊瑚红/深灰", 
["addation_ebc1216c1e096a5d"] = "浅蓝色/橙色", 
["addation_d963322941b07c86"] = "Some people expect a free ride through life, cruising on good looks and luck. The world doesn\"t work that way, even if it sometimes looks like it. Talent is just the start; it takes education, dedication, determination. As a leader, you gotta make up your own mind. Respect your decisions, and others will too.", 
["addation_7b9f0a89e7cce99a"] = "Per Bend", 
["addation_768e1d592f286fad"] = "Trieced Pall", 
["addation_fab7c4d607f86334"] = "Ocean Breeze Teal", 
["addation_211019c44d8c413a"] = "深灰/白色", 
["addation_9fe0a73d5b06a648"] = "糖果", 
["addation_8d76c881cda8132a"] = "帕里米亚黄", 
["addation_65d4cb5484584689"] = "深绿色/叶绿色", 
["addation_a1332bcffef95f14"] = "蓝色/灰色", 
["addation_f5fb05218baad2c2"] = "Fess", 
["addation_d3f068df57a15fe8"] = "灰色/绿色", 
["addation_f139f346d0c07741"] = "塑料蓝", 
["addation_9dd2fce7ee54d68f"] = "塑料绿", 
["addation_499beeeff130c630"] = "黑色/绿色", 
["addation_0b91d1a3d53d2c3f"] = "亮棕色/白色", 
["addation_f091b0e037d44b71"] = "深灰色/深蓝色", 
["addation_1de94816c6f87df7"] = "$NL;$NL;这个面具属于成就里程碑奖励. 它不可在收获日抽卡环节获得, 也不可被出售. 相对应的, 当你卖出这个面具时, 它将自动返回你的库存. 但是你的涂装和涂装费用将不会被返还. ", 
["addation_09dcef939d8576be"] = "The Great Immortal", 
["addation_d2b748c7d3477d45"] = "塑料深灰", 
["addation_3255499ccb8ae4fa"] = "亮棕色/黑色", 
["addation_3d8168c7b7d6e142"] = "灰色/红色", 
["addation_bf42e1b40fa77d51"] = "青绿色/暖黄色", 
["addation_b3514f036025ba9f"] = "青绿色/灰色", 
["addation_e2154592c8338d04"] = "灰色/青绿色", 
["addation_9f7aba07b0879978"] = "品红/深灰", 
["addation_91325d5c35a4a90f"] = "足球", 
["addation_57a86079e34cd12c"] = "浅蓝色/白色", 
["addation_0cf7401b9b5ca8b8"] = "亮黄色/暗红色", 
["addation_b6a477eec329872b"] = "白色/暗红色", 
["addation_654ebc9efca4e39f"] = "粘土橙", 
["addation_8a04d73606aedbb5"] = "暗红色/亮黄色", 
["addation_ee93706836ab158f"] = "紫色/白色", 
["addation_85e999538e5dbd4b"] = "小花", 
["addation_91e9dff146c8c519"] = "Salaminati", 
["addation_e2c8a7695b1408c7"] = "Barry", 
["addation_0f5db07081f698c7"] = "品红/暖黄色", 
["addation_d1358d73c12119e0"] = "橙色/灰色", 
["addation_ade50932bccfe39c"] = "Klaus isn\"t a particularly smart dog, but what he lacks in brains, he makes up for in heart, and is always ready to share his bones with the rest of the pack.", 
["addation_21db284a15bf43b0"] = "白色/青色", 
["addation_2d7ab59e3951c3bd"] = "榛黄", 
["addation_eb78117f8f305b00"] = "Boxey", 
["addation_9f2f169d32f70d08"] = "水煮蛋", 
["addation_eaf21c6686aa7078"] = "浅蓝色/海军蓝", 
["addation_3d87361a785a4e8e"] = "葡萄紫", 
["addation_a8483df3a477329c"] = "塑料亮灰", 
["addation_809103f83b6e4fcb"] = "青绿色/黑色", 
["addation_0544ea00839b8a06"] = "Chip", 
["addation_a62483ab9471da00"] = "深灰/黑色", 
["addation_a972561ceff63e40"] = "珊瑚红/亮灰色", 
["addation_43d9796ff31c59bc"] = "Mega Conquest", 
["addation_c45fb054f49680d7"] = "Scalp", 
["addation_2d0c8c6c5d3e745b"] = "品红/黄色", 
["addation_92bdc50973d3252c"] = "超凡杜克", 
["addation_7b746d6a852f511f"] = "暖黄色/暗红色", 
["addation_4019019420328606"] = "Dark Knight", 
["addation_b88f18f2d07502bc"] = "叶绿色/黑色", 
["addation_47e7847bd55be23a"] = "On the one-thousand-and-first night, there was no light. But neither was it needed, for legends tell of an unruly rogue, who donned a visage that would allow all to be seen.$NL;$NL;Activate Night Vision Mode by holding down the Fire Mode button.", 
["addation_2b934d6f694816dd"] = "So arrives the Harbinger！ Humans can often recognize a human skull, even if it\"s only partially shown. The brain even has a special region for it. This is definitely not a human skull, it belongs to a demon of carnage.$NL;$NL;Look ye into the sky, as fire rains down from the heavens, followed by molten gold, to cover the land in a glittering metal blanket of awesome to illuminate your greatness as a heister. With every bar that is raised, you step up to the challenge, and have so done yet again. Construction of a throne is underway here at the OVERKILL office, so that we may bow to and worship your utterly divine skills at not getting beaten by anything we throw at you.", 
["addation_261acc990688fec5"] = "品红/白色", 
["addation_de646114305752a3"] = "完成奥德斯通的传承\"备战\"以解锁", 
["addation_c467e2f54eab12e7"] = "深灰/青绿色", 
["addation_1655b3e99506af92"] = "Chevron", 
["addation_c4750f58af77ae51"] = "钱恩斯, 武器专家", 
["addation_6c42a22c93cd8042"] = "Lavender Purple", 
["addation_42090e50d8a97a0b"] = "Gray / Purple", 
["addation_85a3f690e5bba6ed"] = "PNV闪亮之夜", 
["addation_b07f40f39dee9a14"] = "灰色/亮黄色", 
["addation_a00aa865fad938f4"] = "深蓝色/暖黄色", 
["addation_280e4588863a86ce"] = "Gyronny", 
["addation_f6e08d01ce6cf70b"] = "Plastic Teal", 
["addation_bde2cbe2cefb3a4c"] = "Pale", 
["addation_573222294af81de9"] = "沃尔夫, 疯子", 
["addation_ac1b0c151b140387"] = "Lozengy", 
["addation_a2607e2f7764e2b4"] = "Solid Cobalt Blue", 
["addation_773b751378b3c7a1"] = "The One Down Skull", 
["addation_112f0602a6eaf310"] = "粉色/深蓝色", 
["addation_a186f19c0c515fb7"] = "珊瑚红/黑色", 
["addation_95f5aaffff85ee4c"] = "紫色/黑色", 
["addation_14d001fd789325bc"] = "Royal Ruby Purple", 
["addation_40b59acfed925c8e"] = "深灰/暗红色", 
["addation_bd8ef03962983ae5"] = "暖黄色/浅蓝色", 
["addation_398bf77f7900a9c6"] = "Bend", 
["addation_0ea0217b0ead7ec3"] = "夜色蓝", 
["addation_9d310683f4e283fe"] = "暖黄色/紫色", 
["addation_66cbaa73eeda4b77"] = "粉色/黄色", 
["addation_7b7b48423734f99d"] = "达拉斯, 领队", 
["addation_e8dd347b57844a2a"] = "血红/毒气绿", 
["addation_fb2f2038c91ced80"] = "深灰/亮黄色", 
["addation_af341033b0b34c0f"] = "Saltire", 
["addation_0b28072e2e3c2027"] = "黑色/青色", 
["addation_8cd2fbe67117e9a8"] = "粉色/黑色", 
["addation_eae1e8f2265c69e4"] = "Crow Beak", 
["addation_4a14a1e0c76df95e"] = "黄色/红色", 
["addation_da1986a013b9bf81"] = "暗红色/黑色", 
["addation_37e512c22ee9e6e5"] = "霍斯顿, 渗透者", 
["addation_51c568fa037fe96b"] = "Mega Famine", 
["addation_3f333a6cc0e7f1e8"] = "Mega Greed", 
["addation_05aafc3031760ae6"] = "深灰/品红", 
["addation_489517465368d94d"] = "Per Pall", 
["addation_78118c3b92a1b863"] = "蜡笔红", 
["addation_8c8aec5158f7f098"] = "深蓝色/灰色", 
["addation_63f9284cda7c2038"] = "Fusil", 
["addation_9bb0cb6a9dc9469c"] = "Cupcake", 
["addation_8959d796c154e777"] = "Aristotle, Plato, Confucius, Michelangelo, DaVinci, Newton, Galileo... artists and thinkers forever engraved in history. And somewhere in that history, the place of a heister is assu红色. Contained herein is their essence, so magnificent in combination that the very surface of the mask can barely contain it.", 
["addation_c8a3d974b833b869"] = "It burns into your heart and tears the flesh from your skull- Orange flames to contrast the color of an unquenchable need for more. How many trips back into the vault will you make until you are satisfied？ How many weapons will make you happy？ All of them！ Maybe.", 
["addation_9a009662fee148d1"] = "叶绿色/暗绿色", 
["addation_8a5f262e85645f7c"] = "When there\"s only one copy of something left in the world, it becomes priceless. Know what you can do, and what others can do better. Get the job done. Don\"t get carried away by jealousy; that\"s fear talking. Fear brings you down. It doesn\"t come from love. When you really love someone, you trust them. Trust them enough to not get mean over priceless things.", 
["addation_14d7366b0cc8989e"] = "红色/深灰", 
["addation_8c1b76e08c194797"] = "灰色/暗红色", 
["addation_83aba9ecd7c5ecee"] = "灰色/白色", 
["addation_cada68887c10b98e"] = "深灰/黄色", 
["addation_1606a7904c1bc347"] = "灰色/深蓝色", 
["addation_9f82639c3f0ed9bd"] = "浅蓝色/亮黄色", 
["addation_9dcc0fb0808ab3d4"] = "青绿色/白色", 
["addation_56aae10d2b2f48b8"] = "鸽蓝色", 
["addation_32a0aba9520aa0e0"] = "Bermuda Blue", 
["addation_7678144cc7c6accb"] = "塑料黑", 
["addation_56de360ba8227728"] = "紫色/青色", 
["addation_f62bc4a3913bb2ee"] = "Solid Tuquoise", 
["addation_5082300e37ab87f7"] = "Plastic Magenta", 
["addation_143d644788052e56"] = "Crazy Lou", 
["addation_28e4a93270ed28c7"] = "Paly", 
["addation_1caa20e5b5f19d61"] = "红色/恐怖绿", 
["addation_5c13a7c8cb5ec5a1"] = "亮棕色/灰色", 
["addation_4d2c26919a4830ec"] = "骷髅脸", 
["addation_cfce81fca05daecf"] = "玫瑰木粉", 
["addation_f79afc7be2071d41"] = "灰色/品红", 
["addation_bf8eaf83f1c5eecd"] = "品红/黑色", 
["addation_adde11330f0d5af0"] = "Per Fess", 
["addation_4604b8b0a068754f"] = "If only the Kings of Old had such an artifact, they would have been invincible. What enemy could withstand bowing before you, as they gaze upon your magnificence？ Sun Tzu can go suck a lemon, because with a mask like this, who needs to employ art in war？", 
["addation_e588212b97705812"] = "深蓝色/黑色", 
["addation_df9242d21ec38a36"] = "One move, then another. Your opponent makes a move and you respond. He stands there, atop the mountain of gold, daring you to come forward and take on his challenge. By wearing this mask, you declare your defiance, with the game afoot, and the rivalry unending.", 
["addation_1766430dfcd4105a"] = "Solid Bright Yellow", 
["addation_dc53867dddcb5b7c"] = "粉色/军队蓝", 
["addation_de526be024415c19"] = "翡翠绿", 
["addation_a7dd8083c709d265"] = "浅蓝色/黑色", 
["addation_123ae19f8e800d80"] = "完成奥德斯通的传承\"刀具管制法\"以解锁. ", 
["addation_ff02c1015ba9acb5"] = "Shut Up！", 
["addation_6cc757d9f1c8d161"] = "Per Saltire", 
["addation_6f88eb58d052541a"] = "灰色/橙色", 
["addation_23dc1fe536209623"] = "深灰/珊瑚红", 
["addation_4b3c2140afc4c40b"] = "珊瑚红/白色", 
["addation_b9015c8f450d4c4b"] = "Magic", 
["addation_ed522197e33faca6"] = "固态珊瑚红", 
["addation_b1a1081df866f4b3"] = "塑料橙", 
["addation_6549f028bd698ebb"] = "橙色/深蓝色", 
["addation_219b27aa369cd1b5"] = "深红色/红色", 
["addation_c9cc47b5b5b3bf0a"] = "沙石橙", 
["addation_b0eb07074c33e7b5"] = "黄色/灰色", 
["addation_be33b32f42f2ef6e"] = "Old school street smarts and butch toughness is what you get here. A no nonsense get-the-job-done personality. You won\"t find a more devoted guard for your loot than this fellow.", 
["addation_9f8056f62d82a4ca"] = "Naismith", 
["addation_8fc9c26f3b835aa4"] = "Mega Arch Nemesis", 
["addation_1657d830a90ac926"] = "红色/灰色", 
["addation_74bc7283001777bd"] = "粉色/灰色", 
["addation_58182da143e59ee2"] = "Mega Tormentor", 
["addation_838ffc431a14776e"] = "灰色/黄色", 
["addation_dd8373bc65c4ff46"] = "黑色/黄色", 
["addation_7df4760b75482107"] = "暗红色/灰色", 
["addation_72b9c91ea7d14330"] = "蓝色/海军蓝", 
["addation_c27ba30323c6928f"] = "白色/恐怖绿", 
["addation_8bdcf4a904c89011"] = "That loaf of bread you wanted. Imagine that hunger one thousandfold. More than just a lack of food, your very soul is deprived of sustenance until it\"s as empty on nourishment as your belly. If starvation could continue beyond death, this is the visage it would take. But such a plight can be a mighty motivator for heisting.", 
["addation_8294ffdef1bb5725"] = "With her charming, floppy ears, Frou Frou is no timid Afghan Hound. Sharp and witty, she\"s the ideal companion to cover your face with on those heists that require brains as well as cunning.", 
["addation_59161f9dd95093b0"] = "Don\"t let the small frame and disheveled fur fool you. This little guy\"s piercing eyes can intimidate just about anyone, and woe betide any who dares steal something while he\"s on watch.", 
["addation_13e64b2ffe57ff10"] = "Payday蓝", 
["addation_916cd8009b933701"] = "Prussian Blue", 
["addation_def45b97e238cf89"] = "塑料紫", 
["addation_95b4a9196761197a"] = "塑料红", 
["addation_6ac25d42e7e09148"] = "Sea Teal", 
["addation_ef9961d675bfb76a"] = "Art", 
["addation_5fb9bee4edcf954a"] = "Penny the wise", 
["addation_eda96d0adb95d432"] = "Dummy", 
["addation_e2592954c6857c9a"] = "OK！", 
["addation_ba4b04cd0e9b29df"] = "Pale Hands", 
["addation_ab14470f92e77828"] = "Love and Understanding", 
["addation_4258d4ac13b1f87c"] = "Quarterly", 
["addation_8fcb40b50785c831"] = "Barry Pale", 
["addation_f8058bf203fa50bb"] = "Bendy", 
["addation_9cc79e6649fb3f5d"] = "Checky", 
["addation_0f1ff786d9da2e6f"] = "Cross", 
["addation_e0740058a7c10be4"] = "Quarter Back", 
["addation_c2e6809d2e36b582"] = "Warriors Eyes", 
["addation_e9d32a4f76b5784e"] = "Opera", 
["addation_d5f3b80daf15a5b3"] = "Freedom", 

["addation_c42eb0ab40d9421c"] = "阿尔米尔", 
["addation_cb2beefd26383289"] = "这个面具既令人恐惧, 又令人敬畏. 若要想戴上这特殊的面具, 你就得同时掌握你内心的平静与混沌 — 这种人很少在罪犯圈中出现. $NL;$NL;是否戴上阿尔米尔另大部分劫匪犹豫不决. 内心狂野的人戴上它后必成大器, 不过这种人只会出现在精神病院. 不过有时候, 你正是需要这种人来两肋插刀, 帮助你逃离困境$NL;$NL;在了解这些后, 你还会把\"阿尔米尔\"带入队伍中吗？ $NL; ；)", 
["addation_c3da795d96f1843c"] = "这是件ZAG TOYS公司物品！", 
["addation_f7db78f8902a854f"] = "想体验下火星旅行吗？ 你可以考虑买个火焰喷射器模拟下火星的气候. ", 
["addation_e6a9626517b59eb9"] = "想体验下火星旅行吗？ 你可以考虑买个火焰喷射器模拟下火星的气候. ", 

["addation_96179557e84e6e2a"] = "完成重金属成就！", 
["addation_09cc318c66388b69"] = "乔伊初始", 
["addation_fd2a7767818f7a4b"] = "黄金沃尔夫", 
["addation_40e5e5fae4928774"] = "需要装备黑客天赋牌组", 
["addation_271b5db79c0f56e5"] = "乔伊角色包", 
["addation_eb659245ff608a08"] = "乔伊", 

["addation_ac7dc926181e26cc"] = "戴上这头盔, 让条子们以为他们在攻打80年代的重金属乐队之神！", 
["addation_b7b8f973c44efa26"] = "老大哥", 
["addation_cf7a70a5df9b2422"] = "究极老派的邪恶. 无论是搭配燕尾服还是防弹衣, 这套装备都能显现出你的犯罪魅力. ", 
["addation_ac26d55d150004c0"] = "攻势警报", 
["addation_50a80dc754662647"] = "人质", 
["addation_904b2e37324da793"] = "玷污", 
["addation_1f0cebac8163dac8"] = "超凡战争", 
["addation_ac3bd3d425f226f0"] = "具有迪斯科风格；把你的脸打扮得惊人地美丽；在战斗中能够吸引敌人注意力. ", 
["addation_976fa9086b2a67dc"] = "刺钢丝", 
["addation_45644010fed32808"] = "伏击", 
["addation_63cedde7e98917d2"] = "庞乔", 
["addation_4542c816d060a825"] = "霍金斯", 
["addation_152aad78765afcb8"] = "水疱", 
["addation_083f7b08f43259aa"] = "古典式的超级反派", 
["addation_d8149d687e871f85"] = "乱涂乱画", 
["addation_c9fb071071c8311e"] = "小丑世界", 
["addation_75507d111fa6efd8"] = "恐怖的骷髅, 同时也是最神秘的海盗王, 将令在场所有的执法人员颤栗. 呀啊！", 
["addation_86adb201982187b1"] = "牛逼礼帽", 
["addation_006eef57c0f9bc3d"] = "迪斯科", 
["addation_3fc038bd3f684685"] = "据说这个头盔是在一处废弃的俄罗斯核设施中发现的, 穿戴它的人将随着时间的推移获得巨大能量. 当然这只是谣言. ", 
["addation_32049e363186f2a4"] = "爱憎", 
["addation_f7fd76db4c2cb1ac"] = "立体感", 
["addation_b2f2a573bc9ceeb9"] = "跑者", 
["addation_60164a32526989dd"] = "做事要持之以恒. 将这句话牢记在心, 尤其是当你面带微笑消失在深夜的迷雾中的时候. ", 
["addation_3e48aba3b54c76cd"] = "每个劫匪都应有个方便他人辨别的标志. 这顶老式礼帽, 出自纽约一名著名制帽师之手, 它绝对能吸引到所有执法人员的注意. ", 
["addation_c796b598d7580976"] = "嘣！嘣！", 
["addation_07af740f31d93cde"] = "天分和闪光点总得有个出发点. 有时候它只是个极端的基线, 原始、寒冷, 准备开始行动. ", 
["addation_d1f792ac95b572f6"] = "经典单片眼镜", 
["addation_ddb9357212fb9850"] = "吾乃$美金$", 
["addation_103b27c852ecbcdb"] = "游戏结束！", 
["addation_b98b09b1fa3c485d"] = "长途跋涉", 
["addation_0f1d7f522599124a"] = "即使这副华丽的眼镜只有一个镜片, 但它依旧能让你输入金库大门的身姿显得复古、时髦. ", 
["addation_16c199704c6781bd"] = "超凡弗拉德的护甲", 
["addation_1d31da3daa099d4c"] = "超凡海盗骷髅", 
["addation_0feea0420551b069"] = "匕首", 
["addation_6804399e12eacab2"] = "超凡乐观派", 
["addation_460489b53a431b7e"] = "未来的机器人霸主会感到欣喜若狂！你的领袖已经到来, 并为你带来了许多的正电荷. ", 
["addation_82f6e00392ee027e"] = "超级反派的胡子", 
["addation_0b8f09760fafa7e7"] = "已经过去五年了？ 该死. 现实生活中谁又能坚持五年？ 过去的一年是艰苦的, *很*艰苦. 这个大家庭已经被伤及要害, 条子们每天都离我们更进一步, 都快找上头了. 在这种情况下大部分劫匪要么被杀, 要么选择了销声匿迹息事宁人, 但我们才不是那些二流劫匪. 我们是PAYDAY. 我们能解决所有事情. 我们也总能得到黄金. ", 
["addation_b61a865aaefc03d0"] = "署名于此", 
["addation_251b061ce02af437"] = "修补工作", 
["addation_874b533f3992cd03"] = "比利", 
["addation_71bd1b80de69a7f3"] = "迪兰", 
["addation_27d0aeda673ee7f3"] = "费用平摊", 
["addation_73d193e6bf2096a9"] = "$金钱之王$", 
["addation_679a1074fddba3a4"] = "死猪", 
["addation_910220a89a49a53b"] = "给我们$钱$", 
["addation_68f9bb7803d1f484"] = "横向标识", 
["addation_beed6639bca9ede8"] = "百叶窗", 
["addation_4cd6d82459479827"] = "死亡绘画", 
["addation_616959e08b59831d"] = "薄雾", 

["addation_f01ff6214ad35974"] = "超凡笑面", 
["addation_44c5510d3ec95031"] = "超凡机车男头盔", 
["addation_05cd887c3a72a40c"] = "超凡阿努比斯", 
["addation_2cd57a3d91a28828"] = "电玩猴子", 
["addation_a9821b685f89cd1f"] = "奇比猫", 
["addation_5c6dc9e2eb6b971b"] = "超凡食虫虻", 
["addation_bd166950e62e5339"] = "低多边形山羊", 
["addation_b796836f2d697a8f"] = "哦, 你该如何去考量, 所有的富有和誓言, 都高于一堆珍奇且稀有的现金. （引述于劫匪）", 
["addation_f779cb7d64f33bc0"] = "看看这扭曲的笑脸, 这腐坏的金牙, 还有这闪耀着魅力光芒的, 对悲惨小丑的深深的敬意. ", 
["addation_37564beebb108c02"] = "一些巫术师声称他们知道永生的秘诀. 戴上这个面具不一定会好使, 但至少它能吓跑你的敌人, 或是被邀请参加牙买加人的户外烧烤排队", 
["addation_6e29c28ca9b55a66"] = "你释放出了这个面具所蕴含的极限恐惧, 现在警察和平民们都以为他们在上世纪60年代的恐怖电影里. ", 
["addation_a4123f6d60e9610b"] = "传说在冲绳的森林深处, 住着一条火狐的灵魂. 被那只火狐看到会是终身的幸事, 但是被带着这个面具的劫匪看到, 那就说不准了. ", 
["addation_823824fa39dbaf3f"] = "任何一个来自上世纪80年代的孩子都会为争夺这个面具而互相厮杀. 向大家展示谁才能真正统领霓虹高速. ", 
["addation_77a059b46253ef20"] = "如果一名劫匪戴着这面具走上街去, 全世界的人都将知道他无所畏惧. 该死的九条命！", 
["addation_5538171bee3340ac"] = "戴上这个面具以后, 你可以假装一直在向条子们扔手榴弹. 他们可能不会理会这种行为, 但是这的确能让你投出真正的手榴弹时的乐趣翻倍. ", 
["addation_f6f927e999d3dcb7"] = "魔鬼和恶魔会敬畏敢于戴上这个面具的劫匪的. ", 
["addation_59743e44aceabe17"] = "牙买加人的梦魇", 
["addation_8e678f7b51cdb165"] = "超凡克拉普斯", 
["addation_67de1c804362e732"] = "黑鸟", 
["addation_b8ff775f40d101ad"] = "学习埃及神的叫声, 然后花上一辈子站在你的战利品边上, 这样你就能守住它们. ", 
["addation_9acbd030a511c3f3"] = "超凡冕", 
["addation_69545902b1c20ee8"] = "来自上世纪90年代某个电子游戏的一群撒旦崇拜者想要拿回他们的低多边形山羊. 你会打算就这么还给他, 还是和他们胶着(物理)一整子？", 
["addation_333c41208bd1f20e"] = "灵狐", 
["addation_36687b93b735c826"] = "舞会皇后也不是没有从头戴这个头饰的劫匪身上得到些什么. 据说上面的珠宝全部来源于18世纪坠落地球的英仙座陨石上", 

["addation_dad2396134988bf0"] = "黄金霍斯顿", 
["addation_3f0320239f84ec9c"] = "它太完美了, 这才是一把枪该有的制作水准. ", 
["addation_384692a0438ffc2b"] = "是时候来次总结了. 我们的劫匪大家庭正在与我们所看不到的势力作斗争. 我只知道一件事 — 我们要么一起活着挺过去, 要么一起战斗到底. 我们是小丑, 他妈的劫匪之神, 我们之根据自己的规矩行事. 所以, 无论接下来发生什么, 我们都要准备好迎接那片金色的光芒. ", 
["addation_7aa2e074c619e609"] = "黄金休斯顿", 
["addation_6ec72f290038ba8d"] = "我还记得我第一次带上面具的时候. 真的已经过去七年了吗？当你执着地做了某些事很久, 是时候该抵达人生的十字路口了. 在这一行中, 风浪与安逸不可兼得. 每个人都得作出自己的选择. 每个人都得明白自己所面对的风险. 对Payday来说, 成功与否真的之代表了存活与否. ", 


["addation_577f0672f51136d9"] = "有着剧毒箭头的箭矢, 造成持续伤害并有机会打断敌人行动. ", 
["addation_b7e53d23c512a154"] = "唯我独尊", 
["addation_bef0d128b1a6add7"] = "枪口喷嘴", 
["addation_c27a54180db9175b"] = "有着爆破箭头的箭矢, 在撞击到物体时会引爆. ", 
["addation_1f9d94840116d40b"] = "唯我独尊", 

["addation_e386002c9575cdb8"] = "钱恩斯从来不把秘密放在心上，他称其为某些“天晓得是什么jb玩意”的东西。作为一名务实的人，尽管他极度“现实主义”，但他仍旧忠诚，并相信他与贝恩之间的关系。", 
["addation_384674dde4e4e1bc"] = "埃及-沃尔夫面具", 
["addation_44a80f1ae01fba48"] = "观测者的守卫", 
["addation_d630bed2886e73ed"] = "国籍：美国$NL;年龄：37$NL;$NL;钱恩斯从小就是个事儿逼，多年来游走在寄养家庭与慈善院之间。最终这种生活以钱恩斯参军结尾。$NL;多年来的军旅生活使他成为了完美军人，但他依然讨厌别人对他发号施令。$NL;$NL;离开军队后，钱恩斯成为了个雇佣兵, 利用他军队的专业知识来换取高额的回报。", 
["addation_e659863c0e4c0d1e"] = "秘密-沃尔夫面具", 
["addation_9746b761b9bd1c56"] = "秘密-钱恩斯面具", 
["addation_6b05a9922f421db5"] = "阿努比斯，下界的守护神战士与巴斯特的配偶，一股生于黎明的神秘力量。博学且好战的守卫者把守着观测者约柜的大门，并将没有资格的灵魂阻挡在外。就算凡人将这位古战神面具戴上。也不可能拥有他的全部力量。", 
["addation_0426db521b0972d8"] = "他们从何而来，是给人来带来最大礼物的人，还是来自于地球表面或是深海的原住民？不管他们是谁，他们所存在的大部分痕迹已经随着时间的流逝而消失殆尽。霍斯顿，寻求新未来的旅行者，可能并不知道真相，但他仍旧戴着他们的面具，以致敬秘密之源。", 
["addation_e46afc37751d9ebd"] = "国籍：美国$NL;年龄：44$NL;$NL;老道，狡猾而又井井有条。$NL;在他30岁时就已经有能力让两个芝加哥黑帮相互火拼，这导致南部许多黑帮老大下令要取达拉斯的首级，但他总是能够隐匿行踪并存活。当一切平息下来后，他又重新爬上了犯罪的阶梯.$NL;$NL;现在他成为了世人的恐惧。", 
["addation_35586ba36dcaea16"] = "这副面具由古化石制成，并附有每一位前任主人的雕刻，它象征着无限的力量。正如面具边缘的文字所属，这是所有胆敢违抗佩戴者的终结的开始。", 
["addation_1496bee9c1543721"] = "秘密-达拉斯面具", 
["addation_76c612e4f4481348"] = "秘密-霍斯顿面具", 
["addation_d90b39db35353dce"] = "预示", 
["addation_f008b0e31d4cfa71"] = "国籍：美国$NL;年龄：31$NL;$NL;休斯顿从来都不能在一份工作上做长久，虽说他的确保住了PAYDAY帮的饭碗。$NL;他的生活作风使他成为了骗子和窃贼，他负债累累，也因多年来的诈骗树立了许多敌人。他需要越来越多的钱来安顿那些放高利贷的人。他在24岁时犯下的第一单重罪对债务来说只不过是杯水车薪。", 
["addation_1f5389d9704258d5"] = "苏美尔人-钱恩斯面具", 
["addation_2f8447d0da580e8c"] = "霍斯顿离开了他的母国，并加入了Payday帮。当贝恩第一次和他提及秘密时，他幻想着去寻找那些具有潜在价值的古代遗产，而不是去考虑贝恩所说的“传奇力量”是否属实。", 
["addation_444cbcfd6db03643"] = "观测者-霍斯顿面具", 
["addation_51b76d0a233c1b47"] = "作为领队，他不得不牺牲许多。事业，团队，个人目标———不惜代价来完成任务。正如中美洲人牺牲自己来安抚神明，达拉斯也将自己奉献给了劫案之神———合约人。", 
["addation_324d2d002844dc5c"] = "恶毒，否认死亡，外加黄金———这是古埃及人能够克服万物的要点。某种意义上，沃尔夫会戴这副面具来致敬古代文化完全合情合理。", 
["addation_150c29bfa4aa40f5"] = "巴斯特，阿努比斯的配偶，被古埃及人奉为猫神战士，而事实上它更像是一种古老的力量。拜她的力量所赐，观望者约柜的守卫者能够通过她的面具，来完成他们永无止境的任务。据说戴上她的面具的人将拥有无尽的运气，且有能力在死神降临之时假死瞒骗过去。", 
["addation_36e2cb8f9a3440df"] = "苏美尔人开启了一个充满只会，音乐与想象力的时代，并曾想象过世界是如何开始的。从表面上看，钱恩斯也许是名专业的武器大师，但是在更深处，他更是一个传奇，这也是这副面具所要致敬的文化。", 
["addation_0daa59b9193fa282"] = "中美洲-达拉斯面具", 
["addation_764618bb29de5d7f"] = "王者的守卫", 
["addation_6e59ee99b11c1037"] = "达拉斯总觉得贝恩对他隐瞒了秘密的一些细节。在洗劫第一世界银行之后，贝恩并未解释为什么玛雅人的黄金是如此重要。Payday帮是个大家庭，而信任并不是坚固无暇的，但在最后，达拉斯最终还是明白了贝恩保密的原因。他的机智使每个人都获得了他们想要的东西。", 
["addation_c4af4f931bfec6d9"] = "沃尔夫是名时常暴力且不可预测的成员，这导致贝恩起初并不确定该不该告诉他找寻秘密的信息。最终，他还是表现出了他的价值，但当贝恩告诉他自己的需求时，沃尔夫彻底陷入了疯狂。他不仅能从中获利，他还同时喜欢阴谋。", 
["addation_f62cc997264144a8"] = "国籍：爱尔兰$NL;年龄：27$NL;$NL;克洛芙成长于一个贫困镇子里的贫困家庭。她世代祖先都是战士，而克洛芙也严格遵循着她的爱尔兰传统。为了祝福好运，她随身都带着三叶草，犹如在宣示\"我是爱尔兰人我自豪\"。", 
["addation_6092267792529d3f"] = "国籍：瑞典$NL;年龄：34$NL;$NL;在生命中大部分时间里，沃尔夫都是个老实巴交的平民。直到2000年末，金融风暴席卷全球，沃尔夫的公司就剩一个越发没有信心想要终止合作的客户。$NL;他的公司最终还是破产了。$NL;$NL;现在他满怀曾经经营公司的决心，继续着犯罪生涯。", 


["addation_dafa61dfa677cb6e"] = "联盟光学模组包", 
["addation_7713c6f59b847976"] = "购买联盟光学模组包DLC以解锁", 
["addation_d4fc9763460fea09"] = "跨越边境劫案", 
["addation_cb40fd083d1a5e30"] = "购买跨越边境劫案DLC以解锁", 

["addation_0293dfb1a7a04318"] = "嬉皮卡", 
["addation_1551fd29f5dda851"] = "宏伟且高贵，来自最伟大的王朝，象征着传统与家找的铁面战士，将面对史上最大的敌人。通过这片艺术品，来自Crime.net的百夫长能够发挥来自古罗马的耐性与力量。", 

-- ———— 圣马丁银行
["addation_9a177883ec4d8f85"] = "购买联邦武器DLC以解锁", 

["addation_e96f9b7e2f9e57f4"] = "阔边帽", 
["addation_6834a0df344c9992"] = "嘲笑带着这副面具的劫匪的人很快就会意识到这将是他们最后的笑声，毕竟我也没见过头上顶个贼鸡大的子弹孔的人还能笑。", 

["addation_3114b99c6032c7c3"] = "购买圣马丁银行劫案DLC以解锁", 

["addation_184e9cb3b2f35be2"] = "霍斯顿是早期PAYDAY帮的成员之一。在大肆作案一番后，霍斯顿于2012年锒铛入狱。2014年PAYDAY帮助他成功越狱。从他出狱以来，他就一直在追查是谁陷害了他。", 

-- ———— 蒂华纳的早餐
["addation_044aabe55ccfd67d"] = "游戏", 
["addation_a0c401a081ea8355"] = "时刻准备游玩。", -- ———— ？
["addation_46ad8e777c58c444"] = "AI队友加成", 
["addation_118bf10f36773a41"] = "AI队友技能", 
["addation_a5ea4402d058d6e6"] = "逃犯武器包", 
["addation_2d0f295c6b0d8a23"] = "蒂华纳的早餐劫案", 
["addation_7cfaefab15b49f5f"] = "联邦武器包", 
["addation_e71371914c8614a0"] = "购买蒂华纳的早餐劫案DLC以解锁", 
["addation_165371bb4bece37b"] = "购买逃犯武器包DLC以解锁", 
["addation_bc91b63abb697b17"] = "使用默认步枪弹", -- ———— 炮台弹药
["addation_e69daaa7516ed3a7"] = "使用AP穿甲弹", 

-- ———— 面具颜色·改 (2020年周年庆)
["addation_a848fd54d6057d2a"] = "颜色", 
["addation_ca0b660abf330a38"] = "主色", 
["addation_e18569aee178a018"] = "选择主色", 
["addation_9a4597903da77e22"] = "副色", 
["addation_dc853930fde80d39"] = "选择副色", 

["addation_2fa9e1778d349cef"] = "(纯色)电子靛蓝", 
["addation_9ea5272894bb5aa1"] = "时尚紫红", 
["addation_cab78c9bdba2c204"] = "玫瑰红", 
["addation_1872097663bed8c6"] = "叶绿色", 
["addation_d42146073834e997"] = "欣喜粉", 
["addation_8636223c9aaf8d3f"] = "黑色", 
["addation_ec64154bdf70e9a8"] = "绿色", 
["addation_33bb28feca610e88"] = "亚光蓝", 
["addation_155e06474112d7fa"] = "亮蓝色", 
["addation_aa5cf3b623590455"] = "暗红色", 
["addation_e66250e99b12311f"] = "(纯色)咖啡色", 
["addation_e9d7d3ad02b745fa"] = "(纯色)枝叶绿", 
["addation_59e6f1dd29c67b0e"] = "法式铜锈", 
["addation_2f0cea90f02a5438"] = "(纯色)淡紫色", 
["addation_141528cb67517bfe"] = "(纯色)海绿色", 
["addation_bf825128aaace87f"] = "(纯色)时尚紫红", 
["addation_edba9cf6dff5bb7e"] = "血红色", 
["addation_20ae40f9ce169aca"] = "(纯色)浅黄色", 
["addation_4d026a4c16dd838a"] = "青绿色", 
["addation_2988bfbc9206341c"] = "鲜艳淡紫", 
["addation_4bac631963288d9f"] = "(纯色)阴蓝色", 
["addation_e2132ee8c016aad2"] = "紫色", 
["addation_9527beda3147eb08"] = "(纯色)俄式雪青", 
["addation_259d48b0bb9f644d"] = "翡翠鱼绿", 
["addation_7d91aa04c282aa68"] = "(纯色)步枪军绿", 
["addation_588548f163f88816"] = "亮黄色", 
["addation_a0879ca7da65ef87"] = "刚果粉", 
["addation_397ce382f2d76b71"] = "绝赞蓝", 
["addation_40e5bb0610ab7942"] = "(纯色)粉笔黄", 
["addation_5f9417ff95cbd44d"] = "(纯色)蓝钟花", 
["addation_b85f95c6e8406492"] = "俄式雪青", 
["addation_43d4ebd6288de4a7"] = "(纯色)玫瑰红", 
["addation_1f004482bb06b093"] = "郊狼棕", 
["addation_a2f7a3d23cd0afca"] = "(纯色)黄绿色", 
["addation_4c83421d7cbed1a5"] = "(纯色)深绿色", 
["addation_59afcb20880e5be0"] = "红色", 
["addation_40e29de21222c7de"] = "暗紫褐色", 
["addation_35e7279c9b71fbc9"] = "海蓝色", 
["addation_e4a0f54f9a9a14f5"] = "蓝色", 
["addation_30ac5304816f7516"] = "(纯色)阴黄色", 
["addation_bebf2908ad9374d5"] = "鲜艳蓝", 
["addation_572c290996a05613"] = "海蓝色", 
["addation_37e86ad215b1fac5"] = "(纯色)石板蓝", 
["addation_ea49129a53c7a3e9"] = "天堂", 
["addation_e7b19a80820fef28"] = "深海蓝", 
["addation_8f7aad35672c5dd2"] = "恐惧绿", 
["addation_398941a66566ac33"] = "鲜艳树莓", 
["addation_9531dfc145365eea"] = "(纯色)暗石板蓝", 
["addation_cfe39f83717ecb03"] = "(纯色)鲜艳淡紫", 
["addation_929f5210229d9415"] = "(纯色)鲜艳天蓝", 
["addation_26371e6b82836695"] = "亚光紫色", 
["addation_71dc1f4ce00a707e"] = "(纯色)帝国紫", 
["addation_958912e285f17b91"] = "白色", 
["addation_876946c8c9266719"] = "亮灰色", 
["addation_45a0239ba07a031a"] = "暗灰色", 
["addation_6af1e74537f6c755"] = "朦胧淡紫", 
["addation_38da0cc817b9e0de"] = "粉色", 
["addation_a5dfe42cb95e57fd"] = "法式天蓝", 
["addation_9a479dc8b2dae85a"] = "(纯色)布兰迪斯蓝", 
["addation_37f3a844e47da0b8"] = "鲜艳天蓝", 
["addation_4c5f2c0d9a3aa691"] = "毒物绿", 
["addation_58e51c5f8e8fd28e"] = "马革色", 
["addation_30e0d4cf46777f06"] = "浅黄色", 
["addation_aaf951d7d8021d9c"] = "阴蓝色", 
["addation_a9177211868ee4c0"] = "帝国紫色", 
["addation_de9bd836953c5056"] = "泥浆色", 
["addation_eeb671bdc78c1d52"] = "(纯色)刚果粉", 
["addation_5820d58f18f271b3"] = "深红色", 
["addation_cb800d43c03319bb"] = "热浪", 
["addation_d2f0bf13c8cc80b8"] = "无忧蓝", 
["addation_7854ea33ca94d782"] = "(纯色)法式铜锈", 
["addation_4d5922d642a50a5b"] = "(纯色)欣喜粉", 
["addation_ca718843698e68f3"] = "暗石板蓝", 
["addation_03341ca22d22e8b2"] = "棕色", 
["addation_d2c69d1afdff2d3c"] = "枝叶绿", 
["addation_da2109743d55ba2b"] = "(纯色)无忧蓝", 
["addation_5ee6f04224625b62"] = "柠檬绿", 
["addation_975a1f20eaadde54"] = "(纯色)深红色", 
["addation_7dd0462e31677897"] = "青色", 
["addation_72cb27c3758bb5c6"] = "(纯色)霓虹红", 
["addation_c4eb53faf5859160"] = "(纯色)热浪", 
["addation_b868e4723e8725da"] = "淡紫色", 
["addation_9f1a07fd6c7a248d"] = "沙色", 
["addation_759c8d87d380e2dc"] = "五月绿", 
["addation_20e68ef2aaf39092"] = "黄色", 
["addation_1b26469f5a71d100"] = "灰蓝色", 
["addation_d3946f2ba3102d4c"] = "阴黄色", 
["addation_6d3c702841f03b8b"] = "强紫色", 
["addation_9765958e853ffb55"] = "(纯色)深海蓝", 
["addation_0a31c405b0e2210d"] = "(纯色)绝赞蓝", 
["addation_00752c118dd48e16"] = "霓虹红", 
["addation_49f9266c1463283c"] = "(纯色)鲜艳树莓", 
["addation_21d6dbaaa5594525"] = "橙色", 
["addation_ba2d8b0ffb294ae7"] = "(纯色)泥浆色", 
["addation_db4eaa8f98461d71"] = "蓝钟花", 
["addation_1ae046ddc09cc7ec"] = "米色", 
["addation_7c86ddac724d08c1"] = "骨头白", 
["addation_bff647398fdeca5e"] = "海军蓝", 
["addation_1f62ceafba9c8c63"] = "品红", 
["addation_acea13651b47d5ed"] = "(纯色)淡紫色", 
["addation_fd820127c468d2e5"] = "(纯色)米色", 
["addation_c75bd228e71bdeb2"] = "(纯色)朦胧淡紫", 
["addation_4d203e6c5bb912f0"] = "(纯色)海蓝色", 
["addation_ccdea07e866cba68"] = "(纯色)暗紫褐色", 
["addation_5ed12b59e5c25067"] = "(纯色)强紫色", 
["addation_739980bfa1ee926d"] = "皮肤粉", 
["addation_a71d11c758f00914"] = "(纯色)翡翠鱼绿", 
["addation_080df24a004142df"] = "海绿色", 
["addation_fd41db12af030719"] = "(纯色)法式天蓝", 
["addation_4918ee03d48764ea"] = "(纯色)熟成绿", 
["addation_0b1a81d417acfa88"] = "(纯色)五月绿", 
["addation_3973939ca9b3c1e9"] = "淡紫色", 
["addation_2c795b38b456b095"] = "(纯色)鲜艳蓝", 
["addation_fe483d190c4feef3"] = "钴蓝色", 
["addation_11af67a8937e3cc1"] = "石板蓝", 
["addation_872729647c0ae166"] = "淡紫色", 
["addation_ecb19210e4116226"] = "珊瑚红", 
["addation_7154ff57bc72315c"] = "(纯色)淡紫色", 
["addation_3d4c8dc2b18e3d4b"] = "灰色", 
["addation_28999a1523c9e2cf"] = "(纯色)沙色", 
["addation_064a07c42ccbb5d4"] = "熟成绿", 
["addation_b33b21a2fd845ab6"] = "黄绿色", 
["addation_234af0b46c2efd79"] = "暗紫色", 
["addation_279381e13ac94ca4"] = "暖黄色", 
["addation_75343f53f3b65ccc"] = "步枪军绿", 
["addation_a954d8ca046580f4"] = "电子靛蓝", 
["addation_653be43e8094363e"] = "橄榄绿", 
["addation_3d6e256ac879f66b"] = "暗绿色", 
["addation_19085a9ceea86719"] = "粉笔黄", 
["addation_7f2a48b84c6800d0"] = "深绿色", 
["addation_21e61fc1dba241d9"] = "蕨绿色", 
["addation_504657c4eb0ddfe2"] = "(纯色)天堂", 
["addation_a68f4f2a91e4ec20"] = "(纯色)马革色", 
["addation_1d3018decd741842"] = "(纯色)蕨绿色",  
["addation_f1c344322d126508"] = "(纯色)郊狼棕", 
["addation_4839f8f5c819d686"] = "布兰迪斯蓝", 
["addation_c4ad58dd79f5ee0e"] = "咖啡色", 
["addation_0de5b14b20fec93a"] = "亮棕色", 

-- ———— 瓮中捉鳖
["addation_17157eb02274e518"] = "恶名转生", 
["addation_e62189e1d4ebdad8"] = "购买裁缝3号DLC以解锁", 
["addation_5dcfae8760b4ca8b"] = "购买瓮中捉鳖劫案DLC以解锁", 
["addation_ac31cad167c17ffd"] = "购买枪手武器包DLC以解锁", 
["addation_11fc6b2c46d010d0"] = "枪手武器包", 

["addation_c84a39aa0db165b6"] = "不死孔雀", -- ——面具
["addation_0c9e52af71aeba2e"] = "怒发冲冠者为大王。", 

-- ———— 恶名奖励
["addation_087b43409c2ebb61"] = "数字极限", 
["addation_fa7303beec60d04a"] = "如同精心制作的钟表，你能从这副面具的佩戴者身上体会到什么叫毫米级的准确。在战斗中，敌人将无一不被这精细所震撼。", 
["addation_98944c7c76456544"] = "致命玩笑", 
["addation_06ede5450103781e"] = "谁知道这面具之下是否蕴含着一样的疯狂？它到底是在影射劫匪的内心，还是劫匪们对法律的藐视？", 

["addation_e3d5119bddda1cd3"] = "2020圣诞节", 
["addation_8535311ce552859f"] = "欢庆冬日", 

["addation_4258a676cbef6d01"] = "购买附凤扳龙DLC以解锁", 

-- ———— 乌克兰囚徒
["addation_93c4ee44b12f983e"] = "完成成就\"圣诞老人恐惧症\"解锁", 
["addation_dbd7ad08ed89a35a"] = "完成成就\"弗拉德好帮手\"解锁", 
["addation_78083e9a8f9f1466"] = "完成成就\"圣诞抢个够\"解锁", 
["addation_ff577bf3da66351a"] = "完成成就\"只有圣诞老人不在的圣诞节\"解锁", 
["addation_56fd51129b246745"] = "购买黑道圣徒3重制版解锁", 
["addation_275a6fdce931d187"] = "购买卫士裁缝包解锁。", 
["addation_bb6a09e07d9362e8"] = "完成成就\"乘风破雪而来\"解锁", 

-- ———— 8周年
["addation_9479bc568670d453"] = "Not-A-Flamethrower 退休金喷射器", 
["addation_5823bc6831eff3b1"] = "完成支线任务\"钱雨不止\"以解锁", 

["addation_6558682424f18a9b"] = "狂热老八", 
["addation_26d439123a544c45"] = "庆典是为了庆祝特殊时刻而办的，而总有时刻比特殊更特殊。应混乱与犯罪之神(即Payday帮)要求，我们为您献上这个燃烧的小丑面具以表对您的忠诚。", 
["addation_9bf781c383a35c4f"] = "完成支线任务\"红火当头\"以解锁", 

["addation_00d60b298d1972d1"] = "活动已结束：无法使用", 

-- ————  九凤走私包3
["addation_1835fe2c0f62c10f"] = "购买九风走私3号包DLC以解锁", 
["addation_1fc92423d9143aa8"] = "九风走私3号包", 

["addation_eaddf6bb213586a2"] = "购买超凡都市裁缝包DLC以解锁", 

-- ———— 星风账号
["bm_global_value_sbzac2"] = "Starbreeze账号", 

-- ———— 2021圣诞节/水蛭
["bm_menu_skill_locked_copr_ability"] = "需要装备水蛭天赋牌组", 
["bm_global_value_snow_unlock"] = "购买冬日幽灵裁缝包DLC以解锁", 
["bm_global_value_snow"] = "冬日幽灵裁缝包", 
})
end)