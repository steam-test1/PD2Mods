Hooks:Add("LocalizationManagerPostInit", "CHNMOD_PATCH_save", function(loc)
	LocalizationManager:add_localized_strings({
["savefile_autosave"] = "$TEXT_WITH_DATE;———自动保存",
["savefile"] = "$TEXT;———$DATE;",
["savefile_setting"] = "游戏设置：需要$VERSION;或更高的版本。",
["savefile_game_title"] = "PAYDAY 2",
["savefile_saving"] = "保存中...",
["savefile_setting_description"] = "用户自定义游戏设定。",
["savefile_progress"] = "玩家进程：需要$VERSION;或更高的版本。",
["savefile_empty"] = "[新的存档]",
["savefile_loading"] = "载入中...",
["savefile_progress_description"] = "Player statistics and game progression。",
["savefile_removing"] = "移动...",
})
end)