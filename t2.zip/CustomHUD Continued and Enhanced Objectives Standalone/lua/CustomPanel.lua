CustomPanel = CustomPanel or class(HUDTeammate)

CustomPanel.scale = CustomPanel.scale or 1
CustomPanel.width = CustomPanel.width * CustomPanel.scale
CustomPanel.height = CustomPanel.height * CustomPanel.scale

function CustomPanel:init(width, height, scale)
    CustomPanel.width = self._main_player and 575 or 388
    CustomPanel.height = self._main_player and 80 or 85

    self._panel = self._parent:panel({
        name = "teammate_panel_" .. self._id,
        visible = false,
        w = CustomPanel.width,
        h = CustomPanel.height,
    })
end