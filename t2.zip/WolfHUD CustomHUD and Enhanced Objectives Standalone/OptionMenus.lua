if CustomEOStandalone then
	-- Actual Menu Data table
	CustomEOStandalone.options_menu_data = {
		type = "menu",
		menu_id = "CustomEOStandalone_main_options_menu",
		--parent_id = "blt_options",
		name_id = "CustomEOStandalone_options_name",
		desc_id = "CustomEOStandalone_options_help",
		position = 3,
		options = {
			{
				type = "multi_choice",
				name_id = "CustomEOStandalone_language_title",
				desc_id = "CustomEOStandalone_language_desc",
				options = {
					["english"] = "CustomEOStandalone_languages_english",
					["german"] = "CustomEOStandalone_languages_german",
					["dutch"] = "CustomEOStandalone_languages_dutch",
					["french"] = "CustomEOStandalone_languages_french",
					["italian"] = "CustomEOStandalone_languages_italian",
					["spanish"] = "CustomEOStandalone_languages_spanish",
					["portuguese"] = "CustomEOStandalone_languages_portuguese",
					["russian"] = "CustomEOStandalone_languages_russian",
					["chinese"] = "CustomEOStandalone_languages_chinese",
					["korean"] = "CustomEOStandalone_languages_korean"
				},
				visible_reqs = {},
				enabled_reqs = {},
				value = {"LANGUAGE"},
			},
			{
				type = "divider",
				size = 12,
			},
			{	--General HUD
				type = "menu",
				menu_id = "CustomEOStandalone_customhud_options_menu",
				name_id = "CustomEOStandalone_panels_options_name",
				desc_id = "CustomEOStandalone_panels_options_help",
				options = {
					{
						type = "toggle",
						name_id = "CustomEOStandalone_use_customhud_title",
						desc_id = "CustomEOStandalone_use_customhud_desc",
						value = {"WolfHUDCustomHUD", "ENABLED"},
						visible_reqs = {}, enabled_reqs = {},
					},
					{
						type = "toggle",
						name_id = "CustomEOStandalone_use_enhanced_objective_title",
						desc_id = "CustomEOStandalone_use_enhanced_objective_desc",
						visible_reqs = {}, enabled_reqs = {},
						value = {"WolfHUDCustomHUD", "ENABLED_ENHANCED_OBJECTIVE"},
					},
					{
						type = "toggle",
						name_id = "wolfhud_disable_blend_mode_title",
						desc_id = "wolfhud_disable_blend_mode_desc",
						visible_reqs = {},
						enabled_reqs = {},
						value = {"WolfHUDCustomHUD", "DisableBlend"},
					},
					{
						type = "divider",
						size = 8,
					},
					{	--WolfHUDCustomHUD Player
						type = "menu",
						menu_id = "CustomEOStandalone_customhud_player_options_menu",
						name_id = "CustomEOStandalone_playerpanel_options_name",
						desc_id = "CustomEOStandalone_playerpanel_options_help",
						options = {
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_position_title",
								desc_id = "CustomEOStandalone_panels_position_desc",
								options = {
									"CustomEOStandalone_multiselect_left",
									"CustomEOStandalone_multiselect_center",
									"CustomEOStandalone_multiselect_right"
								},
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "POSITION"},
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_scale_title",
								desc_id = "CustomEOStandalone_panels_scale_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "SCALE"},
								min_value = 0.01,
								max_value = 2,
								step_size = 0.01,
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_oppacity_title",
								desc_id = "CustomEOStandalone_panels_oppacity_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "OPACITY"},
								min_value = 0,
								max_value = 1,
								step_size = 0.01,
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_name_title",
								desc_id = "CustomEOStandalone_panels_show_name_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "NAME"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_rank_title",
								desc_id = "CustomEOStandalone_panels_rank_name_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "PLAYER", "RANK"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_truncate_tags_title",
								desc_id = "CustomEOStandalone_panels_truncate_tags_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "PLAYER", "TRUNCATE_TAGS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_char_title",
								desc_id = "CustomEOStandalone_panels_show_char_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "CHARACTER"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_status_title",
								desc_id = "CustomEOStandalone_panels_show_status_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "STATUS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_downcounter_title",
								desc_id = "CustomEOStandalone_panels_show_downcounter_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "PLAYER", "DOWNCOUNTER"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_stamina_title",
								desc_id = "CustomEOStandalone_panels_show_stamina_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "PLAYER", "STAMINA"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_condition_icon_color_title",
								desc_id = "CustomEOStandalone_panels_condition_icon_color_desc",
								value = {"WolfHUDCustomHUD", "PLAYER", "CONDITION_ICON_COLOR"},
								visible_reqs = {}, enabled_reqs = {},
								options = {},
								add_color_options = true,
								add_rainbow = false,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_equip_title",
								desc_id = "CustomEOStandalone_panels_show_equip_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "EQUIPMENT"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_special_equip_title",
								desc_id = "CustomEOStandalone_panels_show_special_equip_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "SPECIAL_EQUIPMENT"},
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_special_equip_rows_title",
								desc_id = "CustomEOStandalone_panels_special_equip_rows_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false },
									{ setting = {"WolfHUDCustomHUD", "PLAYER", "SPECIAL_EQUIPMENT"}, invert = false },
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "SPECIAL_EQUIPMENT_ROWS"},
								min_value = 1,
								max_value = 8,
								step_size = 1,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_callsign_title",
								desc_id = "CustomEOStandalone_panels_show_callsign_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "CALLSIGN"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_carry_title",
								desc_id = "CustomEOStandalone_panels_show_carry_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "CARRY"},
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_icon_title",
								desc_id = "CustomEOStandalone_panels_weapon_icon_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both"
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "WEAPON", "ICON"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_name_title",
								desc_id = "CustomEOStandalone_panels_weapon_name_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both"
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "WEAPON", "NAME"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_ammo_title",
								desc_id = "CustomEOStandalone_panels_weapon_ammo_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both",
									"CustomEOStandalone_panels_ammo_total"
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "WEAPON", "AMMO"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_firemode_title",
								desc_id = "CustomEOStandalone_panels_weapon_firemode_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both"
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "WEAPON", "FIREMODE"},
							}
						},
					},
					{	--WolfHUDCustomHUD Teammate
						type = "menu",
						menu_id = "CustomEOStandalone_customhud_team_options_menu",
						name_id = "CustomEOStandalone_teampanels_options_name",
						desc_id = "CustomEOStandalone_teampanels_options_help",
						options = {
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_position_title",
								desc_id = "CustomEOStandalone_panels_position_desc",
								options = {
									"CustomEOStandalone_multiselect_left",
									"CustomEOStandalone_multiselect_center",
									"CustomEOStandalone_multiselect_right"
								},
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "POSITION"},
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_scale_title",
								desc_id = "CustomEOStandalone_panels_scale_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "SCALE"},
								min_value = 0.01,
								max_value = 2,
								step_size = 0.01,
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_oppacity_title",
								desc_id = "CustomEOStandalone_panels_oppacity_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "OPACITY"},
								min_value = 0,
								max_value = 1,
								step_size = 0.01,
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_name_title",
								desc_id = "CustomEOStandalone_panels_show_name_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "NAME"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_rank_title",
								desc_id = "CustomEOStandalone_panels_rank_name_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "RANK"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_truncate_tags_title",
								desc_id = "CustomEOStandalone_panels_truncate_tags_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "TRUNCATE_TAGS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_char_title",
								desc_id = "CustomEOStandalone_panels_show_char_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "CHARACTER"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_ping_title",
								desc_id = "CustomEOStandalone_panels_show_ping_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "LATENCY"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_status_title",
								desc_id = "CustomEOStandalone_panels_show_status_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "STATUS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_downcounter_title",
								desc_id = "CustomEOStandalone_panels_show_downcounter_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "DOWNCOUNTER"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_condition_icon_color_title",
								desc_id = "CustomEOStandalone_panels_condition_icon_color_desc",
								value = {"WolfHUDCustomHUD", "TEAMMATE", "CONDITION_ICON_COLOR"},
								visible_reqs = {}, enabled_reqs = {},
								options = {},
								add_color_options = true,
								add_rainbow = false,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_equip_title",
								desc_id = "CustomEOStandalone_panels_show_equip_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "EQUIPMENT"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_special_equip_title",
								desc_id = "CustomEOStandalone_panels_show_special_equip_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "SPECIAL_EQUIPMENT"},
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_special_equip_rows_title",
								desc_id = "CustomEOStandalone_panels_special_equip_rows_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false },
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "SPECIAL_EQUIPMENT"}, invert = false },
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "SPECIAL_EQUIPMENT_ROWS"},
								min_value = 1,
								max_value = 8,
								step_size = 1,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_callsign_title",
								desc_id = "CustomEOStandalone_panels_show_callsign_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "CALLSIGN"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_carry_title",
								desc_id = "CustomEOStandalone_panels_show_carry_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "CARRY"},
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_build_show_title",
								desc_id = "CustomEOStandalone_panels_build_show_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "BUILD", "HIDE"},
								invert_value = true,
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_build_time_title",
								desc_id = "CustomEOStandalone_panels_build_time_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "BUILD", "DURATION"},
								min_value = 0,
								max_value = 30,
								step_size = 1,
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_icon_title",
								desc_id = "CustomEOStandalone_panels_weapon_icon_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both"
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "WEAPON", "ICON"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_name_title",
								desc_id = "CustomEOStandalone_panels_weapon_name_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both"
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "WEAPON", "NAME"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_ammo_title",
								desc_id = "CustomEOStandalone_panels_weapon_ammo_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both",
									"CustomEOStandalone_panels_ammo_total"
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "WEAPON", "AMMO"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_weapon_firemode_title",
								desc_id = "CustomEOStandalone_panels_weapon_firemode_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "ENABLED"}, invert = false }
								},
								options = {
									"CustomEOStandalone_panels_hide",
									"CustomEOStandalone_panels_selected",
									"CustomEOStandalone_panels_unselected",
									"CustomEOStandalone_panels_both"
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "WEAPON", "FIREMODE"},
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_interaction_title",
								desc_id = "CustomEOStandalone_panels_show_interaction_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "HIDE"},
								invert_value = true,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_interaction_number_title",
								desc_id = "CustomEOStandalone_panels_show_interaction_number_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "NUMBER"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_show_interaction_text_title",
								desc_id = "CustomEOStandalone_panels_show_interaction_text_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "TEXT"},
							},
							{
								type = "slider",
								name_id = "CustomEOStandalone_panels_interaction_time_title",
								desc_id = "CustomEOStandalone_panels_interaction_time_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "INTERACTION", "MIN_DURATION"},
								min_value = 0,
								max_value = 30,
								step_size = 1,
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_panels_use_ai_color_title",
								desc_id = "CustomEOStandalone_panels_use_ai_color_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "AI_COLOR", "USE"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_panels_ai_color_title",
								desc_id = "CustomEOStandalone_panels_ai_color_desc",
								value = {"WolfHUDCustomHUD", "TEAMMATE", "AI_COLOR", "COLOR"},
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "AI_COLOR", "USE"}, invert = false }
								},
								options = {},
								add_color_options = true,
								add_rainbow = false,
							},
						},
					},
					{
						type = "divider",
						size = 8
					},
					{	--KillCounter
						type = "menu",
						menu_id = "CustomEOStandalone_killcounter_options_menu",
						name_id = "CustomEOStandalone_killcounter_options_name",
						desc_id = "CustomEOStandalone_killcounter_options_help",
						options = {
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_player_show_killcount_title",
								desc_id = "CustomEOStandalone_killcounter_player_show_killcount_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "HIDE"},
								invert_value = true,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_player_show_special_title",
								desc_id = "CustomEOStandalone_killcounter_player_show_special_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "SHOW_SPECIAL_KILLS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_player_show_head_title",
								desc_id = "CustomEOStandalone_killcounter_player_show_head_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "SHOW_HEADSHOT_KILLS"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_killcounter_player_color_title",
								desc_id = "CustomEOStandalone_killcounter_player_color_desc",
								value = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "COLOR"},
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								options = {},
								add_color_options = true,
								add_rainbow = false,
							},
							{
								type = "divider",
								size = 8,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_player_show_accuracy_title",
								desc_id = "CustomEOStandalone_killcounter_player_show_accuracy_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "PLAYER", "SHOW_ACCURACY"},
							},
							{
								type = "divider",
								size = 32,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_team_show_killcount_title",
								desc_id = "CustomEOStandalone_killcounter_team_show_killcount_desc",
								visible_reqs = {}, enabled_reqs = {},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "HIDE"},
								invert_value = true,
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_team_show_special_title",
								desc_id = "CustomEOStandalone_killcounter_team_show_special_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "SHOW_SPECIAL_KILLS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_team_show_head_title",
								desc_id = "CustomEOStandalone_killcounter_team_show_head_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "SHOW_HEADSHOT_KILLS"},
							},
							{
								type = "toggle",
								name_id = "CustomEOStandalone_killcounter_team_show_ai_title",
								desc_id = "CustomEOStandalone_killcounter_team_show_ai_desc",
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								value = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "SHOW_BOT_KILLS"},
							},
							{
								type = "multi_choice",
								name_id = "CustomEOStandalone_killcounter_team_color_title",
								desc_id = "CustomEOStandalone_killcounter_team_color_desc",
								value = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "COLOR"},
								visible_reqs = {},
								enabled_reqs = {
									{ setting = {"WolfHUDCustomHUD", "TEAMMATE", "KILLCOUNTER", "HIDE"}, invert = true }
								},
								options = {},
								add_color_options = true,
								add_rainbow = false,
							},
						},
					},
					{
						type = "divider",
						size = 16,
					},
				},
			},
			{
				type = "divider",
				size = 32,
			},
			{
				type = "button",
				name_id = "CustomEOStandalone_reset_options_title",
				desc_id = "CustomEOStandalone_reset_options_desc",
				clbk = "CustomEOStandalone_reset_clbk",
			},
		},
	}
end
