if VHUDPlus then
	return
end

if string.lower(RequiredScript) == "lib/units/beings/player/huskplayermovement" then

	-- local _perform_movement_action_enter_bleedout_original = HuskPlayerMovement._perform_movement_action_enter_bleedout

	-- function HuskPlayerMovement:_perform_movement_action_enter_bleedout(...)
	-- 	if not self._bleedout then
	-- 		local crim_data = managers.criminals:character_data_by_unit(self._unit)
	-- 		if crim_data and crim_data.panel_id then
	-- 			managers.hud:increment_teammate_downs(crim_data.panel_id)
	-- 		end
	-- 	end

	-- 	return _perform_movement_action_enter_bleedout_original(self, ...)
	-- end
elseif string.lower(RequiredScript) == "lib/managers/group_ai_states/groupaistatebase" then

	local set_whisper_mode_original = GroupAIStateBase.set_whisper_mode
	function GroupAIStateBase:set_whisper_mode(enabled, ...)
		set_whisper_mode_original(self, enabled, ...)
		if (enabled) then
			managers.hud:set_hud_mode("stealth")
		else
			managers.hud:set_hud_mode("loud")
		end
		self:_call_listeners("whisper_mode", enabled)
	end
elseif string.lower(RequiredScript) == "lib/managers/hudmanagerpd2" then

	HUDManager.DOWNS_COUNTER_PLUGIN = true

	-- local set_player_health_original = HUDManager.set_player_health
	-- local set_mugshot_custody_original = HUDManager.set_mugshot_custody

	-- function HUDManager:set_player_health(data, ...)
	-- 	if data.revives then
	-- 		self:set_player_revives(HUDManager.PLAYER_PANEL, data.revives - 1)
	-- 	end
	-- 	return set_player_health_original(self, data, ...)
	-- end

	-- function HUDManager:set_mugshot_custody(id, ...)
	-- 	local data = self:_get_mugshot_data(id)
	-- 	if data then
	-- 		local i = managers.criminals:character_data_by_name(data.character_name_id).panel_id
	-- 		managers.hud:reset_teammate_downs(i)
	-- 	end

	-- 	return set_mugshot_custody_original(self, id, ...)
	-- end

	function HUDManager:set_hud_mode(mode)
		for _, panel in pairs(self._teammate_panels or {}) do
			panel:set_hud_mode(mode)
		end
	end

	HUDManager.set_player_revives = HUDManager.set_player_revives or function(self, i, revive_amount)
		self._teammate_panels[i]:set_revives_amount(revive_amount)
	end

	-- HUDManager.increment_teammate_downs = HUDManager.increment_teammate_downs or function(self, i)
	-- 	self._teammate_panels[i]:increment_downs()
	-- end

	-- HUDManager.reset_teammate_downs = HUDManager.reset_teammate_downs or function(self, i)
	-- 	self._teammate_panels[i]:reset_downs()
	-- end
end