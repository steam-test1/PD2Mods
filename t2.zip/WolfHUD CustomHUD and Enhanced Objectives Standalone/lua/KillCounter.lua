if VHUDPlus then
	return
end

if RequiredScript == "lib/units/equipment/sentry_gun/sentrygunbase" then

	local sync_setup_original = SentryGunBase.sync_setup

	function SentryGunBase:sync_setup(upgrade_lvl, peer_id, ...)
		sync_setup_original(self, upgrade_lvl, peer_id, ...)
		self._owner_id = self._owner_id or peer_id
	end

elseif RequiredScript == "lib/managers/statisticsmanager" then

	local _update_debug_ws_original = CopDamage._update_debug_ws
	--Workaround for Teammate Headshots, since col_ray doesn't get forwarded...  (self._sync_ibody_killcount)
	local sync_damage_bullet_original = CopDamage.sync_damage_bullet
	local sync_damage_melee_original = CopDamage.sync_damage_melee

	function CopDamage:_process_kill(data)
		local killer

		local attacker = data and alive(data.attacker_unit) and data.attacker_unit

		if attacker then
			if attacker:in_slot(3) or attacker:in_slot(5) then
				--Human team mate
				killer = attacker
			elseif attacker:in_slot(2) then
				--Player
				killer = attacker
			elseif attacker:in_slot(16) then
				--Bot/joker
				killer = attacker
			elseif attacker:in_slot(12) then
				--Enemy
			elseif attacker:in_slot(25)	then
				--Turret
				local owner = attacker:base():get_owner_id()
				if owner then
					killer =  managers.criminals:character_unit_by_peer_id(owner)
				end
			elseif attacker:base().thrower_unit then
				killer = attacker:base():thrower_unit()
			end

			if alive(killer) and alive(self._unit) then
				local tweak_id = self._unit:base()._tweak_table
				local special_unit_ids = managers.statistics and managers.statistics.special_unit_ids or {}
				local is_special = managers.groupai:state():is_enemy_special(self._unit) or table.contains(special_unit_ids, tweak_id)
				local body = data.col_ray and data.col_ray.body or self._sync_ibody_killcount and self._unit:body(self._sync_ibody_killcount)
				local headshot = body and self.is_head and self:is_head(body) or false

				if killer:in_slot(2) then
					managers.hud:increment_teammate_kill_count(HUDManager.PLAYER_PANEL, is_special, headshot)

					local current_player_state = managers.player and managers.player:get_current_state()
					local weapon_base = current_player_state and current_player_state._equipped_unit:base()
					local projectile_name = "bullet"
					if weapon_base._projectile_type_index then
						projectile_name = tweak_data and tweak_data:get_raw_value("blackmarket", "projectiles", "_projectiles_index", weapon_base._projectile_type_index)
					end
					if projectile_name == (data.variant or "") then
						local weapon_id = weapon_base:get_name_id()
						local weapon_tweak = weapon_base and weapon_base:weapon_tweak_data()
						local weapon_type = weapon_tweak.category
						local slot = weapon_tweak and weapon_tweak.use_data and weapon_tweak.use_data.selection_index
						managers.hud:increment_teammate_kill_count_detailed(HUDManager.PLAYER_PANEL, self._unit, weapon_id, weapon_type, slot)
					end
				else
					local crim_data = managers.criminals:character_data_by_unit(killer)
					if crim_data and crim_data.panel_id then
						managers.hud:increment_teammate_kill_count(crim_data.panel_id, is_special, headshot)
					end
				end
			end
		end
	end

	function CopDamage:_update_debug_ws(data, ...)
		_update_debug_ws_original(self, data, ...)
		if self._dead then
			self:_process_kill(data)
		end
	
		self._sync_ibody_killcount = nil
	end
	
	function CopDamage:sync_damage_bullet(attacker_unit, damage_percent, i_body, ...)
		if i_body then
			self._sync_ibody_killcount = i_body
		end

		return sync_damage_bullet_original(self, attacker_unit, damage_percent, i_body, ...)
	end

	function CopDamage:sync_damage_melee(attacker_unit, damage_percent, damage_effect_percent, i_body, ...)
		if i_body then
			self._sync_ibody_killcount = i_body
		end

		return sync_damage_melee_original(self, attacker_unit, damage_percent, damage_effect_percent, i_body, ...)

	end

	local shot_fired_original = StatisticsManager.shot_fired

	function StatisticsManager:shot_fired(data, ...)
		shot_fired_original(self, data, ...)

		--[[
			This does not work well for HE rounds. It would be almost correct if you halved number of shots,
			but would not take into account shots that goes into the void or compensate for direct hits
		]]

		local name_id = data.name_id or data.weapon_unit:base():get_name_id()
		local weapon_tweak = tweak_data.weapon[name_id]
		local slot = weapon_tweak and weapon_tweak.use_data and weapon_tweak.use_data.selection_index
		if slot then	--Exclude throwables like exploding cards mod...
			local weapon_data = name_id and self._global.session.shots_by_weapon[name_id]
			local weapon_accuracy = 0
			if weapon_data and weapon_data.total > 0 then
				weapon_accuracy = math.floor(100 * weapon_data.hits / weapon_data.total)
			end
			managers.hud:set_teammate_weapon_accuracy(HUDManager.PLAYER_PANEL, slot, weapon_accuracy)
		end

		managers.hud:set_teammate_accuracy(HUDManager.PLAYER_PANEL, self:session_hit_accuracy())
	end

elseif RequiredScript == "lib/managers/hudmanagerpd2" then

	HUDManager.KILL_COUNTER_PLUGIN = true
	HUDManager.ACCURACY_PLUGIN = true

	HUDManager.increment_teammate_kill_count = HUDManager.increment_teammate_kill_count or function (self, i, is_special, headshot)
		self._teammate_panels[i]:increment_kill_count(is_special, headshot)
	end

	HUDManager.reset_teammate_kill_count = HUDManager.reset_teammate_kill_count or function(self, i)
		self._teammate_panels[i]:reset_kill_count()
	end

	HUDManager.increment_teammate_kill_count_detailed = HUDManager.increment_teammate_kill_count_detailed or function(self, i, unit, weapon_id, weapon_type, weapon_slot)
		--TODO: Add call for default HUD  |  No need for that, really...
	end

	HUDManager.set_teammate_accuracy = HUDManager.set_teammate_accuracy or function(self, i, value)
		self._teammate_panels[i]:set_accuracy(value)
	end

	HUDManager.set_teammate_weapon_accuracy = HUDManager.set_teammate_weapon_accuracy or function(self, i, slot, value)
		--TODO
	end

	function HUDManager:teampanels_height()
		return (CustomEOStandalone:getSetting({"WolfHUDCustomHUD", "PLAYER", "SHOW_ACCURACY"}, true) and not CustomEOStandalone:getSetting({"WolfHUDCustomHUD", "PLAYER", "KILLCOUNTER", "HIDE"}, false)) and 140 or 120
	end
end
