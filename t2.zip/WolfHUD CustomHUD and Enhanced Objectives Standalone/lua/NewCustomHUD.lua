if RequiredScript == "lib/managers/hudmanagerpd2" then
elseif RequiredScript == "lib/managers/hud/hudteammate" then
elseif RequiredScript == "lib/managers/hud/hudtemp" then
end